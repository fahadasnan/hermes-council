import { addMember, freshShop } from "./checkoutFixtures";
import { expect, signIn, signOut, test } from "./fixtures";
import { recordPassingTest, storedConnection } from "./paymentFixtures";

// 10.2-T4: Settings → Online payments. The owner connects the shop's own
// MyFatoorah merchant from the screen. The key test calls the provider, which
// no e2e run does: the passing test is recorded through the same service-role
// RPC the payments function uses (the function's tests cover the call).
// The keys are made up here and must never come back in a response or the page.

test("the owner connects MyFatoorah: checklist, write-only keys, approvals, turn on, pause and disconnect", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  test.setTimeout(180_000);
  const shop = await freshShop(request, `pay-${appLocale}`);
  const manager = await addMember(request, shop, "branch_manager");
  const apiToken = `e2e-token-${crypto.randomUUID()}`;
  const webhookSecret = `e2e-hook-${crypto.randomUUID()}`;
  const responses: string[] = [];
  page.on("response", (response) => {
    if (new URL(response.url()).pathname.split("/").includes("payments")) {
      void response.text().then((body) => responses.push(body), () => undefined);
    }
  });

  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await page.goto("/settings");
  await page.getByRole("link", { name: s.onlinePayments }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.onlinePayments })).toBeVisible();
  const mf = page.getByRole("region", { name: s.myFatoorah });
  const tap = page.getByRole("region", { name: s.tapProvider });
  await expect(mf).toContainText(s.payNotConnected);
  await expect(tap).toContainText(s.payNotConnected);
  await expect(tap.getByLabel(s.paySecretKey)).toBeVisible();
  await expect(tap.getByLabel(s.payWebhookSecret)).toHaveCount(0);

  // A step the owner ticks is kept before any key is saved.
  await mf.getByRole("checkbox", { name: s.payStepBankAccount }).check();
  await expect.poll(async () => (await storedConnection(request, shop, "myfatoorah"))?.status).toBe("draft");
  await page.reload();
  await expect(mf.getByRole("checkbox", { name: s.payStepBankAccount })).toBeChecked();

  // Keys: refused when empty, then saved once and never shown again.
  await mf.getByRole("button", { name: s.paySaveKeys }).click();
  await expect(mf.getByText(s.payPasteWholeKey).first()).toBeVisible();
  await mf.getByLabel(s.payApiToken).fill(apiToken);
  await mf.getByLabel(s.payWebhookSecret).fill(webhookSecret);
  await mf.getByRole("button", { name: s.paySaveKeys }).click();
  await expect(page.getByText(s.payKeysSaved(s.myFatoorah))).toBeVisible();
  await expect(mf).toContainText(s.payNotTurnedOn);
  await expect(mf).toContainText(s.payTestMode);
  await expect(mf).toContainText(s.payKeyEnding(apiToken.slice(-4)));
  await expect(mf).toContainText(s.payNotTested);
  await expect(mf.getByLabel(s.payApiToken)).toHaveValue("");
  await expect(mf.getByLabel(s.payWebhookSecret)).toHaveValue("");
  await expect(mf.getByRole("button", { name: s.payReplaceKeys })).toBeVisible();

  // Turning on waits for a passed test and an approved method.
  await expect(mf.getByRole("button", { name: s.payTurnOn })).toBeDisabled();
  await expect(mf).toContainText(s.payGapTest);
  await expect(mf).toContainText(s.payGapMethod);
  await recordPassingTest(request, shop, "myfatoorah");
  await page.reload();
  await expect(mf).toContainText(s.payPassed);
  await expect(mf).not.toContainText(s.payGapTest);
  await mf.getByRole("checkbox", { name: s.payKnet, exact: true }).check();
  await mf.getByRole("button", { name: s.paySaveFeatures }).click();
  await expect(page.getByText(s.payFeaturesSaved(s.myFatoorah))).toBeVisible();
  expect((await storedConnection(request, shop, "myfatoorah"))?.capabilities).toEqual(["knet"]);

  await mf.getByRole("button", { name: s.payTurnOn }).click();
  await expect(page.getByText(s.payIsActive(s.myFatoorah))).toBeVisible();
  await expect(mf).toContainText(s.payActive);
  expect((await storedConnection(request, shop, "myfatoorah"))?.status).toBe("active");

  await mf.getByRole("button", { name: s.payPause }).click();
  await page.getByRole("alertdialog", { name: s.payPauseTitle(s.myFatoorah) }).getByRole("button", { name: s.payPause }).click();
  await expect(page.getByText(s.payIsPaused(s.myFatoorah))).toBeVisible();
  await expect(mf).toContainText(s.payPaused);
  await mf.getByRole("button", { name: s.payTurnBackOn }).click();
  await expect(mf).toContainText(s.payActive);

  await mf.getByRole("button", { name: s.payDisconnect }).click();
  await page
    .getByRole("alertdialog", { name: s.payDisconnectTitle(s.myFatoorah) })
    .getByRole("button", { name: s.payDisconnect })
    .click();
  await expect(page.getByText(s.payIsDisconnected(s.myFatoorah))).toBeVisible();
  await expect(mf).toContainText(s.payDisconnected);
  await expect(mf).not.toContainText(s.payKeyEnding(apiToken.slice(-4)));
  expect((await storedConnection(request, shop, "myfatoorah"))?.status).toBe("disconnected");
  await expect(tap).toContainText(s.payNotConnected);

  // The keys went in once and never came back out.
  expect(responses.length).toBeGreaterThan(0);
  for (const body of responses) {
    expect(body).not.toContain(apiToken);
    expect(body).not.toContain(webhookSecret);
  }
  expect(await page.content()).not.toContain(apiToken);

  // A manager has neither the settings entry nor the page.
  await signOut(page, s);
  await signIn(page, s, manager);
  await page.goto("/settings");
  await expect(page.getByRole("link", { name: s.onlinePayments })).toHaveCount(0);
  await page.goto("/settings/online-payments");
  await expect(page.getByRole("heading", { name: s.forbidden })).toBeVisible();
});
