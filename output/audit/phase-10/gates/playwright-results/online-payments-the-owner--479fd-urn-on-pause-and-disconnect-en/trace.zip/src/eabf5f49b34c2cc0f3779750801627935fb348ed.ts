import type { APIRequestContext } from "@playwright/test";
import { admin, REST } from "./bookingFixtures";
import type { Shop } from "./checkoutFixtures";
import { expect } from "./fixtures";

// Online payment connections for e2e, written through the service-role RPCs
// the payments function uses. No run calls a provider, so a key test is
// recorded rather than made, and seeded credentials are placeholder
// ciphertext that no key decrypts.

export type StoredConnection = { id: string; status: string; credentials_revision: number; capabilities: string[] };

export async function storedConnection(
  request: APIRequestContext,
  shop: Shop,
  provider: string,
): Promise<StoredConnection | undefined> {
  const response = await request.get(
    `${REST}/payment_provider_connections?tenant_id=eq.${shop.tenantId}&provider=eq.${provider}&select=id,status,credentials_revision,capabilities`,
    { headers: admin },
  );
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as StoredConnection[])[0];
}

async function ownerId(request: APIRequestContext, shop: Shop): Promise<string> {
  const response = await request.get(
    `${REST}/memberships?tenant_id=eq.${shop.tenantId}&role=eq.tenant_owner&select=user_id`,
    { headers: admin },
  );
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { user_id: string }[])[0]!.user_id;
}

async function rpc(request: APIRequestContext, name: string, data: Record<string, unknown>) {
  const response = await request.post(`${REST}/rpc/${name}`, { headers: admin, data });
  expect(response.ok(), await response.text()).toBe(true);
  return (await response.json()) as { id: string; credentials_revision: number };
}

export async function recordPassingTest(request: APIRequestContext, shop: Shop, provider: string) {
  const connection = (await storedConnection(request, shop, provider))!;
  await rpc(request, "record_provider_connection_test", {
    p_actor: await ownerId(request, shop),
    p_tenant_id: shop.tenantId,
    p_provider: provider,
    p_revision: connection.credentials_revision,
    p_result: "ok",
  });
}

/** A test-mode connection with keys saved: "testing", not yet tested. */
export async function savedConnection(request: APIRequestContext, shop: Shop, provider: "myfatoorah" | "tap") {
  const actor = { p_actor: await ownerId(request, shop), p_tenant_id: shop.tenantId, p_provider: provider };
  const opened = await rpc(request, "open_provider_connection", actor);
  const myFatoorah = provider === "myfatoorah";
  await rpc(request, "save_provider_connection", {
    ...actor,
    p_connection_id: opened.id,
    p_mode: "sandbox",
    p_account_country: myFatoorah ? "KW" : null,
    p_key_version: 1,
    p_nonce: "AAAAAAAAAAAAAAAA",
    p_ciphertext: "AAAAAAAAAAAAAAAAAAAAAAAA",
    p_secret_hint: "e2e0",
    p_webhook_secret_hint: myFatoorah ? "e2e1" : null,
  });
  return actor;
}

/** A test-mode connection, keys saved and tested, with these approvals, turned on. */
export async function activeConnection(
  request: APIRequestContext,
  shop: Shop,
  provider: "myfatoorah" | "tap",
  capabilities: string[],
) {
  await savedConnection(request, shop, provider);
  await activateConnection(request, shop, provider, capabilities);
}

/** Records a passing key test, these approvals, and turns a saved connection on. */
export async function activateConnection(
  request: APIRequestContext,
  shop: Shop,
  provider: "myfatoorah" | "tap",
  capabilities: string[],
) {
  const actor = { p_actor: await ownerId(request, shop), p_tenant_id: shop.tenantId, p_provider: provider };
  await recordPassingTest(request, shop, provider);
  await rpc(request, "update_provider_connection_checklist", { ...actor, p_steps: {}, p_capabilities: capabilities });
  await rpc(request, "set_provider_connection_status", { ...actor, p_status: "active" });
}

export async function setConnectionStatus(
  request: APIRequestContext,
  shop: Shop,
  provider: "myfatoorah" | "tap",
  status: "active" | "suspended" | "disconnected",
) {
  await rpc(request, "set_provider_connection_status", {
    p_actor: await ownerId(request, shop),
    p_tenant_id: shop.tenantId,
    p_provider: provider,
    p_status: status,
  });
}

export type BranchPaymentRow = {
  knet_provider: string | null;
  card_provider: string | null;
  payment_mode: string;
  deposit_percent_bp: number | null;
  deposit_fixed_minor: number | null;
  card_on_file: string;
  hold_minutes: number;
  no_show_fee_percent_bp: number | null;
  no_show_fee_fixed_minor: number | null;
  late_cancel_fee_percent_bp: number | null;
  late_cancel_fee_fixed_minor: number | null;
  late_cancel_window_minutes: number;
};

export async function branchPaymentSettings(request: APIRequestContext, shop: Shop): Promise<BranchPaymentRow> {
  const response = await request.get(`${REST}/branch_online_payment_settings?branch_id=eq.${shop.branchId}&select=*`, {
    headers: admin,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as BranchPaymentRow[])[0]!;
}
