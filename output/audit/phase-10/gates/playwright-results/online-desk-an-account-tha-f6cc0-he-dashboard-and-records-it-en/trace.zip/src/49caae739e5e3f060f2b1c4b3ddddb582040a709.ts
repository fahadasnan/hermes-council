import AxeBuilder from "@axe-core/playwright";
import type { APIRequestContext, Page } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { addDays } from "./blockedTimeFlows";
import { accessToken, ANON_KEY, API, kuwait } from "./bookingFixtures";
import { createSale, freshShop, openCalendar, saleOf, shopCatalogue, shopVisit, type Shop } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { connectProvider, payByLink, PROVIDERS, replayedCalls, replayRefund, type OnlineShop } from "./onlineFixtures";
import { kuwaitToday } from "./shiftFlows";
import type { Strings } from "./strings";

// 10.8-T7 online money at the desk, each journey in a tenant of its own with
// its own provider connection (fabricated keys) and the fixture-replay server
// standing in for MyFatoorah and Tap: a partial refund of a payment taken by
// link, a refund the owner makes in the provider's dashboard and records, a
// no-show fee sent as a payment link, and the deposits-held report. axe runs
// on each new dialog and screen.

const PRICE = 12_000;
const TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"];

/** axe once nothing is loading or moving (a fading dialog reads as half-blended colours). */
async function axe(page: Page) {
  await expect(page.locator('[aria-busy="true"]')).toHaveCount(0);
  await page.waitForFunction(() =>
    document
      .getAnimations()
      .every((animation) => animation.playState !== "running" || animation.effect?.getTiming().iterations === Infinity),
  );
  const results = await new AxeBuilder({ page }).withTags(TAGS).analyze();
  expect(results.violations.map((violation) => [violation.id, violation.nodes.map((node) => node.target.join(" "))])).toEqual([]);
}

async function bookingsCall(request: APIRequestContext, shop: Shop, route: string, data: unknown) {
  const response = await request.post(functionUrl(API, "bookings", route), {
    headers: {
      apikey: ANON_KEY,
      authorization: `Bearer ${await accessToken(request, shop.owner)}`,
      "idempotency-key": crypto.randomUUID(),
    },
    data,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { data: { id: string } }).data;
}

/** Signs in as the owner and opens the visit labelled `label` from the branch calendar on `day`. */
async function openVisit(page: Page, s: Strings, shop: Shop, day: string, label: string) {
  await openCalendar(page, s, shop.owner, shop.branchId, day);
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await byStaff.locator("[data-event-id]:not([id^='time-grid-event-copy-'])").filter({ hasText: label }).first().click();
  return page.getByRole("dialog", { name: new RegExp(label) });
}

/** Tomorrow's visit at PRICE, sold unpaid and then paid in full by KNET from a payment link. */
async function visitPaidByLink(request: APIRequestContext, shop: OnlineShop) {
  const day = addDays(kuwaitToday(), 1);
  const visit = await shopVisit(request, shop, shop.owner, { day, priceMinor: PRICE });
  const sale = await createSale(request, shop.owner, {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    appointment_id: visit.id,
    client_id: visit.clientId,
    lines: [{ type: "appointment_item", appointment_item_id: visit.itemId }],
    tips: [],
    payments: [],
    expected: { total_minor: PRICE, tip_minor: 0, grand_total_minor: PRICE },
  });
  await payByLink(request, shop, sale.id, PRICE);
  return { day, visit, sale };
}

/** Opens the visit's sale from the appointment drawer. */
async function openSale(page: Page, s: Strings, shop: Shop, day: string, label: string) {
  const appointment = await openVisit(page, s, shop, day, label);
  await appointment.getByRole("button", { name: s.viewSale }).click();
  return page.getByRole("dialog", { name: s.sale, exact: true });
}

for (const provider of PROVIDERS) {
  test(`${provider}: part of a payment taken by link is refunded from the sale, and waits for the provider`, async ({
    page,
    request,
    s,
    appLocale,
  }) => {
    const shop = await connectProvider(request, await freshShop(request, `od-${provider.slice(0, 3)}-${appLocale}`), provider);
    const { day, visit, sale } = await visitPaidByLink(request, shop);
    await replayRefund(request, shop);

    const drawer = await openSale(page, s, shop, day, visit.label);
    const payments = drawer.getByRole("list", { name: s.paymentsAndRefunds });
    await expect(payments).toContainText(s.knetOnline);
    await expect(payments).toContainText(s.providerName[provider]);
    await axe(page);

    await drawer.getByRole("button", { name: s.refundPaymentButton(s.knetOnline) }).click();
    const dialog = page.getByRole("dialog", { name: s.refundThisPayment });
    await expect(dialog).toContainText("12.000");
    await dialog.getByRole("textbox", { name: s.refundAmount }).fill("5.000");
    await dialog.getByRole("textbox", { name: s.reason }).fill("Service cut short");
    await axe(page);
    await dialog.getByRole("button", { name: s.refundConfirm }).click();
    await expect(dialog).toBeHidden();

    await expect(drawer.getByText(s.onlineRefundSent(s.providerName[provider]))).toBeVisible();
    const pending = drawer.getByRole("list", { name: s.pendingRefunds }).getByRole("listitem");
    await expect(pending).toHaveCount(1);
    await expect(pending).toContainText(s.pendingBadge);
    await expect(pending).toContainText("5.000");
    // 7.000 is still refundable.
    await expect(drawer.getByRole("button", { name: s.refundPaymentButton(s.knetOnline) })).toBeVisible();

    // The ledger gains the refund only when the provider confirms it.
    const stored = await saleOf(request, { id: sale.id });
    expect(stored.status).toBe("completed");
    expect(stored.payments.map((p) => [p.payment_type, p.payment_method, p.amount_minor])).toEqual([["payment", "knet_online", PRICE]]);
    const calls = await replayedCalls(request, shop);
    expect(calls.filter((call) => !call.matched), JSON.stringify(calls)).toEqual([]);
    expect(calls.map((call) => call.path)).toContain(provider === "tap" ? "/v2/refunds" : "/v2/MakeRefund");
  });
}

test("an account that can't refund KNET by API: the owner refunds in the dashboard and records it", async ({ page, request, s, appLocale }) => {
  const provider = appLocale === "en" ? "myfatoorah" : "tap";
  const name = s.providerName[provider];
  const plain = await freshShop(request, `od-dash-${appLocale}`);
  const shop = await connectProvider(request, plain, provider, {}, ["knet", "cards", "refunds_api"]);
  const { day, visit, sale } = await visitPaidByLink(request, shop);

  const drawer = await openSale(page, s, shop, day, visit.label);
  await drawer.getByRole("button", { name: s.refundPaymentButton(s.knetOnline) }).click();
  const dialog = page.getByRole("dialog", { name: s.refundThisPayment });
  await dialog.getByRole("textbox", { name: s.reason }).fill("Client cancelled");
  await dialog.getByRole("button", { name: s.refundConfirm }).click();
  await expect(dialog).toBeHidden();

  await expect(drawer.getByText(s.dashboardRefund(name))).toBeVisible();
  const pending = drawer.getByRole("list", { name: s.pendingRefunds }).getByRole("listitem");
  await expect(pending).toContainText(s.refundInDashboard(name));
  await pending.getByRole("button", { name: s.recordRefundButton(s.knetOnline) }).click();

  const record = page.getByRole("dialog", { name: s.recordThisRefund });
  await axe(page);
  await record.getByRole("textbox", { name: s.refundReference }).fill("RF-20261014-01");
  await record.getByRole("button", { name: s.recordRefund, exact: true }).click();
  await expect(record).toBeHidden();

  await expect(drawer.getByText(s.refundRecorded)).toBeVisible();
  await expect(drawer.getByRole("list", { name: s.pendingRefunds })).toHaveCount(0);
  await expect(drawer.getByRole("list", { name: s.paymentsAndRefunds })).toContainText(s.refundOf(s.knetOnline));

  // The recorded refund is a ledger row; the provider was never asked to refund.
  const stored = await saleOf(request, { id: sale.id });
  expect(stored.payments.map((p) => [p.payment_type, p.payment_method, p.amount_minor])).toEqual([
    ["payment", "knet_online", PRICE],
    ["refund", "knet_online", PRICE],
  ]);
  const paths = (await replayedCalls(request, shop)).map((call) => call.path);
  expect(paths.filter((path) => path.includes("efund")), JSON.stringify(paths)).toEqual([]);
});

test("a no-show fee becomes a sale on the visit, sent to the client as a payment link", async ({ page, request, s, appLocale }) => {
  const provider = appLocale === "en" ? "tap" : "myfatoorah";
  const shop = await connectProvider(request, await freshShop(request, `fee-${appLocale}`), provider, { no_show_fee_fixed_minor: 5_000 });
  const day = addDays(kuwaitToday(), 1);
  const catalogue = await shopCatalogue(request, shop, {
    day,
    priceMinor: PRICE,
  });
  const visit = await bookingsCall(request, shop, "create", {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    client_id: catalogue.clientId,
    items: [
      {
        service_id: catalogue.serviceId,
        staff_id: catalogue.staffId,
        starts_at: kuwait(day, "15:00"),
      },
    ],
  });
  await bookingsCall(request, shop, "no-show", {
    tenant_id: shop.tenantId,
    appointment_id: visit.id,
  });

  const appointment = await openVisit(page, s, shop, day, catalogue.label);
  const fees = appointment.getByRole("region", { name: s.depositAndFees });
  await expect(fees).toContainText(s.noShowFee);
  await expect(fees).toContainText("5.000");
  await fees.getByRole("button", { name: s.chargeNoShowFee }).click();

  const dialog = page.getByRole("dialog", { name: s.chargeNoShowFee });
  await expect(dialog.getByText(s.feeByLink)).toBeVisible();
  await axe(page);
  await dialog.getByRole("button", { name: s.chargeFee }).click();
  await expect(dialog.getByText(s.linkCreatedNoEmail)).toBeVisible();
  await expect(dialog.getByRole("button", { name: s.copyLink })).toBeVisible();
  await expect(dialog).toContainText("/l/");
  await axe(page);
  await dialog.getByRole("button", { name: s.done }).click();
  await expect(dialog).toBeHidden();

  // The visit now shows the fee's sale, still due, with "Collect again".
  await expect(fees).toContainText(s.noShowFee);
  await expect(fees.getByRole("button", { name: s.collectAgain })).toBeVisible();
  await expect(fees.getByRole("button", { name: s.chargeNoShowFee })).toHaveCount(0);

  const stored = await saleOf(request, { appointmentId: visit.id });
  expect([stored.status, stored.totals.grand_total_minor, stored.totals.due_minor, stored.payments]).toEqual(["unpaid", 5_000, 5_000, []]);
});

test("the deposits-held report opens from the hub", async ({ page, request, s }) => {
  const shop = await freshShop(request, "deposits");
  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/reports?branch=${shop.branchId}`);
  await page.getByRole("list", { name: s.reports }).getByRole("link", { name: s.depositsHeld, exact: true }).click();
  await expect(page).toHaveURL(/\/reports\/deposits/);
  await expect(page.getByRole("heading", { level: 1, name: s.depositsHeld })).toBeVisible();
  await expect(page.getByText(s.noDepositsWaiting)).toBeVisible();
  await axe(page);
});
