import AxeBuilder from "@axe-core/playwright";
import type { Page } from "@playwright/test";
import { createSale, freshShop, walkInSale } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { chargeReference, connectProvider, payByLink, PROVIDERS, replayChargeLost, replayedCalls } from "./onlineFixtures";
import { kuwaitToday } from "./shiftFlows";

// 10.9-T4 the owner's payment reconciliation, each provider in a tenant of its
// own with fabricated keys and the fixture-replay server standing in for
// MyFatoorah and Tap: today's payment by link checks out to zero difference
// (Tap from its list of charges, MyFatoorah by asking about each payment),
// then the provider loses the charge and, at Tap, lists one GlowDesk never
// made, and "Check again" shows both as differences to follow up.

const PRICE = 12_000;
const TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"];

/** axe once nothing is loading or moving. */
async function axe(page: Page) {
  await expect(page.locator('[aria-busy="true"]')).toHaveCount(0);
  await page.waitForFunction(() =>
    document
      .getAnimations()
      .every((animation) => animation.playState !== "running" || animation.effect?.getTiming().iterations === Infinity),
  );
  const results = await new AxeBuilder({ page }).withTags(TAGS).analyze();
  expect(results.violations.map((violation) => [violation.id, violation.nodes.map((node) => node.target.join(" "))])).toEqual([]);
}

for (const provider of PROVIDERS) {
  test(`${provider}: the day's payment reconciles to zero, and a charge the provider lost is a difference`, async ({
    page,
    request,
    s,
    appLocale,
  }) => {
    const shop = await connectProvider(request, await freshShop(request, `rc-${provider.slice(0, 3)}-${appLocale}`), provider);
    const sale = await createSale(request, shop.owner, walkInSale(shop, PRICE, []));
    await payByLink(request, shop, sale.id, PRICE);
    const name = s.providerName[provider];
    const today = kuwaitToday();

    await page.goto("/login");
    await signIn(page, s, shop.owner);
    await expect(page).toHaveURL(/\?branch=/);
    await page.goto(`/settings/online-payments?branch=${shop.branchId}`);
    await page.getByRole("link", { name: s.paymentReconciliation }).click();
    await expect(page.getByRole("heading", { level: 1, name: s.paymentReconciliation })).toBeVisible();
    // Yesterday, by default: nothing was paid then.
    const card = page.getByRole("region", { name: s.reconOnDay(name) });
    await expect(card).toContainText(s.reconNotChecked);

    await page.goto(`/settings/online-payments/reconciliation?branch=${shop.branchId}&date=${today}`);
    await expect(card).toContainText(s.reconNotChecked);
    const before = (await replayedCalls(request, shop)).length;
    await card.getByRole("button", { name: s.reconCheckNow }).click();
    await expect(card.getByText(s.reconBalanced, { exact: true })).toBeVisible();
    await expect(card).toContainText(s.reconPaymentsAt(name));
    await expect(card).toContainText(s.reconPaymentsInGlowDesk);
    const [atProvider, inGlowDesk] = [card.locator("dd").nth(0), card.locator("dd").nth(1)];
    await expect(atProvider).toContainText("12.000");
    await expect(inGlowDesk).toContainText("12.000");
    await expect(card).toContainText(provider === "tap" ? s.reconFromList(name) : s.reconAskedEach(name));
    await expect(card.getByRole("listitem")).toHaveCount(0);
    await expect(page.getByRole("table", { name: s.reconLastDays })).toContainText(s.reconBalanced);
    await axe(page);

    const checked = (await replayedCalls(request, shop)).slice(before);
    expect(checked.filter((call) => !call.matched), JSON.stringify(checked)).toEqual([]);
    // Tap's list settles the payment without asking about it; MyFatoorah is asked.
    expect(checked.map((call) => `${call.method} ${call.path}`)).toEqual(
      provider === "tap" ? ["POST /v2/charges/list"] : expect.arrayContaining(["POST /v2/GetPaymentStatus"]),
    );

    // The provider no longer knows the charge; at Tap, a charge GlowDesk never made is listed.
    const reference = await chargeReference(request, sale.id);
    await replayChargeLost(request, shop, reference);
    await card.getByRole("button", { name: s.reconCheckAgain }).click();
    await expect(card.getByText(s.reconDifferencesFound, { exact: true })).toBeVisible();
    // GlowDesk still holds the payment; the provider settled nothing for it.
    await expect(atProvider).toContainText("0.000");
    await expect(atProvider).not.toContainText("12");
    await expect(inGlowDesk).toContainText("12.000");
    const differences = provider === "tap" ? 2 : 1;
    await expect(card.getByRole("heading", { name: s.reconDifferenceCount(differences) })).toBeVisible();
    const items = card.getByRole("listitem");
    await expect(items).toHaveCount(differences);
    const lost = items.filter({ hasText: s.reconNoRecord(name) });
    await expect(lost).toContainText(reference);
    await expect(lost).toContainText("12.000");
    if (provider === "tap") {
      const foreign = items.filter({ hasText: s.reconForeignCharge(name) });
      await expect(foreign).toContainText("3.500");
      await expect(foreign.getByRole("link")).toHaveCount(0);
    }
    await axe(page);

    await lost.getByRole("link", { name: s.reconOpenSale }).click();
    await expect(page).toHaveURL(new RegExp(`/sales/${sale.id}`));
  });
}
