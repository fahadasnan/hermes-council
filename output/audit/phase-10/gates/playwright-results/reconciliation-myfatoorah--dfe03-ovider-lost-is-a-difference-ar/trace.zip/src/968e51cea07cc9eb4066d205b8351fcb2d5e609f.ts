import type { APIRequestContext } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { accessToken, admin, ANON_KEY, API, REST } from "./bookingFixtures";
import type { Shop } from "./checkoutFixtures";
import { expect } from "./fixtures";

// Online money at the desk (Epic 10.8) against the fixture-replay server, as
// in apps/booking/e2e/payments.ts: the shop links its own provider with
// fabricated sandbox keys, and the edge runtime's provider calls go to the
// replay server (PAYMENTS_FAKE_ROUTING), so no test reaches MyFatoorah or Tap.
// Each shop's scenario is keyed by its API key's last four characters. The
// scenarios follow the documented shapes in
// supabase/functions/_shared/payments/fixtures/<provider>/.

const REPLAY = "http://127.0.0.1:54399";

export const PROVIDERS = ["myfatoorah", "tap"] as const;
export type Provider = (typeof PROVIDERS)[number];

export type OnlineShop = Shop & { provider: Provider; key: string };

type Exchange = {
  provider: Provider;
  request: { method: string; path: string; capture?: Record<string, string> };
  response: { status: number; body: unknown };
  repeat?: boolean;
};

const ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789";
const scenarioKey = () => Array.from({ length: 4 }, () => ALPHABET[Math.floor(Math.random() * ALPHABET.length)]).join("");

async function serviceRpc<T>(request: APIRequestContext, fn: string, args: Record<string, unknown>): Promise<T> {
  const response = await request.post(`${REST}/rpc/${fn}`, {
    headers: admin,
    data: args,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return (await response.json()) as T;
}

async function asOwner(request: APIRequestContext, shop: Shop) {
  return {
    apikey: ANON_KEY,
    authorization: `Bearer ${await accessToken(request, shop.owner)}`,
  };
}

/**
 * The owner links `provider` with fabricated sandbox keys (sealed by the
 * payments function, as from Settings); the connection is marked tested and
 * active as the testkit does, and the branch takes KNET and card online
 * through it, with `patch` added to its online payment settings. By default
 * the account refunds cards and KNET by API.
 */
export async function connectProvider(
  request: APIRequestContext,
  shop: Shop,
  provider: Provider,
  patch: Record<string, unknown> = {},
  capabilities: string[] = ["knet", "cards", "refunds_api", "knet_refunds_api"],
): Promise<OnlineShop> {
  const key = scenarioKey();
  const headers = await asOwner(request, shop);
  const myfatoorah = provider === "myfatoorah";
  const saved = await request.post(functionUrl(API, "payments", "connection-save"), {
    headers,
    data: {
      tenant_id: shop.tenantId,
      provider,
      mode: "sandbox",
      account_country: myfatoorah ? "KW" : null,
      secret_key: myfatoorah ? `SK_KWT_fabricated-${key}` : `sk_test_e2e${key}`,
      webhook_secret: myfatoorah ? `fabricated-webhook-${key}` : null,
    },
  });
  expect(saved.ok(), await saved.text()).toBe(true);

  const owner = await request.get(`${REST}/memberships?tenant_id=eq.${shop.tenantId}&role=eq.tenant_owner&select=user_id`, {
    headers: admin,
  });
  const [ownerRow] = (await owner.json()) as { user_id: string }[];
  const scope = {
    p_actor: ownerRow!.user_id,
    p_tenant_id: shop.tenantId,
    p_provider: provider,
  };
  const { credentials_revision } = await serviceRpc<{
    credentials_revision: number;
  }>(request, "load_provider_connection", {
    p_tenant_id: shop.tenantId,
    p_provider: provider,
  });
  await serviceRpc(request, "record_provider_connection_test", {
    ...scope,
    p_revision: credentials_revision,
    p_result: "ok",
  });
  await serviceRpc(request, "update_provider_connection_checklist", {
    ...scope,
    p_steps: {},
    p_capabilities: capabilities,
  });
  await serviceRpc(request, "set_provider_connection_status", {
    ...scope,
    p_status: "active",
  });

  const settings = await request.post(`${REST}/rpc/update_branch_online_payment_settings`, {
    headers,
    data: {
      p_branch_id: shop.branchId,
      p_patch: { knet_provider: provider, card_provider: provider, ...patch },
    },
  });
  expect(settings.ok(), await settings.text()).toBe(true);
  return { ...shop, provider, key };
}

let sequence = 0;

/** One KNET charge the provider reports paid. */
function knetPaid(shop: OnlineShop): Exchange[] {
  if (shop.provider === "tap") {
    const id = `chg_TS05A10e2e${shop.key}${String(++sequence).padStart(6, "0")}`;
    const charge = (status: string) => ({
      id,
      object: "charge",
      live_mode: false,
      status,
      amount: "{{amount}}",
      currency: "KWD",
      metadata: { glowdesk_intent: "{{intent_id}}" },
      reference: { transaction: "{{intent_id}}", order: "{{intent_id}}" },
      source: { object: "source", id: "src_kw.knet" },
    });
    return [
      {
        provider: "tap",
        request: {
          method: "POST",
          path: "/v2/charges",
          capture: { intent_id: "/reference/transaction", amount: "/amount" },
        },
        response: {
          status: 200,
          body: {
            ...charge("INITIATED"),
            transaction: {
              amount: "{{amount}}",
              currency: "KWD",
              url: `${REPLAY}/__replay/hosted/tap/${shop.key}`,
            },
          },
        },
      },
      {
        provider: "tap",
        request: { method: "GET", path: `/v2/charges/${id}` },
        response: { status: 200, body: charge("CAPTURED") },
        repeat: true,
      },
      {
        provider: "tap",
        request: { method: "POST", path: "/v2/charges/list" },
        response: { status: 200, body: { object: "list", has_more: false, charges: [charge("CAPTURED")] } },
        repeat: true,
      },
    ];
  }
  const invoice = String(6_400_000 + Math.floor(Math.random() * 500_000) + ++sequence);
  const paymentId = `0707${invoice}0000${String(sequence).padStart(4, "0")}`;
  const ok = { IsSuccess: true, Message: "", ValidationErrors: null };
  return [
    {
      provider: "myfatoorah",
      request: {
        method: "POST",
        path: "/v3/payments",
        capture: {
          intent_id: "/Order/ExternalIdentifier",
          amount: "/Order/Amount",
        },
      },
      response: {
        status: 201,
        body: {
          ...ok,
          Data: {
            InvoiceId: invoice,
            PaymentId: null,
            PaymentURL: `${REPLAY}/__replay/hosted/myfatoorah/${shop.key}`,
            PaymentCompleted: false,
            TransactionDetails: null,
          },
        },
      },
    },
    {
      provider: "myfatoorah",
      request: { method: "POST", path: "/v2/GetPaymentStatus" },
      response: {
        status: 200,
        body: {
          ...ok,
          Data: {
            InvoiceId: Number(invoice),
            InvoiceStatus: "Paid",
            CustomerReference: "{{intent_id}}",
            InvoiceValue: "{{amount}}",
            InvoiceTransactions: [
              {
                PaymentGateway: "KNET",
                PaymentId: paymentId,
                TransactionStatus: "Succss",
                Card: null,
              },
            ],
          },
        },
      },
      repeat: true,
    },
    {
      provider: "myfatoorah",
      request: { method: "GET", path: `/v3/payments/${paymentId}` },
      response: {
        status: 200,
        body: {
          ...ok,
          Data: {
            Invoice: {
              Id: invoice,
              Status: "PAID",
              ExternalIdentifier: "{{intent_id}}",
            },
            Transaction: {
              Id: String(sequence).padStart(6, "0"),
              Status: "SUCCESS",
              PaymentMethod: "KNET",
              PaymentId: paymentId,
              Error: { Code: "", Message: "" },
              Card: null,
            },
            Amount: {
              BaseCurrency: "KWD",
              ValueInBaseCurrency: "{{amount}}",
              DisplayCurrency: "KWD",
              ValueInDisplayCurrency: "{{amount}}",
              PayCurrency: "KWD",
              ValueInPayCurrency: "{{amount}}",
            },
          },
        },
      },
      repeat: true,
    },
  ];
}

/** One refund the provider accepts and still reports pending (MyFatoorah's finance review, Tap's PENDING). */
function refundPending(shop: OnlineShop): Exchange[] {
  if (shop.provider === "tap") {
    const id = `re_TS05A10e2e${shop.key}${String(++sequence).padStart(6, "0")}`;
    const refund = {
      id,
      object: "refund",
      live_mode: false,
      amount: "{{amount}}",
      currency: "KWD",
      charge_id: "{{charge_id}}",
      status: "PENDING",
      reference: { merchant: "{{refund_intent}}" },
      metadata: { glowdesk_refund_intent: "{{refund_intent}}" },
      response: { code: "100", message: "Pending" },
    };
    return [
      {
        provider: "tap",
        request: {
          method: "POST",
          path: "/v2/refunds",
          capture: {
            amount: "/amount",
            charge_id: "/charge_id",
            refund_intent: "/reference/merchant",
          },
        },
        response: { status: 200, body: refund },
      },
      {
        provider: "tap",
        request: { method: "GET", path: `/v2/refunds/${id}` },
        response: { status: 200, body: refund },
        repeat: true,
      },
    ];
  }
  const refundId = 270_000 + ++sequence;
  const ok = { IsSuccess: true, Message: "", ValidationErrors: null };
  return [
    {
      provider: "myfatoorah",
      request: {
        method: "POST",
        path: "/v2/MakeRefund",
        capture: {
          invoice: "/Key",
          amount: "/Amount",
          refund_intent: "/ExternalIdentifier",
        },
      },
      response: {
        status: 200,
        body: {
          ...ok,
          Data: {
            Key: "{{invoice}}",
            RefundId: refundId,
            RefundReference: `2026${String(refundId).padStart(6, "0")}`,
            RefundInvoiceId: "{{invoice}}",
            Amount: "{{amount}}",
            Comment: "",
            ExternalIdentifier: "{{refund_intent}}",
          },
        },
      },
    },
    {
      provider: "myfatoorah",
      request: { method: "POST", path: "/v2/GetRefundStatus" },
      response: {
        status: 200,
        body: {
          ...ok,
          Data: {
            RefundStatusResult: [
              {
                RefundId: refundId,
                RefundStatus: "Pending",
                InvoiceId: "{{invoice}}",
                Amount: "{{amount}}",
                RefundReference: `2026${String(refundId).padStart(6, "0")}`,
                RefundAmount: "{{amount}}",
                ExternalIdentifier: "{{refund_intent}}",
                RRN: null,
                BaseCurrency: "KWD",
              },
            ],
          },
        },
      },
      repeat: true,
    },
  ];
}

async function loadScenario(request: APIRequestContext, shop: OnlineShop, exchanges: Exchange[]): Promise<void> {
  const response = await request.post(`${REPLAY}/__replay/scenario`, {
    data: { exchanges, key: shop.key },
  });
  expect(response.ok(), await response.text()).toBe(true);
}

/** The provider's reference for the sale's online charge. */
export async function chargeReference(request: APIRequestContext, saleId: string): Promise<string> {
  const response = await request.get(`${REST}/payment_intents?sale_id=eq.${saleId}&kind=eq.charge&select=gateway_reference`, {
    headers: admin,
  });
  expect(response.ok(), await response.text()).toBe(true);
  const [intent] = (await response.json()) as { gateway_reference: string | null }[];
  expect(intent?.gateway_reference).toBeTruthy();
  return intent!.gateway_reference!;
}

/**
 * Loads a scenario where the provider has no record of the charge `reference`
 * (404). Tap's list of the day's charges then holds one charge of 3.500 that
 * GlowDesk never made.
 */
export async function replayChargeLost(request: APIRequestContext, shop: OnlineShop, reference: string): Promise<void> {
  if (shop.provider === "myfatoorah") {
    await loadScenario(request, shop, [
      {
        provider: "myfatoorah",
        request: { method: "POST", path: "/v2/GetPaymentStatus" },
        response: { status: 404, body: { IsSuccess: false, Message: "Invoice not found", ValidationErrors: null, Data: null } },
        repeat: true,
      },
    ]);
    return;
  }
  const foreign = {
    id: `chg_TS05A10e2e${shop.key}${String(++sequence).padStart(6, "0")}`,
    object: "charge",
    live_mode: false,
    status: "CAPTURED",
    amount: 3.5,
    currency: "KWD",
    metadata: {},
    reference: { transaction: "pos-0001" },
    source: { object: "source", id: "src_kw.knet" },
  };
  await loadScenario(request, shop, [
    {
      provider: "tap",
      request: { method: "POST", path: "/v2/charges/list" },
      response: { status: 200, body: { object: "list", has_more: false, charges: [foreign] } },
      repeat: true,
    },
    {
      provider: "tap",
      request: { method: "GET", path: `/v2/charges/${reference}` },
      response: { status: 404, body: { errors: [{ code: "1108", description: "Charge not found" }] } },
      repeat: true,
    },
  ]);
}

/** Loads the shop's refund scenario: the next refund is accepted and stays pending. */
export async function replayRefund(request: APIRequestContext, shop: OnlineShop): Promise<void> {
  await loadScenario(request, shop, refundPending(shop));
}

export type ReplayedCall = {
  provider: string;
  method: string;
  path: string;
  matched: boolean;
};

/** The provider calls the shop's scenarios saw. */
export async function replayedCalls(request: APIRequestContext, shop: OnlineShop): Promise<ReplayedCall[]> {
  const response = await request.get(`${REPLAY}/__replay/requests`, {
    params: { key: shop.key },
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { requests: ReplayedCall[] }).requests;
}

/**
 * The client pays the sale's balance by KNET from a payment link: the desk
 * sends the link (as the owner, without the email), the link page starts the
 * payment, and reading the link again settles it once the provider says paid.
 */
export async function payByLink(request: APIRequestContext, shop: OnlineShop, saleId: string, dueMinor: number): Promise<void> {
  const headers = await asOwner(request, shop);
  const link = await request.post(functionUrl(API, "checkout", "pay-link"), {
    headers: { ...headers, "idempotency-key": crypto.randomUUID() },
    data: {
      tenant_id: shop.tenantId,
      sale_id: saleId,
      expected_due_minor: dueMinor,
      send_email: false,
    },
  });
  expect(link.status(), await link.text()).toBe(201);
  const { url } = ((await link.json()) as { data: { url: string } }).data;
  const token = new URL(url).pathname.split("/").pop()!;

  await loadScenario(request, shop, knetPaid(shop));
  // The client is a visitor of her own, so the per-IP link-pay quota never carries between tests.
  const octet = () => Math.floor(Math.random() * 250) + 1;
  const visitor = { apikey: ANON_KEY, authorization: `Bearer ${ANON_KEY}`, "x-forwarded-for": `198.19.${octet()}.${octet()}` };
  const started = await request.post(functionUrl(API, "online-booking", "link-pay"), {
    headers: { ...visitor, "idempotency-key": crypto.randomUUID() },
    data: { token, method: "knet" },
  });
  expect(started.ok(), await started.text()).toBe(true);
  await expect
    .poll(async () => {
      const read = await request.get(`${functionUrl(API, "online-booking", "link")}?${new URLSearchParams({ token })}`, {
        headers: visitor,
      });
      expect(read.ok(), await read.text()).toBe(true);
      return ((await read.json()) as { data: { status: string } }).data.status;
    })
    .toBe("paid");
}
