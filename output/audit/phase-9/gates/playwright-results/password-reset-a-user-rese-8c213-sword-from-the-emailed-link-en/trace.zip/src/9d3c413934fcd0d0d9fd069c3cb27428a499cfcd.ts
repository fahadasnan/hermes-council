import { expect, expectDocumentLocale, signIn, signOut, test } from "./fixtures";
import { deleteMail, waitForAuthLink } from "./mailpit";

test("a user resets a forgotten password from the emailed link", async ({ page, request, s, appLocale }) => {
  // One user per language so the two projects can run in parallel.
  const email = `reset-${appLocale}@spacorner.test`;
  const newPassword = `Glow-${Date.now()}`;
  await deleteMail(request, email);

  await page.goto("/login");
  await page.getByRole("link", { name: s.forgotLink }).click();
  await expect(page).toHaveURL(/\/forgot-password$/);
  await page.getByLabel(s.email).fill(email);
  await page.getByRole("button", { name: s.sendResetLink }).click();
  await expect(page.getByText(s.resetSent)).toBeVisible();

  const link = await waitForAuthLink(request, email);
  await page.goto(link);

  await expect(page).toHaveURL(/\/reset-password/);
  await expectDocumentLocale(page, s);
  await page.getByLabel(s.newPassword, { exact: true }).fill(newPassword);
  await page.getByLabel(s.confirmPassword, { exact: true }).fill(newPassword);
  await page.getByRole("button", { name: s.savePassword }).click();

  await expect(page).toHaveURL(/\/\?branch=[\w-]+$/);
  await signOut(page, s);

  await signIn(page, s, email, newPassword);
  await expect(page).toHaveURL(/\/\?branch=[\w-]+$/);
});
