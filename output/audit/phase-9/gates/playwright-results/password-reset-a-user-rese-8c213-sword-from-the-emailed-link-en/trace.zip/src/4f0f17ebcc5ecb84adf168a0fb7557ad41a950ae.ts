import type { APIRequestContext } from "@playwright/test";
import { expect } from "./fixtures";

// Local Supabase delivers auth email to Mailpit (supabase/config.toml).
const MAILPIT = "http://127.0.0.1:54324";
const VERIFY_LINK = /http:\/\/127\.0\.0\.1:54321\/auth\/v1\/verify\?[^\s)"<>]+/;

export async function deleteMail(request: APIRequestContext, email: string) {
  await request.delete(`${MAILPIT}/api/v1/search`, { params: { query: `to:"${email}"` } });
}

/** Subjects of every email Mailpit holds for `email`, newest first. */
export async function subjectsTo(request: APIRequestContext, email: string): Promise<string[]> {
  const response = await request.get(`${MAILPIT}/api/v1/search`, { params: { query: `to:"${email}"` } });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { messages: { Subject: string }[] }).messages.map((message) => message.Subject);
}

/** How many emails Mailpit holds for `email`. */
export async function mailCount(request: APIRequestContext, email: string): Promise<number> {
  return (await subjectsTo(request, email)).length;
}

/** The auth verify link (recovery or invite) from the newest email to `email`. */
export async function waitForAuthLink(request: APIRequestContext, email: string): Promise<string> {
  let messageId: string | undefined;
  await expect
    .poll(
      async () => {
        const response = await request.get(`${MAILPIT}/api/v1/search`, { params: { query: `to:"${email}"` } });
        const body = (await response.json()) as { messages: Array<{ ID: string }> };
        messageId = body.messages[0]?.ID;
        return messageId;
      },
      { timeout: 15_000 },
    )
    .toBeTruthy();

  const message = (await (await request.get(`${MAILPIT}/api/v1/message/${messageId}`)).json()) as { Text: string };
  const link = VERIFY_LINK.exec(message.Text)?.[0];
  expect(link, "auth link in the email").toBeTruthy();
  return link!.replaceAll("&amp;", "&");
}
