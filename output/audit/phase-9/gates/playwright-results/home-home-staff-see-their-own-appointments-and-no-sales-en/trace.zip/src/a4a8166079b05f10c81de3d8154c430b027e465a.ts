import type { APIRequestContext, Locator } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { accessToken, admin, ANON_KEY, API, insert, kuwait, REST } from "./bookingFixtures";
import { addMember, createSale, freshShop, type Shop } from "./checkoutFixtures";
import { expect, PASSWORD } from "./fixtures";

// Phase 7 report fixtures: a tenant of its own with two Kuwait branches
// (Main and Second), so every figure on a report or home screen is the
// test's. Visits and sales go through the bookings and checkout functions as
// real logins; the service key only provisions and configures.

export type ReportShop = Shop & {
  secondBranchId: string;
  manager: string;
  reception: string;
  /** A staff login with a staff profile at Main. */
  staffLogin: string;
  loginStaffId: string;
  /** Staff without a login: one more at Main, one at Second. */
  mainStaffId: string;
  secondStaffId: string;
  serviceId: string;
  clientId: string;
  reasonId: string;
};

const DAY_HOURS = Array.from({ length: 7 }, (_, day) => ({ day_of_week: day, opens_at: "00:00", closes_at: "23:59" }));

/** Kuwait's calendar date and minute of the day now. */
export function kuwaitNow(): { day: string; minute: number } {
  const local = new Date(Date.now() + 3 * 3_600_000);
  return { day: local.toISOString().slice(0, 10), minute: local.getUTCHours() * 60 + local.getUTCMinutes() };
}

export const clock = (minute: number) => `${String(Math.floor(minute / 60)).padStart(2, "0")}:${String(minute % 60).padStart(2, "0")}`;

async function call(request: APIRequestContext, fn: "bookings" | "checkout", actor: string, route: string, data: unknown) {
  const response = await request.post(functionUrl(API, fn, route), {
    headers: { apikey: ANON_KEY, authorization: `Bearer ${await accessToken(request, actor)}`, "idempotency-key": crypto.randomUUID() },
    data,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { data: Record<string, unknown> }).data;
}

async function login(request: APIRequestContext, email: string): Promise<string> {
  const created = await request.post(`${API}/auth/v1/admin/users`, { headers: admin, data: { email, password: PASSWORD, email_confirm: true } });
  expect(created.ok(), await created.text()).toBe(true);
  return ((await created.json()) as { id: string }).id;
}

async function openAllDay(request: APIRequestContext, branchId: string) {
  const response = await request.patch(`${REST}/branch_opening_hours?branch_id=eq.${branchId}`, {
    headers: admin,
    data: { opens_at: "00:00", closes_at: "23:59" },
  });
  expect(response.ok(), await response.text()).toBe(true);
}

export async function reportShop(request: APIRequestContext, label: string): Promise<ReportShop> {
  const shop = await freshShop(request, label);
  const tenant = { tenant_id: shop.tenantId };
  const second = await request.post(`${REST}/rpc/provision_branch`, {
    headers: admin,
    data: {
      p_tenant_id: shop.tenantId,
      p_branch: { name_en: `Second ${shop.id}`, name_ar: `الثاني ${shop.id}`, invoice_prefix: "SEC" },
      p_hours: DAY_HOURS,
      p_requested_by: "e2e report fixtures",
    },
  });
  expect(second.ok(), await second.text()).toBe(true);
  const secondBranchId = ((await second.json()) as { branch_id: string }).branch_id;
  await openAllDay(request, shop.branchId);

  const manager = await addMember(request, shop, "branch_manager");
  const reception = await addMember(request, shop, "receptionist");
  const staffLogin = `staff-${shop.id}@checkout.test`;
  const staffUserId = await login(request, staffLogin);
  await insert(request, "memberships", { ...tenant, user_id: staffUserId, role: "staff", branch_id: shop.branchId });

  const [category] = await insert(request, "service_categories", { ...tenant, name_en: "Treatments" });
  const [service] = await insert(request, "services", {
    ...tenant,
    category_id: category!.id,
    name_en: `Massage ${shop.id}`,
    name_ar: `مساج ${shop.id}`,
    duration_minutes: 30,
    price_minor: 10_000,
  });
  const staff = async (nameEn: string, nameAr: string, branchId: string, userId?: string) => {
    const [row] = await insert(request, "staff_members", {
      ...tenant,
      full_name_en: `${nameEn} ${shop.id}`,
      full_name_ar: `${nameAr} ${shop.id}`,
      ...(userId ? { user_id: userId } : {}),
    });
    await insert(request, "staff_branch_assignments", { ...tenant, staff_id: row!.id, branch_id: branchId, is_default: true });
    await insert(request, "service_staff", { ...tenant, service_id: service!.id, branch_id: branchId, staff_id: row!.id });
    return row!.id;
  };
  const loginStaffId = await staff("Huda", "هدى", shop.branchId, staffUserId);
  const mainStaffId = await staff("Mariam", "مريم", shop.branchId);
  const secondStaffId = await staff("Dana", "دانة", secondBranchId);
  const { day } = kuwaitNow();
  for (const [staffId, branchId] of [
    [loginStaffId, shop.branchId],
    [mainStaffId, shop.branchId],
    [secondStaffId, secondBranchId],
  ] as const) {
    await insert(request, "shifts", { ...tenant, staff_id: staffId, branch_id: branchId, starts_at: kuwait(day, "00:00"), ends_at: kuwait(day, "23:59") });
  }
  const [client] = await insert(request, "clients", { ...tenant, first_name: "Noura", last_name: shop.id, first_name_alt: "نورة", last_name_alt: `الصباح ${shop.id}` });

  const reasons = await request.get(`${REST}/cancellation_reasons?tenant_id=eq.${shop.tenantId}&is_active=is.true&select=id&limit=1`, { headers: admin });
  expect(reasons.ok(), await reasons.text()).toBe(true);
  const [reason] = (await reasons.json()) as { id: string }[];
  const reasonId = reason?.id ?? (await insert(request, "cancellation_reasons", { ...tenant, name_en: "Client asked", name_ar: "بطلب العميل" }))[0]!.id;

  return {
    ...shop,
    secondBranchId,
    manager,
    reception,
    staffLogin,
    loginStaffId,
    mainStaffId,
    secondStaffId,
    serviceId: service!.id,
    clientId: client!.id,
    reasonId,
  };
}

export type BookedVisit = { id: string; ref: string };

/** A 30-minute visit booked by the shop's owner at `branchId`, Kuwait wall-clock `time` on `day`. */
export async function bookVisit(
  request: APIRequestContext,
  shop: ReportShop,
  visit: { branchId: string; staffId: string; day: string; time: string; client: boolean },
): Promise<BookedVisit> {
  const data = await call(request, "bookings", shop.owner, "create", {
    tenant_id: shop.tenantId,
    branch_id: visit.branchId,
    client_id: visit.client ? shop.clientId : null,
    items: [{ service_id: shop.serviceId, staff_id: visit.staffId, starts_at: kuwait(visit.day, visit.time) }],
  });
  return { id: String(data.id), ref: String(data.ref_number) };
}

export async function arriveVisit(request: APIRequestContext, shop: ReportShop, appointmentId: string): Promise<void> {
  await call(request, "bookings", shop.owner, "set-status", { tenant_id: shop.tenantId, appointment_id: appointmentId, status: "arrived" });
}

export async function cancelVisit(request: APIRequestContext, shop: ReportShop, appointmentId: string): Promise<void> {
  await call(request, "bookings", shop.owner, "cancel", { tenant_id: shop.tenantId, appointment_id: appointmentId, cancellation_reason_id: shop.reasonId });
}

/** A paid walk-in sale of one zero-rated custom item at `branchId`, by a terminal (no register needed). */
export async function knetSale(
  request: APIRequestContext,
  shop: ReportShop,
  branchId: string,
  amountMinor: number,
  method: "knet_terminal" | "card_terminal" = "knet_terminal",
) {
  return createSale(request, shop.owner, {
    tenant_id: shop.tenantId,
    branch_id: branchId,
    lines: [{ type: "manual_item", name_en: `Voucher ${shop.id}`, unit_price_minor: amountMinor }],
    tips: [],
    payments: [{ method, amount_minor: amountMinor }],
    expected: { total_minor: amountMinor, tip_minor: 0, grand_total_minor: amountMinor },
  });
}

/** The value of the `dl` figure labelled `label` in `region`: home tiles, report totals, the daily summary. */
export const figure = (region: Locator, label: string) =>
  region.locator("dl > div").filter({ has: region.page().getByText(label, { exact: true }) }).locator("dd").first();

/** A report RPC's JSON, as `actor` gets it. */
export async function reportJson<T>(request: APIRequestContext, actor: string, fn: string, args: Record<string, unknown>): Promise<T> {
  const response = await request.post(`${REST}/rpc/${fn}`, {
    headers: { apikey: ANON_KEY, authorization: `Bearer ${await accessToken(request, actor)}` },
    data: args,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return (await response.json()) as T;
}
