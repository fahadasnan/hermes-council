import type { APIRequestContext, Page } from "@playwright/test";
import { expect, signIn, test } from "./fixtures";
import { bookVisit, cancelVisit, clock, figure, knetSale, kuwaitNow, reportShop, type BookedVisit, type ReportShop } from "./reportFixtures";
import type { Strings } from "./strings";

// US-DASH-1 (7.2-T2) in a two-branch shop of its own, later today in Kuwait:
//   Main:   A (the staff login, client), B (the staff login, cancelled), C (another staff member, walk-in); a 20.000 sale
//   Second: D (client); a 5.000 sale
// Main: 3 appointments, 1 cancelled → 2; Second: 1; every branch: 3, sales 2 / 25.000.
// The staff login sees only A and B: 1 appointment, 1 cancelled, no sales.

type Day = { shop: ReportShop; visits: Record<"a" | "b" | "c" | "d", BookedVisit> };

async function today(request: APIRequestContext, label: string): Promise<Day> {
  const { day, minute } = kuwaitNow();
  const slot = Math.ceil((minute + 20) / 15) * 15;
  const shop = await reportShop(request, label);
  const a = await bookVisit(request, shop, { branchId: shop.branchId, staffId: shop.loginStaffId, day, time: clock(slot), client: true });
  const b = await bookVisit(request, shop, { branchId: shop.branchId, staffId: shop.loginStaffId, day, time: clock(slot + 30), client: true });
  const c = await bookVisit(request, shop, { branchId: shop.branchId, staffId: shop.mainStaffId, day, time: clock(slot + 30), client: false });
  const d = await bookVisit(request, shop, { branchId: shop.secondBranchId, staffId: shop.secondStaffId, day, time: clock(slot), client: true });
  await cancelVisit(request, shop, b.id);
  await knetSale(request, shop, shop.branchId, 20_000);
  await knetSale(request, shop, shop.secondBranchId, 5_000);
  return { shop, visits: { a, b, c, d } };
}

async function openHome(page: Page, s: Strings, email: string, branch?: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
  if (branch) await page.goto(`/?branch=${branch}`);
}

const upcomingOf = (page: Page, s: Strings) => page.getByRole("list", { name: s.comingUpToday }).getByRole("listitem");

test.describe("home", () => {
  test.skip(kuwaitNow().minute > 22 * 60 + 30, "needs the visits to start later today in Kuwait");

  test("the owner's tiles add up every branch and one branch, and match the daily summary", async ({ page, request, s }) => {
    const { shop, visits } = await today(request, "home-owner");
    await openHome(page, s, shop.owner, "all");
    const region = page.getByRole("region", { name: s.today, exact: true });
    await expect(figure(region, s.appointments)).toHaveText("3");
    await expect(figure(region, s.cancelled)).toHaveText("1");
    await expect(figure(region, s.salesTitle)).toHaveText("2");
    await expect(figure(region, s.salesTotal)).toContainText("25.000");
    await expect(upcomingOf(page, s)).toHaveCount(3);
    for (const visit of [visits.a, visits.c, visits.d]) await expect(upcomingOf(page, s).filter({ hasText: visit.ref })).toHaveCount(1);
    await expect(upcomingOf(page, s).filter({ hasText: visits.b.ref })).toHaveCount(0);

    await page.goto(`/?branch=${shop.branchId}`);
    await expect(figure(region, s.appointments)).toHaveText("2");
    await expect(figure(region, s.salesTitle)).toHaveText("1");
    const total = await figure(region, s.salesTotal).innerText();
    expect(total).toContain("20.000");
    await expect(upcomingOf(page, s)).toHaveCount(2);

    await page.goto(`/sales/summary?branch=${shop.branchId}`);
    await expect(figure(page.getByRole("region", { name: s.salesOnThisDay }), s.salesTotal)).toHaveText(total);
  });

  test("the upcoming visit opens in the calendar", async ({ page, request, s }) => {
    const { shop, visits } = await today(request, "home-link");
    await openHome(page, s, shop.owner, shop.branchId);
    await upcomingOf(page, s).filter({ hasText: visits.a.ref }).getByRole("link").click();
    await expect(page).toHaveURL(/\/calendar\?/);
    await expect(page.getByRole("dialog")).toContainText(visits.a.ref);
  });

  test("the manager and the receptionist see their branch with its sales", async ({ page, request, s }) => {
    const { shop } = await today(request, "home-desk");
    for (const email of [shop.manager, shop.reception]) {
      await openHome(page, s, email);
      const region = page.getByRole("region", { name: s.today, exact: true });
      await expect(figure(region, s.appointments)).toHaveText("2");
      await expect(figure(region, s.salesTitle)).toHaveText("1");
      await expect(figure(region, s.salesTotal)).toContainText("20.000");
      await expect(upcomingOf(page, s)).toHaveCount(2);
      await page.context().clearCookies();
      await page.evaluate(() => window.localStorage.clear());
    }
  });

  test("staff see their own appointments and no sales", async ({ page, request, s }) => {
    const { shop, visits } = await today(request, "home-staff");
    await openHome(page, s, shop.staffLogin);
    const region = page.getByRole("region", { name: s.yourAppointmentsToday });
    await expect(figure(region, s.appointments)).toHaveText("1");
    await expect(figure(region, s.cancelled)).toHaveText("1");
    await expect(region.getByText(s.salesTitle, { exact: true })).toHaveCount(0);
    await expect(upcomingOf(page, s)).toHaveCount(1);
    await expect(upcomingOf(page, s).first()).toContainText(visits.a.ref);
    await expect(upcomingOf(page, s).getByRole("link")).toHaveCount(0);
  });
});
