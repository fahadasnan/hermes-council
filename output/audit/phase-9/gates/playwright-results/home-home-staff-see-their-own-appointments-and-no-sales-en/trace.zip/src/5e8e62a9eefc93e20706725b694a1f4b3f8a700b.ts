import type { APIRequestContext, Page } from "@playwright/test";
import { functionUrl } from "@repo/api";
import type { SaleCreateInput } from "@repo/validation";
import { accessToken, admin, ANON_KEY, API, insert, kuwait, REST, SETUP_TENANT } from "./bookingFixtures";
import { expect, PASSWORD, signIn } from "./fixtures";
import type { Strings } from "./strings";

// Phase 6 checkout fixtures. Money only moves through the checkout function
// as a real login (ADR-28); the service key reads results back and sets up
// branch config, never sales, payments or register rows. The en and ar
// projects check out at different Setup Studio branches (Hawally, Jahra) so
// they never share a register; register-day and refund/void journeys get a
// tenant of their own from `freshShop`.

type Envelope<T> = { data: T } | { error: { code: string; message: string; details?: Record<string, unknown> } };

async function post(request: APIRequestContext, actor: string, route: string, data: unknown) {
  return request.post(functionUrl(API, "checkout", route), {
    headers: {
      apikey: ANON_KEY,
      authorization: `Bearer ${await accessToken(request, actor)}`,
      "idempotency-key": crypto.randomUUID(),
    },
    data,
  });
}

async function attempt<T>(request: APIRequestContext, actor: string, route: string, data: unknown) {
  const response = await post(request, actor, route, data);
  return { status: response.status(), body: (await response.json()) as Envelope<T> };
}

const detailOf = (body: Envelope<unknown>, key: string) => ("error" in body ? body.error.details?.[key] : undefined);
const reasonOf = (body: Envelope<unknown>) => detailOf(body, "reason");

/** Turns tips on at a branch (Setup Studio branches start with them off). */
export async function enableTips(request: APIRequestContext, branchId: string, presets = [10, 15, 20]): Promise<void> {
  const response = await request.patch(`${REST}/branches?id=eq.${branchId}`, {
    headers: admin,
    data: { tips_enabled: true, tip_presets_percent: presets },
  });
  expect(response.ok(), await response.text()).toBe(true);
}

/** The branch's open register session, opening one as `actor` when there is none. */
export async function ensureRegisterOpen(
  request: APIRequestContext,
  actor: string,
  branchId: string,
  opts: { tenantId?: string; openingCashMinor?: number } = {},
): Promise<string> {
  const { status, body } = await attempt<{ id: string }>(request, actor, "register-open", {
    tenant_id: opts.tenantId ?? SETUP_TENANT,
    branch_id: branchId,
    opening_cash_minor: opts.openingCashMinor ?? 0,
  });
  if (status === 201 && "data" in body) return body.data.id;
  expect(reasonOf(body), JSON.stringify(body)).toBe("register_already_open");
  return String(detailOf(body, "session_id"));
}

/**
 * Closes a session as `actor` (an owner or manager). The function wants the
 * expected cash the closer saw; a first call with none learns it from the
 * register_changed refusal. Counted defaults to expected: no difference.
 */
export async function closeRegister(
  request: APIRequestContext,
  actor: string,
  sessionId: string,
  opts: { tenantId?: string; countedCashMinor?: number } = {},
): Promise<void> {
  const close = (expected: number) =>
    attempt(request, actor, "register-close", {
      tenant_id: opts.tenantId ?? SETUP_TENANT,
      session_id: sessionId,
      counted_cash_minor: opts.countedCashMinor ?? Math.max(expected, 0),
      expected_cash_minor: expected,
    });
  const first = await close(-1);
  if (first.status === 200) return;
  expect(reasonOf(first.body), JSON.stringify(first.body)).toBe("register_changed");
  const expected = Number(detailOf(first.body, "expected_cash_minor"));
  const second = await close(expected);
  expect(second.status, JSON.stringify(second.body)).toBe(200);
}

/** POST /checkout/register-close as `actor`, whatever the answer. */
export function attemptCloseRegister(
  request: APIRequestContext,
  actor: string,
  input: { tenantId: string; sessionId: string; countedCashMinor: number; expectedCashMinor: number },
) {
  return attempt(request, actor, "register-close", {
    tenant_id: input.tenantId,
    session_id: input.sessionId,
    counted_cash_minor: input.countedCashMinor,
    expected_cash_minor: input.expectedCashMinor,
  });
}

/** Closes every session left open at Setup Studio (an interrupted run), counted = expected, as the owner. */
export async function closeLeftoverRegisters(request: APIRequestContext): Promise<number> {
  const open = await request.get(`${REST}/register_sessions?tenant_id=eq.${SETUP_TENANT}&closed_at=is.null&select=id`, { headers: admin });
  expect(open.ok(), await open.text()).toBe(true);
  const sessions = (await open.json()) as { id: string }[];
  for (const session of sessions) await closeRegister(request, "setup-owner@spacorner.test", session.id);
  return sessions.length;
}

export type CreatedSale = { id: string; invoice_number: string; status: string };

/** POST /checkout/create-sale as `actor`; the caller sends the expected totals it computed. */
export async function createSale(request: APIRequestContext, actor: string, input: SaleCreateInput): Promise<CreatedSale> {
  const { status, body } = await attempt<CreatedSale>(request, actor, "create-sale", input);
  expect(status, JSON.stringify(body)).toBe(201);
  return (body as { data: CreatedSale }).data;
}

/** POST /checkout/create-sale as `actor`, whatever the answer. */
export function attemptSale(request: APIRequestContext, actor: string, input: SaleCreateInput) {
  return attempt<CreatedSale>(request, actor, "create-sale", input);
}

/** A walk-in sale of one custom item at `shop` (its default tax rate is zero-rated, so total = price). */
export function walkInSale(shop: Shop, priceMinor: number, payments: SaleCreateInput["payments"]): SaleCreateInput {
  return {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    lines: [{ type: "manual_item", name_en: `Gift voucher ${shop.id}`, unit_price_minor: priceMinor }],
    tips: [],
    payments,
    expected: { total_minor: priceMinor, tip_minor: 0, grand_total_minor: priceMinor },
  };
}

export type StoredRegisterSession = {
  id: string;
  closed_at: string | null;
  opening_cash_minor: number;
  expected_cash_minor: number | null;
  counted_cash_minor: number | null;
  difference_minor: number | null;
  close_note: string | null;
};

/** A branch's register sessions as stored (service read), oldest first. */
export async function registerSessionsOf(request: APIRequestContext, branchId: string): Promise<StoredRegisterSession[]> {
  const select = "id,closed_at,opening_cash_minor,expected_cash_minor,counted_cash_minor,difference_minor,close_note";
  const response = await request.get(`${REST}/register_sessions?branch_id=eq.${branchId}&select=${select}&order=opened_at`, { headers: admin });
  expect(response.ok(), await response.text()).toBe(true);
  return (await response.json()) as StoredRegisterSession[];
}

/** POST /checkout/refund as `actor`, whatever the answer. */
export function attemptRefund(request: APIRequestContext, actor: string, input: { tenantId?: string; paymentId: string; reason: string }) {
  return attempt(request, actor, "refund", { tenant_id: input.tenantId ?? SETUP_TENANT, payment_id: input.paymentId, reason: input.reason });
}

/** POST /checkout/void as `actor`, whatever the answer. */
export function attemptVoid(request: APIRequestContext, actor: string, input: { tenantId?: string; saleId: string; reason: string }) {
  return attempt(request, actor, "void", { tenant_id: input.tenantId ?? SETUP_TENANT, sale_id: input.saleId, reason: input.reason });
}

const TOTALS = [
  "subtotal_minor",
  "line_discount_minor",
  "sale_discount_fixed_minor",
  "sale_discount_percent_bp",
  "sale_discount_minor",
  "tax_minor",
  "total_minor",
  "tip_minor",
  "grand_total_minor",
  "paid_minor",
  "due_minor",
] as const;

export type StoredSale = {
  id: string;
  invoice_number: string;
  status: string;
  appointment_id: string | null;
  client_id: string | null;
  totals: Record<(typeof TOTALS)[number], number>;
  payments: { payment_type: string; payment_method: string; amount_minor: number; register_session_id: string | null }[];
};

/**
 * Sales as stored (service read), oldest first: by id, by appointment, or by
 * a line's English or Arabic name (a quick sale's custom item).
 */
export async function salesOf(
  request: APIRequestContext,
  by: { id: string } | { appointmentId: string } | { itemName: string },
): Promise<StoredSale[]> {
  const filter =
    "id" in by
      ? `id=eq.${by.id}`
      : "appointmentId" in by
        ? `appointment_id=eq.${by.appointmentId}`
        : `items.or=${encodeURIComponent(`(name_en.eq."${by.itemName}",name_ar.eq."${by.itemName}")`)}`;
  const select = `id,invoice_number,status,appointment_id,client_id,${TOTALS.join(",")},items:sale_items!inner(name_en,name_ar),payments(payment_type,payment_method,amount_minor,register_session_id,created_at)`;
  const response = await request.get(`${REST}/sales?${filter}&select=${select}&order=created_at`, { headers: admin });
  expect(response.ok(), await response.text()).toBe(true);
  const rows = (await response.json()) as (Record<string, unknown> & { payments: (StoredSale["payments"][number] & { created_at: string })[] })[];
  return rows.map((row) => ({
    id: String(row.id),
    invoice_number: String(row.invoice_number),
    status: String(row.status),
    appointment_id: (row.appointment_id as string | null) ?? null,
    client_id: (row.client_id as string | null) ?? null,
    totals: Object.fromEntries(TOTALS.map((key) => [key, Number(row[key])])) as StoredSale["totals"],
    payments: [...row.payments]
      .sort((a, b) => a.created_at.localeCompare(b.created_at))
      .map(({ payment_type, payment_method, amount_minor, register_session_id }) => ({
        payment_type,
        payment_method,
        amount_minor: Number(amount_minor),
        register_session_id,
      })),
  }));
}

/** The one sale matching `by`; fails when there are none or several. */
export async function saleOf(request: APIRequestContext, by: Parameters<typeof salesOf>[1]): Promise<StoredSale> {
  const sales = await salesOf(request, by);
  expect(sales, `sales for ${JSON.stringify(by)}`).toHaveLength(1);
  return sales[0]!;
}

export type Shop = { id: string; tenantId: string; branchId: string; owner: string };

/**
 * A tenant of its own, provisioned like a real sign-up (`provision_tenant`)
 * with a fresh owner login (seed password) and one branch open every day.
 */
export async function freshShop(request: APIRequestContext, label: string): Promise<Shop> {
  const id = `${label}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  const owner = `owner-${id}@checkout.test`;
  const created = await request.post(`${API}/auth/v1/admin/users`, {
    headers: admin,
    data: { email: owner, password: PASSWORD, email_confirm: true },
  });
  expect(created.ok(), await created.text()).toBe(true);
  const ownerId = ((await created.json()) as { id: string }).id;
  const provisioned = await request.post(`${REST}/rpc/provision_tenant`, {
    headers: admin,
    data: {
      p_tenant: { name_en: `Checkout ${id}`, name_ar: `محل ${id}`, slug: `checkout-${id}` },
      p_branch: {
        name_en: `Main ${id}`,
        name_ar: `الرئيسي ${id}`,
        invoice_prefix: "INV",
        hours: Array.from({ length: 7 }, (_, day) => ({ day_of_week: day, opens_at: "09:00", closes_at: "21:00" })),
      },
      p_owner_id: ownerId,
      p_requested_by: "e2e checkout fixtures",
    },
  });
  expect(provisioned.ok(), await provisioned.text()).toBe(true);
  const { tenant_id: tenantId, branch_id: branchId } = (await provisioned.json()) as { tenant_id: string; branch_id: string };
  return { id, tenantId, branchId, owner };
}

/** A manager or receptionist login at the shop's branch (seed password). */
export async function addMember(request: APIRequestContext, shop: Shop, role: "branch_manager" | "receptionist"): Promise<string> {
  const email = `${role === "branch_manager" ? "manager" : "reception"}-${shop.id}@checkout.test`;
  const created = await request.post(`${API}/auth/v1/admin/users`, {
    headers: admin,
    data: { email, password: PASSWORD, email_confirm: true },
  });
  expect(created.ok(), await created.text()).toBe(true);
  const userId = ((await created.json()) as { id: string }).id;
  await insert(request, "memberships", { tenant_id: shop.tenantId, user_id: userId, role, branch_id: shop.branchId });
  return email;
}

export type ShopVisit = { id: string; itemId: string; clientId: string; label: string };

async function bookingCall(request: APIRequestContext, actor: string, route: string, data: unknown) {
  const response = await request.post(functionUrl(API, "bookings", route), {
    headers: { apikey: ANON_KEY, authorization: `Bearer ${await accessToken(request, actor)}`, "idempotency-key": crypto.randomUUID() },
    data,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { data: { id: string } }).data;
}

export type ShopCatalogue = { serviceId: string; staffId: string; clientId: string; label: string };

/**
 * One 60-minute service at `priceMinor`, a new staff member who does it on a
 * 09:00-21:00 shift on `day` (Kuwait), and a new client.
 */
export async function shopCatalogue(request: APIRequestContext, shop: Shop, opts: { day: string; priceMinor: number }): Promise<ShopCatalogue> {
  const label = shop.id;
  const tenant = { tenant_id: shop.tenantId };
  const [category] = await insert(request, "service_categories", { ...tenant, name_en: "Services" });
  const [service] = await insert(request, "services", {
    ...tenant,
    category_id: category!.id,
    name_en: `Facial ${label}`,
    name_ar: `تنظيف بشرة ${label}`,
    duration_minutes: 60,
    price_minor: opts.priceMinor,
  });
  const [staff] = await insert(request, "staff_members", { ...tenant, full_name_en: `Huda ${label}`, full_name_ar: `هدى ${label}` });
  await insert(request, "staff_branch_assignments", { ...tenant, staff_id: staff!.id, branch_id: shop.branchId, is_default: true });
  await insert(request, "service_staff", { ...tenant, service_id: service!.id, branch_id: shop.branchId, staff_id: staff!.id });
  await insert(request, "shifts", {
    ...tenant,
    staff_id: staff!.id,
    branch_id: shop.branchId,
    starts_at: kuwait(opts.day, "09:00"),
    ends_at: kuwait(opts.day, "21:00"),
  });
  const [client] = await insert(request, "clients", {
    ...tenant,
    first_name: "Noor",
    last_name: label,
    first_name_alt: "نور",
    last_name_alt: `الصباح ${label}`,
  });
  return { serviceId: service!.id, staffId: staff!.id, clientId: client!.id, label };
}

/**
 * A visit at the shop on `day` 15:00 (Kuwait) for the `shopCatalogue`
 * service, staff member and client, booked through the bookings function as
 * `actor` and marked arrived, ready for checkout.
 */
export async function shopVisit(
  request: APIRequestContext,
  shop: Shop,
  actor: string,
  opts: { day: string; priceMinor: number },
): Promise<ShopVisit> {
  const { serviceId, staffId, clientId, label } = await shopCatalogue(request, shop, opts);
  const visit = await bookingCall(request, actor, "create", {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    client_id: clientId,
    items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(opts.day, "15:00") }],
  });
  await bookingCall(request, actor, "set-status", { tenant_id: shop.tenantId, appointment_id: visit.id, status: "arrived" });
  const items = await request.get(`${REST}/appointment_items?appointment_id=eq.${visit.id}&select=id`, { headers: admin });
  const [item] = (await items.json()) as { id: string }[];
  return { id: visit.id, itemId: item!.id, clientId, label };
}

/** The ids of a sale's payments (not refunds), oldest first. */
export async function paymentIdsOf(request: APIRequestContext, saleId: string): Promise<string[]> {
  const response = await request.get(`${REST}/payments?sale_id=eq.${saleId}&payment_type=eq.payment&select=id&order=created_at`, {
    headers: admin,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { id: string }[]).map((row) => row.id);
}

/** Signs in as `actor` and opens the branch calendar on `day`. */
export async function openCalendar(page: Page, s: Strings, actor: string, branchId: string, day: string): Promise<void> {
  await page.goto("/login");
  await signIn(page, s, actor);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/calendar?branch=${branchId}&date=${day}`);
}
