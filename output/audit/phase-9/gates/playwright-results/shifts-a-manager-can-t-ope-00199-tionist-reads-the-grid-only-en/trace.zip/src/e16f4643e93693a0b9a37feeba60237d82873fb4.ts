import { expect, signIn, test } from "./fixtures";
import { acceptInvite, newPersonPage, unique } from "./memberFlows";
import {
  addShiftButton,
  drawShift,
  freshWeek,
  gridRow,
  kuwaitToday,
  openShiftGrid,
  shiftButtons,
  submitShift,
} from "./shiftFlows";
import { SETUP_BRANCH, addStaff, openStaffList } from "./staffFlows";

// Setup Studio (supabase/seed.sql) gets fresh staff and a fresh far-future
// week each run, so shifts never collide across runs or languages. Hawally is
// Asia/Kuwait with weeks starting on Saturday and a 15-minute slot step.

test("a manager draws a shift, types an overnight one, and copies the week with skip and replace", async ({
  page,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const week = freshWeek();

  await page.goto("/login");
  await signIn(page, s, "setup-manager@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await addStaff(page, s, { nameEn: `Shift ${id}`, nameAr: `وردية ${id}`, branches: [s.hawally] });
  const name = appLocale === "ar" ? `وردية ${id}` : `Shift ${id}`;

  await openShiftGrid(page, s, SETUP_BRANCH.hawally, week);
  const row = gridRow(page, id);
  await expect(row).toBeVisible();

  // Drag-to-draw on Saturday snaps to the 15-minute step and prefills the drawer.
  await drawShift(page, row, 0, 9 * 60 + 2, 13 * 60 - 3);
  const drawer = page.getByRole("dialog");
  await expect(drawer.getByLabel(s.starts, { exact: true })).toHaveValue("09:00");
  await expect(drawer.getByLabel(s.ends, { exact: true })).toHaveValue("13:00");
  await drawer.getByRole("button", { name: s.addShift, exact: true }).click();
  await expect(page.getByText(s.shiftAdded)).toBeVisible();
  await expect(shiftButtons(row, s, name)).toHaveCount(1);

  // The form path: Sunday 18:00 to 02:00 is one overnight shift on its start day.
  await addShiftButton(row, s, name, 1).click();
  await page.getByRole("dialog").getByLabel(s.ends, { exact: true }).fill("02:00");
  await page.getByRole("dialog").getByLabel(s.starts, { exact: true }).fill("18:00");
  await expect(page.getByRole("dialog").getByText(s.overnightHint)).toBeVisible();
  await submitShift(page, s, { starts: "18:00", ends: "02:00" });
  // The first add's toast may still be showing.
  await expect(page.getByText(s.shiftAdded).last()).toBeVisible();
  await expect(shiftButtons(row, s, name)).toHaveCount(2);
  await expect(row.getByText(s.overnight, { exact: true })).toHaveCount(1);

  // The same person can't work overlapping hours.
  await addShiftButton(row, s, name, 0).click();
  await submitShift(page, s, { starts: "12:00", ends: "15:00" });
  await expect(page.getByRole("dialog").getByText(s.shiftOverlap)).toBeVisible();
  await page.getByRole("dialog").getByRole("button", { name: s.close }).click();

  // Copy into the next week, skipping anyone already scheduled there.
  await page.getByRole("button", { name: s.nextWeek }).click();
  await expect(page).not.toHaveURL(new RegExp(`week=${week}`));
  await expect(shiftButtons(row, s, name)).toHaveCount(0);
  await page.getByRole("button", { name: s.copyPreviousWeek }).click();
  await expect(page.getByRole("dialog").getByText(s.shiftsLastWeek(2))).toBeVisible();
  await page.getByRole("dialog").getByRole("button", { name: s.copyShifts }).click();
  await expect(page.getByText(s.copiedShifts(2))).toBeVisible();
  await expect(shiftButtons(row, s, name)).toHaveCount(2);
  await expect(row.getByText(s.overnight, { exact: true })).toHaveCount(1);

  // Same wall-clock times a week later, overnight end included.
  await shiftButtons(row, s, name).nth(1).click();
  await expect(page.getByRole("dialog").getByLabel(s.starts, { exact: true })).toHaveValue("18:00");
  await expect(page.getByRole("dialog").getByLabel(s.ends, { exact: true })).toHaveValue("02:00");
  await page.getByRole("dialog").getByRole("button", { name: s.close }).click();

  // Skip has nothing left to copy; replace swaps the week.
  await page.getByRole("button", { name: s.copyPreviousWeek }).click();
  await expect(page.getByRole("dialog").getByText(s.everyoneScheduled)).toBeVisible();
  await expect(page.getByRole("dialog").getByRole("button", { name: s.copyShifts })).toBeDisabled();
  await page.getByRole("radio", { name: s.replaceTheirWeek }).click();
  await page.getByRole("dialog").getByRole("button", { name: s.replaceThisWeek }).click();
  await expect(page.getByText(s.copiedShifts(2))).toBeVisible();
  await expect(shiftButtons(row, s, name)).toHaveCount(2);
});

test("a manager can't open another branch's shifts, and a receptionist reads the grid only", async ({
  page,
  browser,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const week = freshWeek();

  // The owner schedules someone who works at both branches, at Jahra.
  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await addStaff(page, s, { nameEn: `Both ${id}`, nameAr: `كلاهما ${id}`, branches: [s.hawally, s.jahra] });
  const name = appLocale === "ar" ? `كلاهما ${id}` : `Both ${id}`;
  await openShiftGrid(page, s, SETUP_BRANCH.jahra, week);
  await addShiftButton(gridRow(page, id), s, name, 0).click();
  await submitShift(page, s, { starts: "10:00", ends: "14:00" });
  await expect(page.getByText(s.shiftAdded)).toBeVisible();

  // Hawally's manager asking for Jahra lands on Hawally, where the Jahra shift isn't shown.
  const manager = await newPersonPage(browser, appLocale);
  await manager.goto("/login");
  await signIn(manager, s, "setup-manager@spacorner.test");
  await openShiftGrid(manager, s, SETUP_BRANCH.jahra, week);
  await expect(manager).toHaveURL(new RegExp(`branch=${SETUP_BRANCH.hawally}`));
  const row = gridRow(manager, id);
  await expect(row).toBeVisible();
  await expect(shiftButtons(row, s, name)).toHaveCount(0);
  // Still one person: overlapping hours at Hawally are refused without revealing the Jahra shift.
  await addShiftButton(row, s, name, 0).click();
  await submitShift(manager, s, { starts: "12:00", ends: "16:00" });
  await expect(manager.getByRole("dialog").getByText(s.shiftOverlap)).toBeVisible();
  await manager.context().close();

  const reception = await newPersonPage(browser, appLocale);
  await reception.goto("/login");
  await signIn(reception, s, "setup-reception@spacorner.test");
  await openShiftGrid(reception, s, SETUP_BRANCH.hawally, week);
  await expect(gridRow(reception, id)).toBeVisible();
  await expect(reception.getByRole("button", { name: s.copyPreviousWeek })).toHaveCount(0);
  await expect(reception.getByRole("button", { name: new RegExp(s.addShiftFor(name)) })).toHaveCount(0);
  await reception.context().close();
});

test("a staff login sees their own shifts on My day", async ({ page, browser, request, s, appLocale }) => {
  const id = unique(appLocale);
  const email = `shift-${id}@spacorner.test`;
  const name = appLocale === "ar" ? `ريم ${id}` : `Reem ${id}`;

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await addStaff(page, s, { nameEn: `Reem ${id}`, nameAr: `ريم ${id}`, email, branches: [s.hawally] });
  await page.getByRole("button", { name: s.inviteToSignIn }).click();
  await expect(page.getByText(s.invitationSentTo(email))).toBeVisible();

  await openShiftGrid(page, s, SETUP_BRANCH.hawally);
  await addShiftButton(gridRow(page, id), s, name, 0).click();
  await submitShift(page, s, { date: kuwaitToday(), starts: "10:00", ends: "14:00" });
  await expect(page.getByText(s.shiftAdded)).toBeVisible();

  const person = await newPersonPage(browser, appLocale);
  await acceptInvite(person, request, s, email, `Glow-${id}`);
  await person.getByRole("link", { name: s.myDay }).click();
  const shifts = person.getByRole("table", { name: s.yourShifts });
  await expect(shifts).toContainText(s.hawally);
  await expect(shifts.getByRole("row")).toHaveCount(2);
  await person.context().close();
});
