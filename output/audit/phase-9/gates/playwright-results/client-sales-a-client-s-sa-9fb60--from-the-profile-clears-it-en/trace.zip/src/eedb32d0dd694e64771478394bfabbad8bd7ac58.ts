import type { APIRequestContext, Browser, Page } from "@playwright/test";
import { expect, test } from "./fixtures";
import { waitForAuthLink } from "./mailpit";
import type { AppLocale, Strings } from "./strings";

// Members & roles journeys shared by members.spec.ts and the Phase 1 evidence run.

// The random tail keeps parallel workers that start in the same millisecond apart.
export const unique = (appLocale: AppLocale) =>
  `${appLocale}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;

export async function openMembers(page: Page, s: Strings) {
  await page.getByRole("link", { name: s.settings, exact: true }).click();
  await page.getByRole("link", { name: s.membersAndRoles }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.membersAndRoles })).toBeVisible();
}

export async function invite(page: Page, s: Strings, person: { email: string; name: string; role: string; branch: string }) {
  await page.getByRole("button", { name: s.inviteMember }).click();
  const drawer = page.getByRole("dialog");
  await drawer.getByLabel(s.email).fill(person.email);
  await drawer.getByLabel(s.fullName).fill(person.name);
  await drawer.getByLabel(s.role).selectOption({ label: person.role });
  await drawer.getByLabel(s.branchAccess).selectOption({ label: person.branch });
  await drawer.getByRole("button", { name: s.sendInvitation }).click();
  await expect(page.getByText(s.invitationSentTo(person.email))).toBeVisible();
  await expect(page.getByRole("row", { name: new RegExp(person.name) })).toContainText(s.invitationSent);
}

export async function acceptInvite(page: Page, request: APIRequestContext, s: Strings, email: string, password: string) {
  await page.goto(await waitForAuthLink(request, email));
  await expect(page).toHaveURL(/\/accept-invite/);
  await expect(page.getByRole("heading", { name: s.welcomeToTeam })).toBeVisible();
  await page.getByLabel(s.password, { exact: true }).fill(password);
  await page.getByLabel(s.confirmPasswordPlain, { exact: true }).fill(password);
  await page.getByRole("button", { name: s.setPasswordContinue }).click();
  await expect(page).toHaveURL(/\/\?branch=[\w-]+$/);
}

/** A second signed-out browser for the invitee, in the project language. */
export async function newPersonPage(browser: Browser, appLocale: AppLocale): Promise<Page> {
  const context = await browser.newContext({ baseURL: test.info().project.use.baseURL });
  await context.addInitScript((locale) => {
    if (window.localStorage.getItem("glowdesk.locale") === null) window.localStorage.setItem("glowdesk.locale", locale);
  }, appLocale);
  return await context.newPage();
}
