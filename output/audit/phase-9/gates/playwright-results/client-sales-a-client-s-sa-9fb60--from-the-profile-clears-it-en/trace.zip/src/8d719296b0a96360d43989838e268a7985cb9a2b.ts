import type { Page } from "@playwright/test";
import type { SaleCreateInput } from "@repo/validation";
import { createClient, SETUP_TENANT } from "./bookingFixtures";
import { createSale } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { newPersonPage } from "./memberFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { Strings } from "./strings";

// The client profile's sales at Setup Studio, for a client of this run alone:
// at Hawally a 12.000 sale part paid 5.000 (the oldest still owing) and a paid
// 6.000 one; at Jahra a 9.000 sale left unpaid. RLS decides who sees what: the
// owner both branches, Hawally's receptionist Hawally only (ADR-11). The
// receptionist gets a browser of her own: signing out ends every session of
// the user, and other specs sell as the Setup Studio owner at the same time.

const RECEPTION = "setup-reception@spacorner.test"; // Reem Hawally, receptionist at Hawally
const OWNER = "setup-owner@spacorner.test";

function profile(page: Page, s: Strings) {
  const sales = page.getByRole("region", { name: s.salesTitle, exact: true });
  return {
    sales,
    balance: sales.getByRole("region", { name: s.balanceTitle }),
    stat: (label: string) => sales.locator("dl > div").filter({ has: page.getByText(label, { exact: true }) }).locator("dd"),
    sale: (invoice: string) => sales.getByRole("listitem").filter({ hasText: invoice }),
  };
}

test("a client's sales show what they owe by branch, and settling from the profile clears it", async ({ page, browser, request, s, appLocale }) => {
  const clientId = await createClient(request, { firstName: "Hessa", lastName: `Balance ${appLocale} ${Date.now()}` });
  const sell = (actor: string, branchId: string, priceMinor: number, payments: SaleCreateInput["payments"]) =>
    createSale(request, actor, {
      tenant_id: SETUP_TENANT,
      branch_id: branchId,
      client_id: clientId,
      lines: [{ type: "manual_item", name_en: `Gift voucher ${clientId}`, unit_price_minor: priceMinor }],
      tips: [],
      payments,
      expected: { total_minor: priceMinor, tip_minor: 0, grand_total_minor: priceMinor },
    });
  const partPaid = await sell(RECEPTION, SETUP_BRANCH.hawally, 12_000, [{ method: "knet_terminal", amount_minor: 5_000 }]);
  const paid = await sell(RECEPTION, SETUP_BRANCH.hawally, 6_000, [{ method: "knet_terminal", amount_minor: 6_000 }]);
  const jahra = await sell(OWNER, SETUP_BRANCH.jahra, 9_000, []);

  // The owner sees every branch: three sales, 16.000 owed at two of them.
  await page.goto("/login");
  await signIn(page, s, OWNER);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/clients/${clientId}?branch=${SETUP_BRANCH.hawally}`);
  const owner = profile(page, s);
  await expect(owner.stat(s.salesTitle)).toHaveText(/3/);
  await expect(owner.stat(s.spent)).toContainText("27.000");
  await expect(owner.balance).toContainText(s.dueAcrossBranches("16.000", 2));
  await expect(owner.balance.getByRole("listitem").filter({ hasText: s.jahra })).toContainText("9.000");
  await expect(owner.balance.getByRole("listitem").filter({ hasText: s.hawally })).toContainText("7.000");
  await expect(owner.sale(jahra.invoice_number)).toContainText(s.jahra);
  await expect(owner.sale(jahra.invoice_number).getByText(s.unpaid, { exact: true })).toBeVisible();
  await expect(owner.sale(partPaid.invoice_number)).toContainText(s.hawally);
  await expect(owner.sale(paid.invoice_number).getByRole("link", { name: paid.invoice_number })).toHaveAttribute("href", new RegExp(`^/sales/${paid.id}(\\?|$)`));

  // Hawally's receptionist sees Hawally alone, then settles from the profile.
  const desk = await newPersonPage(browser, appLocale);
  await desk.goto("/login");
  await signIn(desk, s, RECEPTION);
  await expect(desk).toHaveURL(/\?branch=/);
  await desk.goto(`/clients/${clientId}?branch=${SETUP_BRANCH.hawally}`);
  const reception = profile(desk, s);
  await expect(reception.stat(s.salesTitle)).toHaveText(/2/);
  await expect(reception.balance).toContainText(s.dueAtOneBranch("7.000"));
  await expect(reception.sale(partPaid.invoice_number)).toBeVisible();
  await expect(reception.sale(jahra.invoice_number)).toHaveCount(0);
  await expect(reception.sales).not.toContainText(s.jahra);

  await reception.balance.getByRole("button", { name: s.settleBalance }).click();
  const drawer = desk.getByRole("dialog", { name: s.sale, exact: true });
  await expect(drawer).toContainText(partPaid.invoice_number);
  await drawer.getByRole("button", { name: s.settleBalance }).click();
  await drawer.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: s.knet, exact: true }).click();
  await expect(drawer.getByRole("group", { name: s.knet, exact: true }).getByRole("textbox", { name: s.amount })).toHaveValue("7.000");
  await drawer.getByRole("button", { name: s.recordPayment }).dblclick();
  await expect(drawer.getByText(s.paidInFull(partPaid.invoice_number))).toBeVisible();
  await desk.keyboard.press("Escape");
  await expect(drawer).toBeHidden();

  await expect(reception.balance).toContainText(s.nothingOwed);
  await expect(reception.balance.getByRole("button", { name: s.settleBalance })).toHaveCount(0);
  await expect(reception.sale(partPaid.invoice_number).getByText(s.paid, { exact: true })).toBeVisible();
  await desk.context().close();
});
