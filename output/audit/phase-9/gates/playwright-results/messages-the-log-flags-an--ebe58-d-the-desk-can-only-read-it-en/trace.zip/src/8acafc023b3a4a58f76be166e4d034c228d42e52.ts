import type { APIRequestContext } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { accessToken, admin, API, ANON_KEY, kuwait, REST } from "./bookingFixtures";
import { addMember, freshShop, openCalendar, shopCatalogue, type Shop } from "./checkoutFixtures";
import { expect, signIn, signOut, test } from "./fixtures";
import { mailCount } from "./mailpit";
import { kuwaitToday } from "./shiftFlows";

// 9.5-T3: message history in the drawer and on the profile, the message log
// with its "didn't arrive" notice, sending again, and the owner's usage card.
// The desk confirmation goes through the real outbox and the local consumer;
// the fake provider decides the outcome from the address (permanent+…,
// ambiguous+… at fake.test), anything else reaches Mailpit.

const DELIVERY = { timeout: 45_000 };

const tomorrow = () => {
  const day = new Date(`${kuwaitToday()}T00:00:00Z`);
  day.setUTCDate(day.getUTCDate() + 1);
  return day.toISOString().slice(0, 10);
};

async function setClientEmail(request: APIRequestContext, clientId: string, email: string) {
  const response = await request.patch(`${REST}/clients?id=eq.${clientId}`, {
    headers: admin,
    data: { email },
  });
  expect(response.ok(), await response.text()).toBe(true);
}

async function ledgerStatuses(request: APIRequestContext, tenantId: string): Promise<string[]> {
  const response = await request.get(`${REST}/notification_messages?tenant_id=eq.${tenantId}&select=status`, {
    headers: admin,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { status: string }[]).map((row) => row.status);
}

/** A desk booking tomorrow 15:00 for the catalogue's client, whose email is `email`. */
async function bookWithEmail(request: APIRequestContext, shop: Shop, email: string) {
  const day = tomorrow();
  const catalogue = await shopCatalogue(request, shop, {
    day,
    priceMinor: 10_000,
  });
  await setClientEmail(request, catalogue.clientId, email);
  const response = await request.post(functionUrl(API, "bookings", "create"), {
    headers: {
      apikey: ANON_KEY,
      authorization: `Bearer ${await accessToken(request, shop.owner)}`,
      "idempotency-key": crypto.randomUUID(),
    },
    data: {
      tenant_id: shop.tenantId,
      branch_id: shop.branchId,
      client_id: catalogue.clientId,
      items: [
        {
          service_id: catalogue.serviceId,
          staff_id: catalogue.staffId,
          starts_at: kuwait(day, "15:00"),
        },
      ],
    },
  });
  expect(response.ok(), await response.text()).toBe(true);
  return { day, clientId: catalogue.clientId };
}

test("a confirmation that didn't arrive is sent again from the drawer once the email is fixed", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  test.setTimeout(150_000);
  const shop = await freshShop(request, `retry-${appLocale}`);
  const { day, clientId } = await bookWithEmail(request, shop, `permanent+${shop.id}@fake.test`);

  await openCalendar(page, s, shop.owner, shop.branchId, day);
  await page
    .getByRole("region", { name: s.appointmentsByStaff })
    .locator("[data-event-id]:not([id^='time-grid-event-copy-'])")
    .first()
    .click();
  const messages = page.getByRole("dialog").getByRole("region", { name: s.messagesTab, exact: true });
  const confirmation = messages.getByRole("listitem").filter({ hasText: s.confirmationMessage });
  await expect(confirmation.getByText(s.notDelivered, { exact: true })).toBeVisible(DELIVERY);

  const fixed = `fixed-${shop.id}@example.com`;
  await setClientEmail(request, clientId, fixed);
  await confirmation.getByRole("button", { name: s.sendMessageAgain(s.confirmationMessage) }).click();
  const ask = page.getByRole("alertdialog", { name: s.sendMessageAgainTitle });
  await expect(ask).not.toContainText(s.possibleDuplicateMessage);
  await ask.getByRole("button", { name: s.sendAgain }).click();
  await expect(page.getByText(s.messageQueuedAgain)).toBeVisible();
  await expect(confirmation.getByText(s.messageSent, { exact: true })).toBeVisible(DELIVERY);
  await expect(confirmation).toContainText(s.twoAttempts);
  await expect(
    confirmation.getByRole("button", {
      name: s.sendMessageAgain(s.confirmationMessage),
    }),
  ).toHaveCount(0);
  await expect.poll(() => mailCount(request, fixed), DELIVERY).toBe(1);

  // The same history on the client's profile.
  await page.goto(`/clients/${clientId}`);
  const profile = page.getByRole("region", {
    name: s.messagesTab,
    exact: true,
  });
  await expect(profile.getByRole("listitem").filter({ hasText: s.confirmationMessage })).toContainText(s.messageSent);
});

test("the log flags an unconfirmed message, sends it again only after the duplicate warning, and the desk can only read it", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  test.setTimeout(150_000);
  const shop = await freshShop(request, `log-${appLocale}`);
  const receptionist = await addMember(request, shop, "receptionist");
  await bookWithEmail(request, shop, `ambiguous+${shop.id}@fake.test`);

  await expect.poll(() => ledgerStatuses(request, shop.tenantId), DELIVERY).toEqual(["unknown"]);

  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await page.getByRole("link", { name: s.messagesTab, exact: true }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.messageLog })).toBeVisible();
  await expect(page.getByText(s.oneUndelivered)).toBeVisible();

  await page.getByRole("button", { name: s.showThem }).click();
  await expect(page).toHaveURL(/delivery=attention/);
  const table = page.getByRole("table", { name: s.messagesTab, exact: true });
  const row = table.getByRole("row").filter({ hasText: s.confirmationMessage });
  await expect(row).toHaveCount(1);
  await expect(row.getByText(s.unconfirmed, { exact: true })).toBeVisible();

  await row
    .getByRole("button", {
      name: new RegExp(`^${s.sendMessageAgain(s.confirmationMessage)}`),
    })
    .click();
  const ask = page.getByRole("alertdialog", { name: s.sendMessageAgainTitle });
  await expect(ask).toContainText(s.possibleDuplicateMessage);
  await ask.getByRole("button", { name: s.sendAnyway }).click();
  await expect(page.getByText(s.messageQueuedAgain)).toBeVisible();

  // The owner's usage: one email this month, whatever its retry is doing.
  const usage = page.getByRole("table", { name: new RegExp(s.messageUsage) });
  await expect(usage.getByRole("row").filter({ hasText: s.email })).toContainText("1");

  // The receptionist reads the log but can't send again or see usage.
  await signOut(page, s);
  await signIn(page, s, receptionist);
  await page.goto("/messages");
  await expect(
    page
      .getByRole("table", { name: s.messagesTab, exact: true })
      .getByRole("row")
      .filter({ hasText: s.confirmationMessage }),
  ).toHaveCount(1);
  await expect(page.getByRole("button", { name: s.sendAgain })).toHaveCount(0);
  await expect(page.getByRole("table", { name: new RegExp(s.messageUsage) })).toHaveCount(0);
});
