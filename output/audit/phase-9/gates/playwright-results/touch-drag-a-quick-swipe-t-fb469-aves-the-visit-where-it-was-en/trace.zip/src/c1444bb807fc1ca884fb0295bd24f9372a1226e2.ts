import type { CDPSession, Locator, Page } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import { book, createClient, createService, createStaff, kuwait } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { Strings } from "./strings";

// Moving appointments on a tablet (768x1024, touch): a press-and-hold drag
// moves a visit, a tap opens it, and a quick swipe that starts on a card
// scrolls without moving it. Touch moves go through Chromium's input
// pipeline (CDP), the same path a finger takes.

test.use({ hasTouch: true, viewport: { width: 768, height: 1024 } });
test.skip(({ browserName }) => browserName !== "chromium", "touch moves are dispatched through CDP");

const EVENT = "[data-event-id]:not([id^='time-grid-event-copy-'])";
// BookingCalendar draws 24px per slot; Hawally keeps the default 15-minute step.
const PX_PER_MINUTE = 24 / 15;
// schedule-x starts a drag 150 ms after the finger lands.
const HOLD_MS = 300;

const timeOf = (event: Locator) => event.locator(".gd-event-time");
const hours = (start: string, end: string) => new RegExp(`${start}\\s*–\\s*${end}`);

async function oneBooked(page: Page, s: Strings, id: string, day: string) {
  const serviceId = await createService(page.request, { en: `Facial ${id}`, ar: `تنظيف بشرة ${id}` }, { duration: 60 });
  const staffId = await createStaff(page.request, {
    name: { en: `Mona ${id}`, ar: `منى ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts: [{ day, starts: "09:00", ends: "22:00" }],
  });
  const clientId = await createClient(page.request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  await book(page.request, "setup-reception@spacorner.test", {
    branchId: SETUP_BRANCH.hawally,
    clientId,
    items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(day, "15:00") }],
  });
  await page.goto("/login");
  await signIn(page, s, "setup-reception@spacorner.test");
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/calendar?branch=${SETUP_BRANCH.hawally}&date=${day}&staff=${encodeURIComponent(JSON.stringify([staffId]))}`);
  const event = page.getByRole("region", { name: s.appointmentsByStaff }).locator(EVENT).filter({ hasText: id });
  await expect(() => event.scrollIntoViewIfNeeded({ timeout: 1_000 })).toPass({ timeout: 5_000 });
  await expect(timeOf(event)).toHaveText(hours("15:00", "16:00"));
  return event;
}

async function startPoint(event: Locator) {
  const box = await event.boundingBox();
  if (!box) throw new Error("not on screen");
  return { x: box.x + box.width / 2, y: box.y + Math.min(12, box.height / 2) };
}

/** One finger from `from`, `dy` pixels down in `steps` moves `stepMs` apart, after holding still `holdMs`. */
async function touchGesture(cdp: CDPSession, from: { x: number; y: number }, dy: number, opts: { holdMs: number; steps: number; stepMs: number }) {
  const touch = (type: "touchStart" | "touchMove" | "touchEnd", y?: number) =>
    cdp.send("Input.dispatchTouchEvent", { type, touchPoints: y === undefined ? [] : [{ x: from.x, y, id: 1 }] });
  await touch("touchStart", from.y);
  await new Promise((resolve) => setTimeout(resolve, opts.holdMs));
  for (let step = 1; step <= opts.steps; step += 1) {
    await touch("touchMove", from.y + (dy * step) / opts.steps);
    await new Promise((resolve) => setTimeout(resolve, opts.stepMs));
  }
  await touch("touchEnd");
}

test("press, hold and drag moves a visit an hour later", async ({ page, s, appLocale }) => {
  const id = unique(appLocale);
  const sara = appLocale === "ar" ? `سارة ${id}` : `Sara ${id}`;
  const event = await oneBooked(page, s, id, addDays(kuwaitToday(), 1));
  const cdp = await page.context().newCDPSession(page);

  await touchGesture(cdp, await startPoint(event), 60 * PX_PER_MINUTE, { holdMs: HOLD_MS, steps: 20, stepMs: 16 });
  await expect(timeOf(event)).toHaveText(hours("16:00", "17:00"));
  await expect(page.getByText(s.movedTo(sara))).toBeVisible();
});

test("a tap opens the visit without moving it", async ({ page, s, appLocale }) => {
  const id = unique(appLocale);
  const event = await oneBooked(page, s, id, addDays(kuwaitToday(), 1));

  await event.tap();
  await expect(page.getByRole("dialog", { name: new RegExp(id) })).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(timeOf(event)).toHaveText(hours("15:00", "16:00"));
});

test("a quick swipe that starts on a card scrolls and leaves the visit where it was", async ({ page, s, appLocale }) => {
  const id = unique(appLocale);
  const sara = appLocale === "ar" ? `سارة ${id}` : `Sara ${id}`;
  const event = await oneBooked(page, s, id, addDays(kuwaitToday(), 1));
  const cdp = await page.context().newCDPSession(page);

  // A flick upwards lasting longer than the 150 ms drag delay.
  const from = await startPoint(event);
  await touchGesture(cdp, from, -240, { holdMs: 0, steps: 15, stepMs: 20 });
  await page.waitForTimeout(1_000);
  await expect(timeOf(event)).toHaveText(hours("15:00", "16:00"));
  expect((await startPoint(event)).y, "the grid scrolled").toBeLessThan(from.y - 100);
  await expect(page.getByText(s.movedTo(sara))).toHaveCount(0);
});
