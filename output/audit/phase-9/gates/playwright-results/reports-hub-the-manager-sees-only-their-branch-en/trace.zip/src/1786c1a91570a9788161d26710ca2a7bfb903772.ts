import type { Page } from "@playwright/test";
import { expect, signIn, test } from "./fixtures";
import type { Strings } from "./strings";

// The reports hub and its guard (7.2-T1). SpaCorner seed: the owner holds
// every branch (Kuwait City, Salmiya); the manager and the receptionist hold
// Salmiya; the staff login works at Kuwait City.

const nav = (page: Page, s: Strings) => page.getByRole("navigation", { name: s.mainNav });

async function openAs(page: Page, s: Strings, email: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
}

test("the owner opens every report from the hub and picks any branch", async ({ page, s }) => {
  await openAs(page, s, "owner@spacorner.test");
  await nav(page, s).getByRole("link", { name: s.reports }).click();
  await expect(page).toHaveURL(/\/reports\?branch=/);

  const cards = page.getByRole("list", { name: s.reports }).getByRole("listitem");
  await expect(cards).toHaveCount(8);
  for (const title of [s.dailySummary, s.salesSummary, s.paymentsSummary, s.taxes, s.appointmentsSummary, s.staffPerformance, s.shiftsReport, s.clientList]) {
    await expect(cards.getByRole("link", { name: title, exact: true })).toBeVisible();
  }

  await cards.getByRole("link", { name: s.salesSummary, exact: true }).click();
  await expect(page).toHaveURL(/\/reports\/sales\?/);
  await expect(page.getByRole("heading", { level: 1, name: s.salesSummary })).toBeVisible();
  const branch = page.getByRole("main").getByRole("combobox", { name: s.branch });
  await expect(branch.locator("option")).toHaveText([s.allBranches, s.kuwaitCity, s.salmiya]);
  await expect(page.getByRole("region", { name: s.totals })).toBeVisible();

  await page.getByRole("link", { name: s.allReports }).click();
  await expect(page).toHaveURL(/\/reports\?branch=/);
});

test("the manager sees only their branch", async ({ page, s }) => {
  await openAs(page, s, "manager@spacorner.test");
  await nav(page, s).getByRole("link", { name: s.reports }).click();
  await expect(page.getByRole("list", { name: s.reports }).getByRole("listitem")).toHaveCount(8);

  await page.getByRole("link", { name: s.paymentsSummary, exact: true }).click();
  const branch = page.getByRole("main").getByRole("combobox", { name: s.branch });
  await expect(branch.locator("option")).toHaveText([s.salmiya]);
  await expect(page.getByRole("region", { name: s.totals })).toBeVisible();
});

for (const email of ["reception@spacorner.test", "staff@spacorner.test"]) {
  test(`${email.split("@")[0]} has no reports`, async ({ page, s }) => {
    await openAs(page, s, email);
    await expect(nav(page, s).getByRole("link", { name: s.reports })).toHaveCount(0);
    await page.goto("/reports");
    await expect(page.getByText(s.forbidden)).toBeVisible();
    await page.goto("/reports/sales");
    await expect(page.getByText(s.forbidden)).toBeVisible();
  });
}
