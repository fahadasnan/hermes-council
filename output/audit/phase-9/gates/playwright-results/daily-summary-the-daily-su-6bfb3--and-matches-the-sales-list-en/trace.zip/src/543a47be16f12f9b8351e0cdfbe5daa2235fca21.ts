import type { Locator, Page } from "@playwright/test";
import { attemptRefund, closeRegister, createSale, ensureRegisterOpen, freshShop, paymentIdsOf, walkInSale } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";

// The daily summary of one day in a shop of its own (`freshShop`), so every
// figure is this test's: the register opened with 10.000; a cash sale of
// 20.000, a 12.000 sale part paid 5.000 by KNET and a 4.000 walk-in left
// unpaid; the register closed counted 1.000 over; then the cash sale refunded
// with the register closed. The same day in the sales list shows the same
// figures (US-SAL-3), and the business's currency locks with its first sale.

const statOf = (page: Page, region: Locator, label: string) =>
  region.locator("dl > div").filter({ has: page.getByText(label, { exact: true }) }).locator("dd");

test("the daily summary adds up the day, flags the out-of-session refund, and matches the sales list", async ({ page, request, s }) => {
  const shop = await freshShop(request, "summary");
  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await expect(page).toHaveURL(/\?branch=/);

  // Before the first sale the currency can still change.
  await page.goto(`/settings/business?branch=${shop.branchId}`);
  const currency = page.getByRole("combobox", { name: s.currency });
  await expect(currency).toBeEnabled();
  await expect(page.getByText(s.currencyLocked)).toHaveCount(0);

  const session = await ensureRegisterOpen(request, shop.owner, shop.branchId, { tenantId: shop.tenantId, openingCashMinor: 10_000 });
  const cash = await createSale(request, shop.owner, walkInSale(shop, 20_000, [{ method: "cash", amount_minor: 20_000 }]));
  await createSale(request, shop.owner, walkInSale(shop, 12_000, [{ method: "knet_terminal", amount_minor: 5_000 }]));
  await createSale(request, shop.owner, walkInSale(shop, 4_000, []));
  await closeRegister(request, shop.owner, session, { tenantId: shop.tenantId, countedCashMinor: 31_000 });
  const [cashPayment] = await paymentIdsOf(request, cash.id);
  const refund = await attemptRefund(request, shop.owner, { tenantId: shop.tenantId, paymentId: cashPayment!, reason: "Client complaint" });
  expect(refund.status, JSON.stringify(refund.body)).toBe(201);

  // The F-PLAN-4 predicate end to end: one sale and the currency is locked.
  await page.reload();
  await expect(currency).toBeDisabled();
  await expect(page.getByText(s.currencyLocked)).toBeVisible();

  await page.goto(`/sales?branch=${shop.branchId}`);
  await page.getByRole("link", { name: s.dailySummary, exact: true }).click();
  await expect(page).toHaveURL(/\/sales\/summary\?/);

  const sales = page.getByRole("region", { name: s.salesOnThisDay });
  await expect(statOf(page, sales, s.salesTotal)).toContainText("36.000");
  await expect(statOf(page, sales, s.paid)).toContainText("25.000");
  await expect(statOf(page, sales, s.refunded)).toContainText("20.000");
  const outstanding = page.getByRole("region", { name: s.outstanding });
  await expect(statOf(page, outstanding, s.balanceDue)).toContainText("11.000");

  const collections = page.getByRole("region", { name: s.collectionsByMethod });
  const zero = /(^|\D)0\.000/;
  const cells = (label: string) => collections.getByRole("row").filter({ hasText: label }).getByRole("cell");
  await expect(cells(s.cash)).toHaveText([/20\.000/, /20\.000/, zero]);
  await expect(cells(s.knet)).toHaveText([/5\.000/, zero, /5\.000/]);
  await expect(cells(s.total)).toHaveText([/25\.000/, /20\.000/, /5\.000/]);

  const flagged = page.getByRole("region", { name: s.outOfSessionRefunds }).getByRole("listitem");
  await expect(flagged).toHaveCount(1);
  await expect(flagged).toContainText(cash.invoice_number);
  await expect(flagged.getByText(s.outsideRegisterSession)).toBeVisible();
  await expect(flagged).toContainText("Client complaint");

  const sessions = page.getByRole("region", { name: s.registerSessions }).getByRole("row");
  await expect(sessions).toHaveCount(2);
  await expect(sessions.nth(1)).toContainText("10.000");
  await expect(sessions.nth(1).getByRole("cell").last()).toHaveText(s.overBy("1.000"));

  // The sales list for the same day shows the same figures.
  const figures = {
    salesTotal: await statOf(page, sales, s.salesTotal).innerText(),
    paid: await statOf(page, sales, s.paid).innerText(),
    refunded: await statOf(page, sales, s.refunded).innerText(),
    balanceDue: await statOf(page, outstanding, s.balanceDue).innerText(),
  };
  await sales.getByRole("link", { name: s.openTheSales }).click();
  await expect(page).toHaveURL(/\/sales\?/);
  const totals = page.getByRole("region", { name: s.totalsForFilters });
  await expect(statOf(page, totals, s.salesTotal)).toHaveText(figures.salesTotal);
  await expect(statOf(page, totals, s.paid)).toHaveText(figures.paid);
  await expect(statOf(page, totals, s.refunded)).toHaveText(figures.refunded);
  await expect(statOf(page, totals, s.balanceDue)).toHaveText(figures.balanceDue);
});
