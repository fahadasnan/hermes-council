import { mkdirSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import AxeBuilder from "@axe-core/playwright";
import type { APIRequestContext, Page, TestInfo } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import { admin, REST } from "./bookingFixtures";
import { createSale, freshShop, openCalendar, shopVisit, type Shop, type ShopVisit } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { ROUTES, routeUrl, type RouteLogin, type RouteParams, type RoutePath } from "./routes";
import { kuwaitToday } from "./shiftFlows";
import type { Strings } from "./strings";

// WCAG 2.1 A/AA sweep with axe: every route in e2e/routes.ts in light and dark
// (the project gives the language), then the dialogs and drawers open. Serious
// and critical violations fail; every violation is attached to the report, and
// with A11Y_EVIDENCE=1 written to plan/evidence/7.4/a11y/.

const TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"];
const BLOCKING = new Set(["serious", "critical"]);
const THEMES = ["light", "dark"] as const;
const PRICE = 12_000;
const EVIDENCE = fileURLToPath(new URL("../../../plan/evidence/7.4/a11y/", import.meta.url));

type Theme = (typeof THEMES)[number];
type Finding = { where: string; theme: Theme; url: string; rule: string; impact: string; help: string; targets: string[]; detail: string };

const pathsFor = (login: RouteLogin) => (Object.keys(ROUTES) as RoutePath[]).filter((path) => ROUTES[path] === login);

async function setTheme(page: Page, theme: Theme) {
  await page.evaluate((value) => window.localStorage.setItem("theme", value), theme);
}

/**
 * Waits for the page to stop loading and moving: no request for 500 ms, no busy region, and no
 * finite animation or transition still running (axe reads a fading dialog's half-blended colours).
 */
async function settle(page: Page) {
  await page.waitForLoadState("networkidle");
  await expect(page.locator('[aria-busy="true"]')).toHaveCount(0);
  await page.waitForFunction(() =>
    document.getAnimations().every((animation) => animation.playState !== "running" || animation.effect?.getTiming().iterations === Infinity),
  );
}

async function audit(page: Page, where: string, theme: Theme, findings: Finding[]) {
  const results = await new AxeBuilder({ page }).withTags(TAGS).analyze();
  for (const violation of results.violations) {
    findings.push({
      where,
      theme,
      url: new URL(page.url()).pathname,
      rule: violation.id,
      impact: violation.impact ?? "unknown",
      help: violation.help,
      targets: violation.nodes.map((node) => node.target.join(" ")),
      detail: violation.nodes[0]?.failureSummary ?? "",
    });
  }
}

async function visit(page: Page, url: string, where: string, theme: Theme, findings: Finding[]) {
  await page.goto(url);
  await settle(page);
  await audit(page, where, theme, findings);
}

async function report(findings: Finding[], name: string, testInfo: TestInfo, appLocale: string) {
  const body = JSON.stringify(findings, null, 2);
  await testInfo.attach(`axe-${name}-${appLocale}.json`, { body, contentType: "application/json" });
  if (process.env.A11Y_EVIDENCE === "1") {
    mkdirSync(EVIDENCE, { recursive: true });
    writeFileSync(`${EVIDENCE}${name}-${appLocale}.json`, `${body}\n`);
  }
  const blocking = findings.filter((finding) => BLOCKING.has(finding.impact));
  expect(blocking, JSON.stringify(blocking, null, 2)).toEqual([]);
}

/** A shop of the run's own: a visit marked arrived, and a second visit sold by card. */
async function a11yShop(request: APIRequestContext, appLocale: string) {
  const shop = await freshShop(request, `a11y-${appLocale}`);
  const day = addDays(kuwaitToday(), 1);
  const arrived = await shopVisit(request, shop, shop.owner, { day, priceMinor: PRICE });
  const sold = await shopVisit(request, shop, shop.owner, { day, priceMinor: PRICE });
  const sale = await createSale(request, shop.owner, {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    appointment_id: sold.id,
    client_id: sold.clientId,
    lines: [{ type: "appointment_item", appointment_item_id: sold.itemId }],
    tips: [],
    payments: [{ method: "knet_terminal", amount_minor: PRICE }],
    expected: { total_minor: PRICE, tip_minor: 0, grand_total_minor: PRICE },
  });
  const first = async (table: string) => {
    const response = await request.get(`${REST}/${table}?tenant_id=eq.${shop.tenantId}&select=id&limit=1`, { headers: admin });
    const [row] = (await response.json()) as { id: string }[];
    return row!.id;
  };
  const params: RouteParams = {
    saleId: sale.id,
    clientId: arrived.clientId,
    staffId: await first("staff_members"),
    serviceId: await first("services"),
    branchId: shop.branchId,
  };
  return { shop, day, arrived, sold, params };
}

test.describe.configure({ timeout: 10 * 60_000 });
test.use({ actionTimeout: 15_000 });

test("signed-out pages and the no-access page", async ({ page, s, appLocale }, testInfo) => {
  const findings: Finding[] = [];
  await page.goto("/login");
  for (const theme of THEMES) {
    await setTheme(page, theme);
    for (const path of pathsFor("signedOut")) await visit(page, path, path, theme, findings);
  }
  await page.goto("/login");
  await signIn(page, s, "nobody@spacorner.test", undefined, { shell: false });
  await expect(page).toHaveURL(/\/no-access/);
  for (const theme of THEMES) {
    await setTheme(page, theme);
    await visit(page, "/no-access", "/no-access", theme, findings);
  }
  await report(findings, "signed-out", testInfo, appLocale);
});

test("the staff login's day", async ({ page, s, appLocale }, testInfo) => {
  const findings: Finding[] = [];
  await page.goto("/login");
  await signIn(page, s, "staff@spacorner.test");
  for (const theme of THEMES) {
    await setTheme(page, theme);
    for (const path of pathsFor("staff")) await visit(page, path, path, theme, findings);
  }
  await report(findings, "staff", testInfo, appLocale);
});

test("every owner route", async ({ page, request, s, appLocale }, testInfo) => {
  const { shop, params } = await a11yShop(request, appLocale);
  const findings: Finding[] = [];
  await page.goto("/login");
  await signIn(page, s, shop.owner);
  for (const theme of THEMES) {
    await setTheme(page, theme);
    for (const path of pathsFor("owner")) await visit(page, routeUrl(path, params), path, theme, findings);
  }
  await report(findings, "owner-routes", testInfo, appLocale);
});

async function openAppointment(page: Page, s: Strings, visitOf: ShopVisit) {
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await byStaff.locator(`[data-event-id="${visitOf.itemId}"]:not([id^='time-grid-event-copy-'])`).first().click();
  const drawer = page.getByRole("dialog", { name: new RegExp(visitOf.label) });
  await expect(drawer).toBeVisible();
  return drawer;
}

async function closeDialog(page: Page, dialog: ReturnType<Page["getByRole"]>) {
  await page.keyboard.press("Escape");
  await expect(dialog).toBeHidden();
}

async function auditDialogs(page: Page, s: Strings, shop: Shop, day: string, arrived: ShopVisit, sold: ShopVisit, theme: Theme, findings: Finding[]) {
  await page.goto(`/calendar?branch=${shop.branchId}&date=${day}`);
  await settle(page);

  const appointment = await openAppointment(page, s, arrived);
  await settle(page);
  await audit(page, "appointment drawer", theme, findings);
  await appointment.getByRole("button", { name: s.checkOut, exact: true }).click();
  const checkout = page.getByRole("dialog", { name: s.checkOut });
  await expect(checkout).toBeVisible();
  await settle(page);
  await audit(page, "checkout drawer", theme, findings);
  await closeDialog(page, checkout);
  if (await appointment.isVisible()) await closeDialog(page, appointment);

  const soldDrawer = await openAppointment(page, s, sold);
  await soldDrawer.getByRole("button", { name: s.viewSale }).click();
  const sale = page.getByRole("dialog", { name: s.sale, exact: true });
  await expect(sale).toBeVisible();
  await settle(page);
  await audit(page, "sale drawer", theme, findings);
  await closeDialog(page, sale);
  if (await soldDrawer.isVisible()) await closeDialog(page, soldDrawer);

  await page.getByRole("banner").getByRole("group", { name: s.cashRegister }).getByRole("button", { name: s.openRegister }).click();
  const register = page.getByRole("dialog", { name: s.openTheRegister });
  await expect(register).toBeVisible();
  await settle(page);
  await audit(page, "open register dialog", theme, findings);
  await closeDialog(page, register);

  await page.getByRole("banner").getByRole("button", { name: s.globalSearchButton }).click();
  const search = page.getByRole("dialog", { name: s.globalSearch });
  await expect(search).toBeVisible();
  await settle(page);
  await audit(page, "search dialog", theme, findings);
  await closeDialog(page, search);

  await page.goto(`/reports/sales?branch=${shop.branchId}`);
  await settle(page);
  await page.getByRole("button", { name: s.exportCsv }).click();
  const exportDialog = page.getByRole("dialog");
  await expect(exportDialog).toBeVisible();
  await settle(page);
  await audit(page, "export dialog", theme, findings);
  await closeDialog(page, exportDialog);
}

test("dialogs and drawers", async ({ page, request, s, appLocale }, testInfo) => {
  const { shop, day, arrived, sold } = await a11yShop(request, appLocale);
  const findings: Finding[] = [];
  await openCalendar(page, s, shop.owner, shop.branchId, day);
  for (const theme of THEMES) {
    await setTheme(page, theme);
    await auditDialogs(page, s, shop, day, arrived, sold, theme, findings);
  }
  await report(findings, "dialogs", testInfo, appLocale);
});
