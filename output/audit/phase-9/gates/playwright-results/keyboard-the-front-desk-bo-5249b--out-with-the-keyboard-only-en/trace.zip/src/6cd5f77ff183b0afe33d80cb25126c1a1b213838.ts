import type { Locator, Page } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import { ensureRegisterOpen, freshShop, saleOf, shopCatalogue } from "./checkoutFixtures";
import { expect, test } from "./fixtures";
import { kuwaitToday } from "./shiftFlows";

// Books a visit and checks it out with the keyboard alone: every step in the
// app is Tab, Shift+Tab, arrows, typing, Enter or Escape; no clicks, fills,
// checks or option picks. Setup and read-back go through the API. Each
// project gets a tenant of its own, so the register is never shared.

test.skip(({ browserName }) => browserName !== "chromium", "Arabic key presses are dispatched through CDP");

const PRICE_MINOR = 12_500;

/** Presses Tab until `target` has focus; fails after `limit` presses. */
async function tabTo(page: Page, target: Locator, limit = 80) {
  await expect(target).toBeVisible();
  for (let presses = 0; presses < limit; presses += 1) {
    if (await target.evaluate((element) => element === document.activeElement)) return;
    await page.keyboard.press("Tab");
  }
  await expect(target).toBeFocused();
}

/** One key press of `char` as a keyboard of its script sends it (Playwright only knows the US layout). */
async function pressChar(page: Page, char: string) {
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("Input.dispatchKeyEvent", { type: "keyDown", key: char, text: char, unmodifiedText: char });
  await cdp.send("Input.dispatchKeyEvent", { type: "keyUp", key: char });
  await cdp.detach();
}

/** Presses `key` until `done` holds; fails after `limit` presses. */
async function pressUntil(page: Page, key: string, done: () => Promise<boolean>, limit = 80) {
  for (let presses = 0; presses < limit; presses += 1) {
    if (await done()) return;
    await page.keyboard.press(key);
  }
  expect(await done(), `${key} pressed ${limit} times`).toBe(true);
}

test("the front desk books and checks out with the keyboard only", async ({ page, request, s, appLocale }) => {
  test.setTimeout(120_000);
  const ar = appLocale === "ar";
  const day = addDays(kuwaitToday(), 1);
  const shop = await freshShop(request, `kbd-${appLocale}`);
  const { serviceId, staffId, label } = await shopCatalogue(request, shop, { day, priceMinor: PRICE_MINOR });
  await ensureRegisterOpen(request, shop.owner, shop.branchId, { tenantId: shop.tenantId });

  // Sign in.
  await page.goto("/login");
  await tabTo(page, page.getByLabel(s.email));
  await page.keyboard.type(shop.owner);
  await tabTo(page, page.getByLabel(s.password, { exact: true }));
  await page.keyboard.type("password123");
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/calendar?branch=${shop.branchId}&date=${day}`);
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await expect(byStaff).toBeVisible();

  // Book: client, service, staff member, 15:00.
  await tabTo(page, page.getByRole("button", { name: s.newAppointment, exact: true }));
  await page.keyboard.press("Enter");
  const drawer = page.getByRole("dialog", { name: s.newAppointment });
  await expect(drawer).toBeVisible();
  await tabTo(page, drawer.getByLabel(s.findClient));
  await page.keyboard.type(`Noor ${label}`);
  await tabTo(page, drawer.getByRole("button", { name: new RegExp(label) }));
  await page.keyboard.press("Enter");

  const item = drawer.getByRole("region", { name: s.service, exact: true });
  const service = item.getByRole("combobox", { name: s.service, exact: true });
  // Type-to-select with the option's first letter; arrows on a closed select open the menu on macOS.
  await tabTo(page, service);
  await pressChar(page, ar ? "ت" : "F");
  await expect(service).toHaveValue(serviceId);
  const staff = item.getByRole("combobox", { name: s.staffMember });
  await tabTo(page, staff);
  await pressChar(page, ar ? "ه" : "H");
  await expect(staff).toHaveValue(staffId);
  const fifteen = item.getByRole("radio", { name: "15:00", exact: true });
  await tabTo(page, item.getByRole("radio").first());
  await pressUntil(page, "ArrowDown", () => fifteen.isChecked());
  await expect(fifteen).toBeFocused();

  await tabTo(page, drawer.getByRole("button", { name: s.bookAppointment }));
  await page.keyboard.press("Enter");
  await expect(drawer).toBeHidden();
  await expect(page.getByText(s.appointmentBooked)).toBeVisible();

  // Open it from the grid through the skip link.
  const event = byStaff.locator("[data-event-id]:not([id^='time-grid-event-copy-'])").filter({ hasText: label });
  await expect(event).toHaveCount(1);
  await tabTo(page, page.getByRole("button", { name: s.skipToAppointments }));
  await page.keyboard.press("Enter");
  await expect(event).toBeFocused();
  await page.keyboard.press("Enter");
  const appointment = page.getByRole("dialog", { name: new RegExp(label) });
  await expect(appointment).toBeVisible();

  // Check out: arrive, cash for the whole amount, complete.
  await tabTo(page, appointment.getByRole("button", { name: s.markArrivedAndCheckOut }));
  await page.keyboard.press("Enter");
  const checkout = page.getByRole("dialog", { name: s.checkOut });
  await expect(checkout).toBeVisible();
  await tabTo(page, checkout.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: s.cash, exact: true }));
  await page.keyboard.press("Enter");
  await expect(checkout.getByRole("group", { name: s.cash, exact: true }).getByRole("textbox", { name: s.amount })).toHaveValue("12.500");
  await tabTo(page, checkout.getByRole("button", { name: s.completeSale }));
  await page.keyboard.press("Enter");
  await expect(checkout).toBeHidden();

  const sale = await saleOf(request, { itemName: `Facial ${label}` });
  await expect(page.getByText(s.saleCompleted(sale.invoice_number))).toBeVisible();
  expect(sale.status).toBe("completed");
  expect(sale.totals.paid_minor).toBe(PRICE_MINOR);
});
