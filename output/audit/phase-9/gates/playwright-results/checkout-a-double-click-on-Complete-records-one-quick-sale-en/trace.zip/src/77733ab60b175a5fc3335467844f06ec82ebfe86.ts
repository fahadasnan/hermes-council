import type { APIRequestContext, Locator, Page } from "@playwright/test";
import { CHECKOUT_FIXTURES } from "@repo/core/checkout.fixtures";
import { addDays } from "./blockedTimeFlows";
import { admin, create, createClient, createService, createStaff, kuwait, REST } from "./bookingFixtures";
import { enableTips, ensureRegisterOpen, openCalendar, saleOf } from "./checkoutFixtures";
import { expect, test } from "./fixtures";
import { unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { AppLocale, Strings } from "./strings";

// Checkout at Setup Studio: en at Hawally as the receptionist, ar at Jahra as
// the owner (the only Jahra login), so the two projects never share a
// register. Visits are booked through the bookings function; every sale is
// made in the drawer and read back with the service key.

const place = (appLocale: AppLocale) =>
  appLocale === "en"
    ? { branchId: SETUP_BRANCH.hawally, actor: "setup-reception@spacorner.test", prefix: /^HWL-\d+$/ }
    : { branchId: SETUP_BRANCH.jahra, actor: "setup-owner@spacorner.test", prefix: /^JHR-\d+$/ };

const local = (appLocale: AppLocale, en: string, ar: string) => (appLocale === "ar" ? ar : en);

async function appointmentStatus(request: APIRequestContext, appointmentId: string): Promise<string> {
  const response = await request.get(`${REST}/appointments?id=eq.${appointmentId}&select=status`, { headers: admin });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { status: string }[])[0]!.status;
}

/** Types into a payment row; a new row starts at what is left to pay. */
async function addPayment(checkout: Locator, s: Strings, method: string, expectedPrefill: string, amount?: string) {
  await checkout.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: method, exact: true }).click();
  const input = checkout.getByRole("group", { name: method, exact: true }).getByRole("textbox", { name: s.amount });
  await expect(input).toHaveValue(expectedPrefill);
  if (amount) await input.fill(amount);
}

test("the Phase 6 AC journey: two staff, a line discount, a tip each, cash + KNET, completed once", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const { branchId, actor, prefix } = place(appLocale);
  await enableTips(request, branchId);
  await ensureRegisterOpen(request, actor, branchId);

  // G11: 25.000 and 18.500 by two people.
  const haircut = { en: `Haircut ${id}`, ar: `قص ${id}` };
  const blowDry = { en: `Blow-dry ${id}`, ar: `تجفيف ${id}` };
  const mona = { en: `Mona ${id}`, ar: `منى ${id}` };
  const huda = { en: `Huda ${id}`, ar: `هدى ${id}` };
  const haircutId = await createService(request, haircut, { duration: 60, price: 25_000 });
  const blowDryId = await createService(request, blowDry, { duration: 60, price: 18_500 });
  const shifts = [{ day, starts: "09:00", ends: "22:00" }];
  const monaId = await createStaff(request, { name: mona, branchId, serviceIds: [haircutId], shifts });
  const hudaId = await createStaff(request, { name: huda, branchId, serviceIds: [blowDryId], shifts });
  const clientId = await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  const visit = await create(request, actor, {
    branchId,
    clientId,
    items: [
      { service_id: haircutId, staff_id: monaId, starts_at: kuwait(day, "15:00") },
      { service_id: blowDryId, staff_id: hudaId, starts_at: kuwait(day, "16:00") },
    ],
  });

  await openCalendar(page, s, actor, branchId, day);
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await byStaff.locator("[data-event-id]:not([id^='time-grid-event-copy-'])").filter({ hasText: id }).first().click();
  const drawer = page.getByRole("dialog", { name: new RegExp(id) });
  await expect(drawer).toContainText(visit.ref);
  await drawer.getByRole("button", { name: s.markArrivedAndCheckOut }).click();
  const checkout = page.getByRole("dialog", { name: s.checkOut });
  await expect(checkout).toBeVisible();
  expect(await appointmentStatus(request, visit.id)).toBe("arrived");

  // 10% off the haircut, with a reason.
  const haircutName = local(appLocale, haircut.en, haircut.ar);
  await checkout.getByRole("button", { name: s.addDiscountTo(haircutName) }).click();
  const discount = checkout.getByRole("group", { name: s.discountOn(haircutName) });
  await discount.getByRole("radio", { name: s.percent }).click();
  await discount.getByRole("textbox", { name: s.discount }).fill("10");
  await discount.getByRole("textbox", { name: s.reason }).fill("Loyalty");

  // A tip for each of them.
  await checkout.getByRole("group", { name: s.tipFor(local(appLocale, mona.en, mona.ar)) }).getByRole("textbox", { name: s.amount }).fill("2.000");
  await checkout.getByRole("group", { name: s.tipFor(local(appLocale, huda.en, huda.ar)) }).getByRole("textbox", { name: s.amount }).fill("1.500");

  // Cash 20.000, then KNET fills the remaining 24.500.
  await addPayment(checkout, s, s.cash, "44.500", "20.000");
  await addPayment(checkout, s, s.knet, "24.500");

  // A double click records one sale (the second click is ignored, not refused).
  await checkout.getByRole("button", { name: s.completeSale }).dblclick();
  await expect(checkout).toBeHidden();

  const sale = await saleOf(request, { appointmentId: visit.id });
  await expect(page.getByText(s.saleCompleted(sale.invoice_number))).toBeVisible();
  expect(sale.invoice_number).toMatch(prefix);
  expect(sale.status).toBe("completed");
  expect(sale.totals).toEqual(CHECKOUT_FIXTURES.find((fixture) => fixture.id === "G11")!.totals);
  expect(sale.payments.map((p) => [p.payment_type, p.payment_method, p.amount_minor])).toEqual([
    ["payment", "cash", 20_000],
    ["payment", "knet_terminal", 24_500],
  ]);
  expect(sale.payments[0]!.register_session_id).not.toBeNull();
  expect(await appointmentStatus(request, visit.id)).toBe("completed");
});

async function quickSaleItem(page: Page, s: Strings, name: string, price: string) {
  await page.getByRole("button", { name: s.quickSale }).click();
  const checkout = page.getByRole("dialog", { name: s.quickSale });
  await checkout.getByRole("radio", { name: s.customItem }).click();
  await checkout.getByRole("textbox", { name: s.itemName }).fill(name);
  await checkout.getByRole("textbox", { name: s.price }).fill(price);
  await checkout.getByRole("button", { name: s.addItem }).click();
  return checkout;
}

test("a double click on Complete records one quick sale", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const { branchId, actor, prefix } = place(appLocale);
  await ensureRegisterOpen(request, actor, branchId);
  const name = local(appLocale, `Gift box ${id}`, `علبة هدايا ${id}`);

  await openCalendar(page, s, actor, branchId, kuwaitToday());
  const checkout = await quickSaleItem(page, s, name, "7.250");
  await addPayment(checkout, s, s.cash, "7.250");
  await checkout.getByRole("button", { name: s.completeSale }).dblclick();
  await expect(checkout).toBeHidden();

  const sale = await saleOf(request, { itemName: name });
  await expect(page.getByText(s.saleCompleted(sale.invoice_number))).toBeVisible();
  expect(sale.invoice_number).toMatch(prefix);
  expect(sale.status).toBe("completed");
  expect(sale.appointment_id).toBeNull();
  expect(sale.totals.paid_minor).toBe(7_250);
});

test("a walk-in quick sale is saved unpaid after a confirmation", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const { branchId, actor } = place(appLocale);
  const name = local(appLocale, `Shampoo ${id}`, `شامبو ${id}`);

  await openCalendar(page, s, actor, branchId, kuwaitToday());
  const checkout = await quickSaleItem(page, s, name, "4.500");
  await checkout.getByRole("button", { name: s.saveUnpaid }).click();
  const confirm = page.getByRole("alertdialog");
  await expect(confirm).toContainText("4.500");
  await confirm.getByRole("button", { name: s.saveUnpaid }).click();
  await expect(checkout).toBeHidden();

  const sale = await saleOf(request, { itemName: name });
  await expect(page.getByText(s.saleSavedUnpaid(sale.invoice_number))).toBeVisible();
  expect(sale.status).toBe("unpaid");
  expect(sale.client_id).toBeNull();
  expect(sale.totals.due_minor).toBe(4_500);
  expect(sale.payments).toEqual([]);
});
