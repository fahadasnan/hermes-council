import { readFile } from "node:fs/promises";
import {
  addNote,
  clientIdFromUrl,
  clientsTable,
  expectProfile,
  importCsv,
  listSearch,
  openClients,
  runPhone,
  shownName,
  submitNewClient,
  type NewClient,
} from "./clientFlows";
import { expect, signIn, test } from "./fixtures";
import { newPersonPage, unique } from "./memberFlows";

// Clients are tenant-wide (ADR-11). Reception works them, a manager blocks and
// deletes, only the owner imports, and staff never reach the clients screens.

test("reception adds a client, is warned about a shared phone, keeps notes and finds them; a manager blocks and deletes", async ({
  page,
  browser,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const phone = runPhone();
  const amira: NewClient = {
    firstName: "Amira",
    lastName: id,
    firstNameAlt: "أَمِيرة",
    lastNameAlt: id,
    phone,
    allergies: appLocale === "ar" ? "المكسرات" : "Nuts",
    tag: "vip",
  };
  const layla: NewClient = { firstName: appLocale === "ar" ? "ليلى" : "Layla", lastName: id, phone };
  const amiraName = shownName(amira, appLocale);
  const laylaName = shownName(layla, appLocale);

  await page.goto("/login");
  await signIn(page, s, "setup-reception@spacorner.test");
  await expect(page).not.toHaveURL(/\/login/);
  await openClients(page, s);
  await submitNewClient(page, s, amira);
  await expectProfile(page, s, amiraName);
  const amiraId = clientIdFromUrl(page);
  await expect(page.getByRole("region", { name: s.safety })).toContainText(amira.allergies!);
  await expect(page.getByRole("button", { name: s.blockAction, exact: true })).toHaveCount(0);
  await expect(page.getByRole("button", { name: s.deleteAction, exact: true })).toHaveCount(0);

  // Same phone: the warning links to the existing client; going ahead creates the second one.
  await openClients(page, s);
  await submitNewClient(page, s, layla);
  const warning = page.getByRole("alertdialog", { name: s.duplicateTitle });
  await expect(warning).toBeVisible();
  const match = warning.getByRole("listitem").filter({ hasText: amiraName });
  await expect(match).toContainText(s.samePhone);
  await expect(match.getByRole("link", { name: amiraName })).toHaveAttribute("href", new RegExp(`/clients/${amiraId}(\\?.*)?$`));
  await warning.getByRole("button", { name: s.createAnyway }).click();
  await expectProfile(page, s, laylaName);
  const laylaId = clientIdFromUrl(page);
  await addNote(page, s, appLocale === "ar" ? `تفضّل الضغط الخفيف ${id}` : `Prefers light pressure ${id}`);

  // List search: part of the phone finds both; Arabic without diacritics or hamza finds Amira.
  await openClients(page, s);
  await listSearch(page, s).fill(phone.slice(2));
  await expect(clientsTable(page).getByRole("link", { name: amiraName })).toBeVisible();
  await expect(clientsTable(page).getByRole("link", { name: laylaName })).toBeVisible();
  await listSearch(page, s).fill(`اميره ${id}`);
  await expect(clientsTable(page).getByRole("link", { name: amiraName })).toBeVisible();
  await expect(clientsTable(page).getByRole("link", { name: laylaName })).toHaveCount(0);
  await listSearch(page, s).fill(`zz${id}`);
  await expect(page.getByText(s.noClientsMatch(`zz${id}`))).toBeVisible();

  // Global search from anywhere: Ctrl+K, type, open.
  await page.keyboard.press("Control+k");
  const search = page.getByRole("dialog", { name: s.globalSearch });
  await search.getByLabel(s.globalSearchField).fill(id);
  await search.getByRole("link", { name: amiraName }).click();
  await expect(page).toHaveURL(new RegExp(`/clients/${amiraId}(\\?.*)?$`));

  // The manager blocks with a reason; the Blocked filter finds the client; then unblocks.
  const manager = await newPersonPage(browser, appLocale);
  await manager.goto("/login");
  await signIn(manager, s, "setup-manager@spacorner.test");
  await expect(manager).not.toHaveURL(/\/login/);
  await manager.goto(`/clients/${amiraId}`);
  await manager.getByRole("button", { name: s.blockAction, exact: true }).click();
  const block = manager.getByRole("dialog", { name: s.blockTitle });
  const reason = appLocale === "ar" ? "تغيب متكرر" : "Repeated no-shows";
  await block.getByLabel(s.blockReason).fill(reason);
  await block.getByRole("button", { name: s.blockClient }).click();
  await expect(manager.getByText(s.clientBlocked)).toBeVisible();
  const safety = manager.getByRole("region", { name: s.safety });
  await expect(safety).toContainText(s.blockedFromBooking);
  await expect(safety).toContainText(reason);
  await manager.goto(`/clients?q=${encodeURIComponent(id)}&blocked=true`);
  await expect(clientsTable(manager).getByRole("link", { name: amiraName })).toBeVisible();
  await expect(clientsTable(manager).getByRole("link", { name: laylaName })).toHaveCount(0);
  await clientsTable(manager).getByRole("link", { name: amiraName }).click();
  await manager.getByRole("button", { name: s.unblockAction, exact: true }).click();
  await manager.getByRole("button", { name: s.unblockClient }).click();
  await expect(manager.getByText(s.clientUnblocked)).toBeVisible();
  await expect(manager.getByText(s.blockedFromBooking)).toHaveCount(0);

  // A manager can delete; the client leaves the list.
  await manager.goto(`/clients/${laylaId}`);
  await manager.getByRole("button", { name: s.deleteAction, exact: true }).click();
  await manager.getByRole("button", { name: s.deleteClient }).click();
  await expect(manager.getByText(s.clientDeleted)).toBeVisible();
  await expect(manager).toHaveURL(/\/clients(\?.*)?$/);
  await listSearch(manager, s).fill(id);
  await expect(clientsTable(manager).getByRole("link", { name: amiraName })).toBeVisible();
  await expect(clientsTable(manager).getByRole("link", { name: laylaName })).toHaveCount(0);
  await manager.context().close();
});

test("staff can't open clients or search them", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "staff@spacorner.test");
  await expect(page).not.toHaveURL(/\/login/);
  await expect(page.getByRole("navigation").getByRole("link", { name: s.clients, exact: true })).toHaveCount(0);
  await expect(page.getByRole("banner").getByRole("button", { name: s.globalSearchButton })).toHaveCount(0);
  await page.goto("/clients");
  await expect(page.getByRole("heading", { level: 1, name: s.forbidden })).toBeVisible();
});

test("the owner imports a CSV: bad rows are reported, a repeated phone is skipped, and the leftovers download", async ({
  page,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const [first, second] = [runPhone(), runPhone()];
  const csv = importCsv(s, [
    ["Hala", `A ${id}`, first],
    ["Reem", `B ${id}`, second],
    ["Sara", `C ${id}`, "12"],
    ["Hala", `D ${id}`, first],
  ]);

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await expect(page).not.toHaveURL(/\/login/);
  await openClients(page, s);
  await page.getByRole("link", { name: s.importClients }).click();
  await page.getByLabel(s.clientListCsv).setInputFiles({ name: `clients-${id}.csv`, mimeType: "text/csv", buffer: Buffer.from(csv) });

  await expect(page.getByRole("heading", { name: s.oneRowCantImport })).toBeVisible();
  await expect(page.getByRole("table", { name: s.problems })).toContainText(s.phoneInvalidReason);
  await expect(page.getByRole("radio", { name: s.skipPolicy, exact: true })).toBeChecked();
  await page.getByRole("button", { name: s.importThree }).click();

  await expect(page.getByRole("heading", { name: s.importFinished })).toBeVisible();
  await expect(page.getByText(s.twoClientsAdded)).toBeVisible();
  const [download] = await Promise.all([
    page.waitForEvent("download"),
    page.getByRole("button", { name: s.downloadNotImported }).click(),
  ]);
  const text = await readFile(await download.path(), "utf8");
  expect(text).toContain(`C ${id}`);
  expect(text).toContain(s.phoneInvalidReason);
  expect(text).not.toContain(`D ${id}`);

  await page.getByRole("link", { name: s.viewClients }).click();
  await listSearch(page, s).fill(id);
  await expect(clientsTable(page).getByRole("link")).toHaveCount(2);
});
