import { expect, signIn, signOut, test } from "./fixtures";
import { acceptInvite, invite, newPersonPage, openMembers, unique } from "./memberFlows";

// Setup Studio (supabase/seed.sql) owner invites fresh people each run, so the
// seeded memberships the settings journeys rely on are never changed.

// Signing out ends every session of that user (Supabase's global scope), so the
// shared seed owner never signs out here; invitees get their own browser.
test("an owner invites a receptionist who accepts and works in one locked branch", async ({
  page,
  browser,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const email = `invitee-${id}@spacorner.test`;
  const name = `Noor ${id}`;
  const password = `Glow-${id}`;

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openMembers(page, s);
  await invite(page, s, { email, name, role: s.receptionistRole, branch: s.hawally });

  const invitee = await newPersonPage(browser, appLocale);
  await acceptInvite(invitee, request, s, email, password);
  await expect(invitee.getByRole("heading", { name: s.welcome(name) })).toBeVisible();
  await expect(invitee.getByRole("group", { name: s.branchLocked })).toContainText(s.hawally);
  await expect(invitee.getByRole("link", { name: s.settings })).toHaveCount(0);

  await signOut(invitee, s);
  await signIn(invitee, s, email, password);
  await expect(invitee.getByRole("group", { name: s.branchLocked })).toContainText(s.hawally);
  await invitee.context().close();

  await page.reload();
  await expect(page.getByRole("row", { name: new RegExp(name) })).not.toContainText(s.invitationSent);
});

test("a demoted manager loses settings on their next page load, without signing in again", async ({
  page,
  browser,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const email = `manager-${id}@spacorner.test`;
  const name = `Huda ${id}`;

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openMembers(page, s);
  await invite(page, s, { email, name, role: s.managerRole, branch: s.hawally });

  const target = await newPersonPage(browser, appLocale);
  await acceptInvite(target, request, s, email, `Glow-${id}`);
  await target.getByRole("link", { name: s.settings }).click();
  await expect(target.getByRole("heading", { level: 1, name: s.settings })).toBeVisible();

  await page.getByRole("button", { name: s.changeRoleFor(name) }).click();
  await page.getByRole("dialog").getByLabel(s.role).selectOption({ label: s.receptionistRole });
  await page.getByRole("button", { name: s.reviewChange }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: s.changeRole, exact: true }).click();
  await expect(page.getByText(s.roleUpdated(name))).toBeVisible();
  await expect(page.getByRole("row", { name: new RegExp(name) })).toContainText(s.receptionistRole);

  await target.goto("/settings");
  await expect(target.getByRole("heading", { name: s.forbidden })).toBeVisible();
  await target.goto("/");
  await expect(target.getByRole("group", { name: s.branchLocked })).toContainText(s.hawally);
  await expect(target.getByRole("link", { name: s.settings })).toHaveCount(0);
  await target.context().close();
});
