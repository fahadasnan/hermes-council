import type { Page } from "@playwright/test";
import { expect } from "./fixtures";
import type { AppLocale, Strings } from "./strings";

// Clients journeys shared by clients.spec.ts and the Phase 4 evidence run.
// Writes go to Setup Studio: the Deno suite expects SpaCorner's seeded
// duplicates (+96550010001 → Fatima, Mariam) to be the only ones there.

/** A Kuwaiti mobile no seed client has (seed phones are +965500100NN). */
export const runPhone = () => `9${Math.floor(Math.random() * 1e7).toString().padStart(7, "0")}`;

export type NewClient = {
  firstName: string;
  lastName?: string;
  firstNameAlt?: string;
  lastNameAlt?: string;
  phone: string;
  allergies?: string;
  tag?: string;
};

/** The name the list and profile show: Arabic script in Arabic, Latin in English. */
export function shownName(client: NewClient, appLocale: AppLocale): string {
  const arabic = /[\u0600-\u06FF]/;
  const primary = [client.firstName, client.lastName].filter(Boolean).join(" ");
  const alt = [client.firstNameAlt, client.lastNameAlt].filter(Boolean).join(" ");
  if (!alt) return primary;
  const primaryIsArabic = arabic.test(client.firstName);
  return (appLocale === "ar") === primaryIsArabic ? primary : alt;
}

export async function openClients(page: Page, s: Strings) {
  await page.getByRole("navigation").getByRole("link", { name: s.clients, exact: true }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.clients })).toBeVisible();
}

export async function fillClient(page: Page, s: Strings, client: NewClient) {
  await page.getByLabel(s.firstName, { exact: true }).fill(client.firstName);
  if (client.lastName) await page.getByLabel(s.lastName, { exact: true }).fill(client.lastName);
  if (client.firstNameAlt) await page.getByLabel(s.firstNameAlt, { exact: true }).fill(client.firstNameAlt);
  if (client.lastNameAlt) await page.getByLabel(s.lastNameAlt, { exact: true }).fill(client.lastNameAlt);
  await page.getByLabel(s.phone, { exact: true }).fill(client.phone);
  if (client.allergies) await page.getByLabel(s.allergies, { exact: true }).fill(client.allergies);
  if (client.tag) {
    await page.getByLabel(s.tags, { exact: true }).fill(client.tag);
    await page.getByRole("button", { name: s.addTag }).click();
  }
}

/** Opens the editor from the list and submits; the caller handles a duplicate warning. */
export async function submitNewClient(page: Page, s: Strings, client: NewClient) {
  await page.getByRole("link", { name: s.newClient }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.newClient })).toBeVisible();
  await fillClient(page, s, client);
  await page.getByRole("button", { name: s.addClient }).click();
}

export async function expectProfile(page: Page, s: Strings, name: string) {
  await expect(page.getByText(s.clientAdded)).toBeVisible();
  await expect(page).toHaveURL(/\/clients\/[0-9a-f-]{36}(\?.*)?$/);
  await expect(page.getByRole("heading", { level: 1, name })).toBeVisible();
}

export const clientIdFromUrl = (page: Page) => new URL(page.url()).pathname.split("/")[2]!;

export function listSearch(page: Page, s: Strings) {
  return page.getByRole("main").getByLabel(s.searchClients);
}

export function clientsTable(page: Page) {
  return page.getByRole("main").getByRole("table");
}

export async function addNote(page: Page, s: Strings, text: string) {
  await page.getByLabel(s.newNote).fill(text);
  await page.getByRole("button", { name: s.addNote }).click();
  await expect(page.getByText(s.noteAdded)).toBeVisible();
  await expect(page.getByRole("list", { name: s.notes })).toContainText(text);
}

/** A small CSV in the project language's template headers. */
export function importCsv(s: Strings, rows: Array<[string, string, string]>): string {
  const lines = [[s.firstName, s.lastName, s.phone], ...rows].map((cells) => cells.join(","));
  return `${lines.join("\r\n")}\r\n`;
}
