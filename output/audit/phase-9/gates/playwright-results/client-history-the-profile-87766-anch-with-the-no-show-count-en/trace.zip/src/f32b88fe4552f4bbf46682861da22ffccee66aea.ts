import type { Page } from "@playwright/test";
import { nextFullDay } from "./blockedTimeFlows";
import { assignToBranch, create, createClient, createService, createStaff, kuwait, setStatus } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { newPersonPage, unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { Strings } from "./strings";

// The client profile lists the client's visits across branches, labelled by
// branch, with their no-show count; RLS decides which branches a reader sees.

async function openProfile(page: Page, s: Strings, email: string, clientId: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/clients/${clientId}`);
  return page.getByRole("region", { name: s.appointments, exact: true });
}

const stat = (card: ReturnType<Page["getByRole"]>, label: string) => card.locator("dl > div").filter({ hasText: label }).locator("dd");

test("the profile lists visits at every branch the reader sees, labelled by branch, with the no-show count", async ({
  page,
  browser,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const day = nextFullDay(kuwaitToday());
  const serviceId = await createService(request, { en: `Facial ${id}`, ar: `تنظيف بشرة ${id}` }, { duration: 60 });
  const staffId = await createStaff(request, {
    name: { en: `Mona ${id}`, ar: `منى ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts: [{ day, starts: "09:00", ends: "14:00" }],
  });
  await assignToBranch(request, staffId, { branchId: SETUP_BRANCH.jahra, serviceIds: [serviceId], shifts: [{ day, starts: "14:00", ends: "22:00" }] });
  const clientId = await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  const at = (branchId: string, time: string) => ({
    branchId,
    clientId,
    items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(day, time) }],
  });
  const hawally = await create(request, "setup-reception@spacorner.test", at(SETUP_BRANCH.hawally, "10:00"));
  const missed = await create(request, "setup-reception@spacorner.test", at(SETUP_BRANCH.hawally, "12:00"));
  await setStatus(request, "setup-reception@spacorner.test", missed.id, "no_show");
  const jahra = await create(request, "setup-owner@spacorner.test", at(SETUP_BRANCH.jahra, "16:00"));

  // The owner sees both branches.
  const card = await openProfile(page, s, "setup-owner@spacorner.test", clientId);
  await expect(stat(card, s.appointments)).toHaveText("3");
  await expect(stat(card, s.noShows)).toHaveText("1");
  const upcoming = card.getByRole("list", { name: s.upcoming }).getByRole("listitem");
  await expect(upcoming).toHaveCount(2);
  await expect(upcoming.nth(0)).toContainText(s.hawally);
  await expect(upcoming.nth(0)).toContainText(hawally.ref);
  await expect(upcoming.nth(1)).toContainText(s.jahra);
  await expect(upcoming.nth(1)).toContainText(jahra.ref);
  // A no-show is history even when its time is still ahead.
  const past = card.getByRole("list", { name: s.past }).getByRole("listitem");
  await expect(past).toHaveCount(1);
  await expect(past.first()).toContainText(missed.ref);
  await expect(past.first()).toContainText(s.noShow);

  // The ref opens that branch's day on the calendar.
  await upcoming.nth(1).getByRole("link", { name: jahra.ref }).click();
  await expect(page).toHaveURL(new RegExp(`/calendar\\?.*branch=${SETUP_BRANCH.jahra}`));
  await expect(page).toHaveURL(new RegExp(`date=${day}`));
  await expect(page.getByRole("region", { name: s.appointmentsByStaff }).locator("[data-event-id]").filter({ hasText: id })).toBeVisible();

  // Hawally's front desk sees only Hawally's visits, and only those count.
  const reception = await newPersonPage(browser, appLocale);
  const hawallyCard = await openProfile(reception, s, "setup-reception@spacorner.test", clientId);
  await expect(stat(hawallyCard, s.appointments)).toHaveText("2");
  await expect(stat(hawallyCard, s.noShows)).toHaveText("1");
  await expect(hawallyCard.getByRole("list", { name: s.upcoming }).getByRole("listitem")).toHaveCount(1);
  await expect(hawallyCard).not.toContainText(jahra.ref);
  await reception.context().close();
});
