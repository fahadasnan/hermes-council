import { readFile } from "node:fs/promises";
import type { Download, Page } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { accessToken, ANON_KEY, API } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { knetSale, reportShop } from "./reportFixtures";
import type { Strings } from "./strings";

// 7.3-T5 export buttons and the exports page on a two-branch shop of its own:
//   the report CSV opens in Excel (UTF-8 BOM) with headers in the app's language;
//   the owner's full export becomes Ready (pg_cron drains the queue every 10 s) and each file downloads once by link;
//   managers get branch kinds only (R10) and a forged owner kind is refused; receptionists export nothing.

const BOM = [0xef, 0xbb, 0xbf];

async function open(page: Page, s: Strings, email: string, path: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(path);
}

async function bytesOf(download: Download): Promise<Buffer> {
  const path = await download.path();
  return readFile(path);
}

test.describe("exports", () => {
  test("the owner's sales CSV starts with a BOM and carries headers in the app's language", async ({ page, request, s }) => {
    const shop = await reportShop(request, "export-csv");
    await knetSale(request, shop, shop.branchId, 12_000);
    await open(page, s, shop.owner, "/reports/sales?branch=all&preset=today");

    await page.getByRole("button", { name: s.exportCsv }).click();
    const downloading = page.waitForEvent("download");
    await page.getByRole("dialog").getByRole("button", { name: s.byDay, exact: true }).click();
    const download = await downloading;
    expect(download.suggestedFilename()).toMatch(/^sales-by-day-\d{4}-\d{2}-\d{2}-to-\d{4}-\d{2}-\d{2}\.csv$/);

    const bytes = await bytesOf(download);
    expect([...bytes.subarray(0, 3)]).toEqual(BOM);
    const text = bytes.subarray(3).toString("utf8");
    expect(text.split(/\r?\n/)[0]).toContain(s.csvHeaderStart);
    expect(text).toContain("12.000");
  });

  test("the owner's full export becomes Ready and its files download by one-time link", async ({ page, request, s }) => {
    const shop = await reportShop(request, "export-full");
    await knetSale(request, shop, shop.branchId, 5_000);
    await open(page, s, shop.owner, "/reports");
    await page.getByRole("link", { name: s.exportsTitle, exact: true }).click();
    await expect(page).toHaveURL(/\/reports\/exports/);
    await expect(page.getByRole("heading", { level: 1, name: s.exportsTitle })).toBeVisible();

    await page.getByLabel(s.whatToExport).selectOption({ label: s.exportEverything });
    await page.getByRole("button", { name: s.startExport }).click();

    const jobs = page.getByRole("table", { name: s.recentExports, exact: true }).locator("tbody tr");
    await expect(jobs).toHaveCount(1);
    await expect(jobs.first()).toContainText(s.exportEverything);
    await expect(jobs.first().getByText(s.exportReady, { exact: true })).toBeVisible({ timeout: 60_000 });

    const files = jobs.first().getByRole("button");
    await expect(files).toHaveCount(18);
    const downloading = page.waitForEvent("download");
    await jobs.first().getByRole("button", { name: "clients.csv", exact: true }).click();
    const download = await downloading;
    const bytes = await bytesOf(download);
    expect([...bytes.subarray(0, 3)]).toEqual(BOM);
    expect(bytes.subarray(3).toString("utf8")).toContain("Noura");
  });

  test("the manager picks branch kinds only and a forged owner kind is refused", async ({ page, request, s }) => {
    const shop = await reportShop(request, "export-manager");
    const forged = await request.post(functionUrl(API, "reports", "export"), {
      headers: { apikey: ANON_KEY, authorization: `Bearer ${await accessToken(request, shop.manager)}`, "idempotency-key": crypto.randomUUID() },
      data: { tenant_id: shop.tenantId, kind: "clients_contacts" },
    });
    expect(forged.status()).toBe(403);
    expect(await forged.json()).toMatchObject({ ok: false, error: { code: "FORBIDDEN", details: { reason: "report_scope_denied" } } });

    await open(page, s, shop.manager, "/reports/exports");
    const kinds = page.getByLabel(s.whatToExport).locator("option");
    await expect(kinds).toHaveCount(8);
    await expect(kinds.filter({ hasText: s.exportAppointments })).toHaveCount(1);
    await expect(kinds.filter({ hasText: s.exportClientsContacts })).toHaveCount(0);
    await expect(kinds.filter({ hasText: s.exportEverything })).toHaveCount(0);

    await page.goto(`/sales/summary?branch=${shop.branchId}`);
    const downloading = page.waitForEvent("download");
    await page.getByRole("button", { name: s.exportCsv }).click();
    const download = await downloading;
    expect(download.suggestedFilename()).toMatch(/^daily-sales-summary-/);
    expect([...(await bytesOf(download)).subarray(0, 3)]).toEqual(BOM);
  });

  test("the receptionist has no export button and no exports page", async ({ page, request, s }) => {
    const shop = await reportShop(request, "export-reception");
    await open(page, s, shop.reception, `/sales/summary?branch=${shop.branchId}`);
    await expect(page.getByRole("heading", { level: 1, name: s.dailySummary })).toBeVisible();
    await expect(page.getByRole("button", { name: s.exportCsv })).toHaveCount(0);
    await page.goto("/reports/exports");
    await expect(page.getByText(s.forbidden)).toBeVisible();
  });
});
