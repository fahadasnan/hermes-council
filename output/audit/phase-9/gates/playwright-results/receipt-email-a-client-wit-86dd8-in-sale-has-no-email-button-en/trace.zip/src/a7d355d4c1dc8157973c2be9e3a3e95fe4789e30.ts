import type { APIRequestContext } from "@playwright/test";
import { admin, insert, REST } from "./bookingFixtures";
import { addMember, createSale, freshShop, walkInSale, type Shop } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { subjectsTo } from "./mailpit";

// 9.5-T4: "Email receipt" in the sale view. The receptionist sends it; the
// language starts on the client's (Arabic here) and can be switched. The
// receipt goes through the ledger and the local consumer to Mailpit. Sales
// carry no payment so no register is needed.

const DELIVERY = { timeout: 45_000 };

async function clientSale(request: APIRequestContext, shop: Shop, client: Record<string, unknown>) {
  const [row] = await insert(request, "clients", { tenant_id: shop.tenantId, ...client });
  const sale = await createSale(request, shop.owner, { ...walkInSale(shop, 4_000, []), client_id: row!.id });
  return { clientId: row!.id, sale };
}

async function receiptLocales(request: APIRequestContext, saleId: string): Promise<string[]> {
  const response = await request.get(
    `${REST}/notification_messages?kind=eq.receipt&payload->>sale_id=eq.${saleId}&select=locale&order=created_at`,
    { headers: admin },
  );
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { locale: string }[]).map((row) => row.locale);
}

test("the desk emails a receipt in the client's Arabic, then in English when asked", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  test.setTimeout(120_000);
  const shop = await freshShop(request, `receipt-mail-${appLocale}`);
  const receptionist = await addMember(request, shop, "receptionist");
  const email = `receipt-${shop.id}@example.com`;
  const { sale } = await clientSale(request, shop, {
    first_name: "Huda",
    last_name: shop.id,
    email,
    preferred_language: "ar",
  });

  await page.goto("/login");
  await signIn(page, s, receptionist);
  await page.goto(`/sales/${sale.id}?branch=${shop.branchId}`);
  await page.getByRole("button", { name: s.emailReceipt, exact: true }).click();
  const dialog = page.getByRole("dialog", { name: s.emailReceiptTitle(sale.invoice_number) });
  await expect(dialog.getByText(s.goesTo(email))).toBeVisible();
  await expect(dialog.getByLabel(s.emailLanguage)).toHaveValue("ar");
  await dialog.getByRole("button", { name: s.sendReceipt }).click();
  await expect(page.getByText(s.receiptOnItsWay(sale.invoice_number, email))).toBeVisible();
  await expect(dialog).toHaveCount(0);

  await expect.poll(() => subjectsTo(request, email), DELIVERY).toHaveLength(1);
  const [arabic] = await subjectsTo(request, email);
  expect(arabic).toContain("إيصالك من");
  expect(arabic).toContain(sale.invoice_number);

  // A second send in English: a new ledger row, an English subject.
  await page.getByRole("button", { name: s.emailReceipt, exact: true }).click();
  await expect(dialog.getByLabel(s.emailLanguage)).toHaveValue("ar");
  await dialog.getByLabel(s.emailLanguage).selectOption("en");
  await dialog.getByRole("button", { name: s.sendReceipt }).click();
  await expect(dialog).toHaveCount(0);
  await expect.poll(() => subjectsTo(request, email), DELIVERY).toHaveLength(2);
  const [english] = await subjectsTo(request, email);
  expect(english).toContain("Your receipt from");
  expect(await receiptLocales(request, sale.id)).toEqual(["ar", "en"]);
});

test("a client without an email is sent to their profile; a walk-in sale has no email button", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const shop = await freshShop(request, `receipt-none-${appLocale}`);
  const { clientId, sale } = await clientSale(request, shop, { first_name: "Dana", last_name: shop.id });
  const walkIn = await createSale(request, shop.owner, walkInSale(shop, 2_000, []));

  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await page.goto(`/sales/${sale.id}?branch=${shop.branchId}`);
  await page.getByRole("button", { name: s.emailReceipt, exact: true }).click();
  const dialog = page.getByRole("dialog", { name: s.emailReceiptTitle(sale.invoice_number) });
  await expect(dialog.getByText(s.noClientEmail)).toBeVisible();
  await expect(dialog.getByRole("button", { name: s.sendReceipt })).toHaveCount(0);
  await expect(dialog.getByRole("link", { name: s.addOneOnProfile })).toHaveAttribute(
    "href",
    new RegExp(`/clients/${clientId}`),
  );

  await page.goto(`/sales/${walkIn.id}?branch=${shop.branchId}`);
  await expect(page.getByRole("link", { name: s.printReceipt })).toBeVisible();
  await expect(page.getByRole("button", { name: s.emailReceipt, exact: true })).toHaveCount(0);
});
