import { expect, signIn, test } from "./fixtures";

// Seed ids (supabase/seed.sql)
const SPACORNER = "00000000-0000-4000-9000-000000000001";
const GLOW_LAB = "00000000-0000-4000-9000-000000000002";
const SALMIYA = "00000000-0000-4000-a000-000000000001";
const KUWAIT_CITY = "00000000-0000-4000-a000-000000000002";
const SHUWAIKH = "00000000-0000-4000-a000-000000000003";

const atBranch = (path: string, branch: string) => new RegExp(`${path}\\?branch=${branch}$`);

const cachedKeyRoots = (page: import("@playwright/test").Page) =>
  page.evaluate(() =>
    (window.__glowdeskQueryClient?.getQueryCache().getAll() ?? []).map((query) => String(query.queryKey[0])),
  );

const cachedTenantIds = (page: import("@playwright/test").Page) =>
  page.evaluate(() =>
    (window.__glowdeskQueryClient?.getQueryCache().getAll() ?? [])
      .filter((query) => query.queryKey[0] === "tenant")
      .map((query) => String(query.queryKey[1])),
  );

test("a multi-tenant user switches tenant: the cache clears and the scope follows", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "multi@spacorner.test");

  const topbar = page.getByRole("banner");
  const company = topbar.getByRole("combobox", { name: s.company });
  // First tenant by name until the user picks one.
  await expect(company).toHaveValue(GLOW_LAB);
  await expect(page).toHaveURL(atBranch("/", SHUWAIKH));
  await expect(topbar.getByText(s.ownerRole, { exact: true })).toBeVisible();
  await expect(topbar.getByRole("group", { name: s.branchLocked })).toContainText(s.shuwaikh);

  // Something tenant-scoped is cached before the switch.
  await page.evaluate((tenantId) => window.__glowdeskQueryClient?.setQueryData(["tenant", tenantId, "probe"], 1), GLOW_LAB);
  expect(await cachedKeyRoots(page)).toContain("tenant");

  await company.selectOption({ label: s.tenantName });

  await expect(company).toHaveValue(SPACORNER);
  await expect(page).toHaveURL(atBranch("/", SALMIYA));
  await expect(topbar.getByText(s.managerRole, { exact: true })).toBeVisible();
  await expect(topbar.getByRole("group", { name: s.branchLocked })).toContainText(s.salmiya);
  // Nothing from the old tenant survives; the top bar may already have fetched the new tenant's register.
  for (const root of await cachedKeyRoots(page)) expect(["session", "tenant"]).toContain(root);
  for (const tenantId of await cachedTenantIds(page)) expect(tenantId).toBe(SPACORNER);

  // The choice is remembered for this user on this device.
  await page.reload();
  await expect(company).toHaveValue(SPACORNER);
  await expect(page).toHaveURL(atBranch("/", SALMIYA));
});

test("the branch lives in the URL and survives reloads, navigation and deep links", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "owner@spacorner.test");

  const branch = page.getByRole("banner").getByRole("combobox", { name: s.branch });
  await expect(page).toHaveURL(atBranch("/", KUWAIT_CITY));
  await expect(branch).toHaveValue(KUWAIT_CITY);
  await expect(branch.locator("option")).toHaveText([s.allBranches, s.kuwaitCity, s.salmiya]);

  await branch.selectOption({ label: s.salmiya });
  await expect(page).toHaveURL(atBranch("/", SALMIYA));

  await page.reload();
  await expect(branch).toHaveValue(SALMIYA);

  // In-app navigation keeps the branch.
  await page.getByRole("link", { name: s.settings }).click();
  await expect(page).toHaveURL(atBranch("/settings", SALMIYA));

  // A shared link opens on its own branch.
  await page.goto(`/settings?branch=${KUWAIT_CITY}`);
  await expect(page).toHaveURL(atBranch("/settings", KUWAIT_CITY));
  await expect(branch).toHaveValue(KUWAIT_CITY);

  // Without a branch in the URL, the last one picked on this device opens.
  await page.goto("/");
  await expect(page).toHaveURL(atBranch("/", SALMIYA));

  await branch.selectOption({ label: s.allBranches });
  await expect(page).toHaveURL(atBranch("/", "all"));
});

test("a receptionist's branch is locked and out-of-scope branches redirect", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "reception@spacorner.test");

  const topbar = page.getByRole("banner");
  await expect(page).toHaveURL(atBranch("/", SALMIYA));
  await expect(topbar.getByRole("group", { name: s.branchLocked })).toContainText(s.salmiya);
  await expect(topbar.getByRole("combobox", { name: s.branch })).toHaveCount(0);

  // Another branch, "all" with a single branch, another tenant's branch, and garbage.
  for (const value of [KUWAIT_CITY, "all", SHUWAIKH, "not-a-branch"]) {
    await page.goto(`/?branch=${value}`);
    await expect(page).toHaveURL(atBranch("/", SALMIYA));
  }
});
