import type { APIRequestContext, Page } from "@playwright/test";
import type { SaleCreateInput } from "@repo/validation";
import { createClient, SETUP_TENANT } from "./bookingFixtures";
import {
  attemptRefund,
  attemptVoid,
  closeRegister,
  createSale,
  ensureRegisterOpen,
  freshShop,
  paymentIdsOf,
  walkInSale,
  type CreatedSale,
} from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { SETUP_BRANCH } from "./staffFlows";
import type { AppLocale, Strings } from "./strings";

// The sales list and the sale page at Setup Studio. Other specs sell at
// Hawally and Jahra at the same time, so every list check goes through a
// client whose Arabic surname belongs to this run alone; the payments list's
// method totals need a `freshShop`. Money moves through the checkout function
// as real logins; the service key only adds the client.

const RECEPTION = "setup-reception@spacorner.test"; // Reem Hawally, receptionist at Hawally
const MANAGER = "setup-manager@spacorner.test"; // Maryam Hawally, manager at Hawally
const OWNER = "setup-owner@spacorner.test";

const LETTERS = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي";

/** An Arabic-letters-only surname that no other run shares. */
function arabicTag(): string {
  let n = Date.now() * 1000 + Math.floor(Math.random() * 1000);
  let tag = "";
  while (n > 0) {
    tag = LETTERS[n % LETTERS.length] + tag;
    n = Math.floor(n / LETTERS.length);
  }
  return tag;
}

const arabicIndic = (text: string) => text.replace(/\d/g, (digit) => "٠١٢٣٤٥٦٧٨٩"[Number(digit)]!);

type Seeded = { tag: string; paid: CreatedSale; unpaid: CreatedSale; voided: CreatedSale; jahra: CreatedSale };

/**
 * Today, for one client: at Hawally a paid sale (15.000 KNET), an unpaid one
 * (8.000) and one voided by the manager (5.000); at Jahra a paid sale (9.000 KNET).
 */
async function seed(request: APIRequestContext, appLocale: AppLocale): Promise<Seeded> {
  const tag = arabicTag();
  const clientId = await createClient(request, { firstName: "Lulwa", lastName: `Sales ${appLocale}`, firstNameAlt: "لولوة", lastNameAlt: tag });
  const sell = (actor: string, branchId: string, priceMinor: number, payments: SaleCreateInput["payments"]) =>
    createSale(request, actor, {
      tenant_id: SETUP_TENANT,
      branch_id: branchId,
      client_id: clientId,
      lines: [{ type: "manual_item", name_en: `Gift voucher ${tag}`, unit_price_minor: priceMinor }],
      tips: [],
      payments,
      expected: { total_minor: priceMinor, tip_minor: 0, grand_total_minor: priceMinor },
    });
  const paid = await sell(RECEPTION, SETUP_BRANCH.hawally, 15_000, [{ method: "knet_terminal", amount_minor: 15_000 }]);
  const unpaid = await sell(RECEPTION, SETUP_BRANCH.hawally, 8_000, []);
  const voided = await sell(RECEPTION, SETUP_BRANCH.hawally, 5_000, [{ method: "knet_terminal", amount_minor: 5_000 }]);
  const voiding = await attemptVoid(request, MANAGER, { saleId: voided.id, reason: "Rang up twice" });
  expect(voiding.status, JSON.stringify(voiding.body)).toBe(200);
  const jahra = await sell(OWNER, SETUP_BRANCH.jahra, 9_000, [{ method: "knet_terminal", amount_minor: 9_000 }]);
  return { tag, paid, unpaid, voided, jahra };
}

function salesPage(page: Page, s: Strings) {
  const totals = page.getByRole("region", { name: s.totalsForFilters });
  return {
    search: page.getByRole("searchbox", { name: s.searchSales }),
    table: page.getByRole("table", { name: s.salesTitle }),
    totals,
    stat: (label: string) => totals.locator("dl > div").filter({ has: page.getByText(label, { exact: true }) }),
    /** The live-sale count, then the voided note when there is one. */
    counts: () => totals.locator("dl > div").first().locator("dd > span > span"),
  };
}

test("reception finds a sale by invoice number and by an Arabic client name, and never sees another branch's sale", async ({ page, request, s, appLocale }) => {
  const seeded = await seed(request, appLocale);
  await page.goto("/login");
  await signIn(page, s, RECEPTION);
  await expect(page).toHaveURL(new RegExp(`\\?branch=${SETUP_BRANCH.hawally}`));

  await page.getByRole("link", { name: s.salesTitle, exact: true }).click();
  await expect(page).toHaveURL(/\/sales\?branch=/);
  const { search, table, stat, counts } = salesPage(page, s);

  // An invoice number typed with Arabic-Indic digits still finds the sale.
  await search.fill(arabicIndic(seeded.paid.invoice_number));
  await expect(table.getByRole("link", { name: seeded.paid.invoice_number, exact: true })).toBeVisible();

  // Her branch's three sales for the client, newest first; Jahra's stays out of the list and the totals.
  await search.fill(seeded.tag);
  await expect(table.getByRole("link")).toHaveText([seeded.voided.invoice_number, seeded.unpaid.invoice_number, seeded.paid.invoice_number]);
  await expect(counts().first()).toHaveText("2");
  await expect(counts().nth(1)).toHaveText(s.oneVoided);
  await expect(stat(s.salesTotal)).toContainText("23.000");
  await expect(stat(s.paid)).toContainText("15.000");
  await expect(stat(s.balanceDue)).toContainText("8.000");

  await page.getByRole("combobox", { name: s.statusFilter }).selectOption({ label: s.unpaid });
  await expect(table.getByRole("link")).toHaveText([seeded.unpaid.invoice_number]);
  await expect(stat(s.salesTotal)).toContainText("8.000");
  await page.getByRole("combobox", { name: s.statusFilter }).selectOption({ index: 0 });

  await search.fill(seeded.jahra.invoice_number);
  await expect(page.getByText(s.noSalesMatch(seeded.jahra.invoice_number))).toBeVisible();

  // Even by its address, the Jahra sale isn't there for her.
  await page.goto(`/sales/${seeded.jahra.id}?branch=${SETUP_BRANCH.hawally}`);
  await expect(page.getByText(s.saleNotFound, { exact: true })).toBeVisible();

  // Her own sale opens as a page, without the history (owners and managers only).
  await page.getByRole("link", { name: s.allSales }).click();
  await search.fill(seeded.tag);
  await table.getByRole("link", { name: seeded.paid.invoice_number, exact: true }).click();
  await expect(page).toHaveURL(new RegExp(`/sales/${seeded.paid.id}`));
  await expect(page.getByRole("main")).toContainText(seeded.paid.invoice_number);
  await expect(page.getByRole("list", { name: s.paymentsAndRefunds })).toContainText(s.knet);
  await expect(page.getByRole("region", { name: s.history })).toHaveCount(0);
});

test("an owner sees every branch's sales, and a sale's history says who did what", async ({ page, request, s, appLocale }) => {
  const seeded = await seed(request, appLocale);
  await page.goto("/login");
  await signIn(page, s, OWNER);
  await expect(page).toHaveURL(/\?branch=/);

  await page.goto(`/sales?branch=all&q=${encodeURIComponent(seeded.tag)}`);
  const { table, stat, counts } = salesPage(page, s);
  await expect(table.getByRole("link")).toHaveText([
    seeded.jahra.invoice_number,
    seeded.voided.invoice_number,
    seeded.unpaid.invoice_number,
    seeded.paid.invoice_number,
  ]);
  await expect(table.getByRole("row").filter({ hasText: seeded.jahra.invoice_number })).toContainText(s.jahra);
  await expect(counts().first()).toHaveText("3");
  await expect(stat(s.salesTotal)).toContainText("32.000");
  await expect(stat(s.paid)).toContainText("24.000");
  await expect(stat(s.balanceDue)).toContainText("8.000");

  await table.getByRole("link", { name: seeded.paid.invoice_number, exact: true }).click();
  const history = page.getByRole("region", { name: s.history });
  const entries = history.getByRole("listitem");
  await expect(entries).toHaveCount(2);
  await expect(entries.nth(0)).toContainText(s.saleRecordedFor(""));
  await expect(entries.nth(0)).toContainText("15.000");
  await expect(entries.nth(0)).toContainText(s.byName("Reem Hawally"));
  await expect(entries.nth(1)).toContainText(s.paymentOf(s.knet, ""));
  await expect(entries.nth(1)).toContainText(s.byName("Reem Hawally"));

  // The void: who voided it and why, and the refund it made.
  await page.goto(`/sales/${seeded.voided.id}`);
  await expect(history).toContainText(s.historyVoided);
  await expect(history).toContainText("Rang up twice");
  await expect(history.getByRole("listitem").filter({ hasText: s.historyVoided })).toContainText(s.byName("Maryam Hawally"));
});

test("the payments list flags a cash refund made with the register closed, and adds up each method", async ({ page, request, s }) => {
  // A shop of its own, so the method totals hold this test's money alone.
  const shop = await freshShop(request, "payments");
  const session = await ensureRegisterOpen(request, shop.owner, shop.branchId, { tenantId: shop.tenantId });
  const cash = await createSale(request, shop.owner, walkInSale(shop, 20_000, [{ method: "cash", amount_minor: 20_000 }]));
  const knet = await createSale(request, shop.owner, walkInSale(shop, 10_000, [{ method: "knet_terminal", amount_minor: 10_000 }]));
  await closeRegister(request, shop.owner, session, { tenantId: shop.tenantId });
  const [cashPayment] = await paymentIdsOf(request, cash.id);
  const refund = await attemptRefund(request, shop.owner, { tenantId: shop.tenantId, paymentId: cashPayment!, reason: "Client changed her mind" });
  expect(refund.status, JSON.stringify(refund.body)).toBe(201);

  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await expect(page).toHaveURL(/\?branch=/);
  await page.getByRole("link", { name: s.salesTitle, exact: true }).click();
  await page.getByRole("link", { name: s.paymentsTitle, exact: true }).click();
  await expect(page).toHaveURL(/\/sales\/payments\?/);

  // Newest first: the refund, the KNET payment, the cash payment; each links to its sale.
  const table = page.getByRole("table", { name: s.paymentsTitle });
  await expect(table.getByRole("link")).toHaveText([cash.invoice_number, knet.invoice_number, cash.invoice_number]);
  const flagged = table.getByRole("row").filter({ hasText: s.outsideRegisterSession });
  await expect(flagged).toHaveCount(1);
  await expect(flagged).toContainText("Client changed her mind");
  await expect(flagged).toContainText("20.000");

  const byMethod = page.getByRole("region", { name: s.byMethod });
  const zero = /(^|\D)0\.000/;
  const cells = (label: string) => byMethod.getByRole("row").filter({ hasText: label }).getByRole("cell");
  await expect(cells(s.cash)).toHaveText([/20\.000/, /20\.000/, zero]);
  await expect(cells(s.knet)).toHaveText([/10\.000/, zero, /10\.000/]);
  await expect(cells(s.total)).toHaveText([/30\.000/, /20\.000/, /10\.000/]);

  // Filters narrow the list; the method totals stay those of the days shown.
  await page.getByRole("combobox", { name: s.typeFilter }).selectOption({ label: s.refundsOnly });
  await expect(table.getByRole("link")).toHaveText([cash.invoice_number]);
  await expect(cells(s.total)).toHaveText([/30\.000/, /20\.000/, /10\.000/]);
  await page.getByRole("combobox", { name: s.typeFilter }).selectOption({ index: 0 });
  await page.getByRole("combobox", { name: s.methodFilter }).selectOption({ label: s.knet });
  await expect(table.getByRole("link")).toHaveText([knet.invoice_number]);

  await table.getByRole("link", { name: knet.invoice_number, exact: true }).click();
  await expect(page).toHaveURL(new RegExp(`/sales/${knet.id}`));
  await expect(page.getByRole("main")).toContainText(knet.invoice_number);
});
