import type { APIRequestContext } from "@playwright/test";
import { admin, insert, REST } from "./bookingFixtures";
import { addMember, freshShop, type Shop } from "./checkoutFixtures";
import { expect, signIn, signOut, test } from "./fixtures";
import { subjectsTo } from "./mailpit";

// 9.5-T4: the owner's data access requests screen. Requests are recorded the
// way online_request_data_access leaves them (the booking app's privacy page
// and the notifications suite cover that path); the approval then runs for
// real: the client_data export, the link email to Mailpit, `delivered`.

type StoredRequest = { status: string; decline_reason: string | null; export_job_id: string | null };

async function client(request: APIRequestContext, shop: Shop, firstName: string) {
  const email = `${firstName.toLowerCase()}-${shop.id}@example.com`;
  const [row] = await insert(request, "clients", {
    tenant_id: shop.tenantId,
    first_name: firstName,
    last_name: shop.id,
    email,
    phone: `+9656${String(Math.floor(Math.random() * 10_000_000)).padStart(7, "0")}`,
  });
  await insert(request, "data_access_requests", {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    client_id: row!.id,
    locale: "ar",
    verification_id: crypto.randomUUID(),
  });
  return { id: row!.id, name: `${firstName} ${shop.id}`, email };
}

async function storedRequest(request: APIRequestContext, clientId: string): Promise<StoredRequest> {
  const response = await request.get(
    `${REST}/data_access_requests?client_id=eq.${clientId}&select=status,decline_reason,export_job_id`,
    { headers: admin },
  );
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as StoredRequest[])[0]!;
}

async function decisionsAudited(request: APIRequestContext, tenantId: string): Promise<number> {
  const response = await request.get(
    `${REST}/audit_log?tenant_id=eq.${tenantId}&action=eq.DATA_ACCESS_DECIDED&select=id`,
    { headers: admin },
  );
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as unknown[]).length;
}

test("the owner approves one request (the client gets the link) and declines another with a reason", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  test.setTimeout(200_000);
  const shop = await freshShop(request, `data-${appLocale}`);
  const manager = await addMember(request, shop, "branch_manager");
  const maryam = await client(request, shop, "Maryam");
  const sara = await client(request, shop, "Sara");

  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await page.goto("/settings");
  await page.getByRole("link", { name: s.dataAccessRequests }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.dataAccessRequests })).toBeVisible();
  const rows = page.getByRole("table", { name: s.dataAccessRequests }).getByRole("row");
  const rowOf = (name: string) => rows.filter({ hasText: name });
  await expect(rowOf(maryam.name)).toContainText(s.waitingForYou);
  await expect(rowOf(sara.name)).toContainText(s.waitingForYou);

  await rowOf(maryam.name)
    .getByRole("button", { name: s.approveRequestOf(maryam.name) })
    .click();
  const approve = page.getByRole("alertdialog", { name: s.approveRequestTitle(maryam.name) });
  await approve.getByRole("button", { name: s.approve }).click();
  await expect(page.getByText(s.requestApproved)).toBeVisible();
  await expect(rowOf(maryam.name).getByRole("button", { name: s.approveRequestOf(maryam.name) })).toHaveCount(0);
  expect((await storedRequest(request, maryam.id)).export_job_id).toBeTruthy();

  await rowOf(sara.name)
    .getByRole("button", { name: s.declineRequestOf(sara.name) })
    .click();
  const decline = page.getByRole("dialog", { name: s.declineRequestTitle(sara.name) });
  await decline.getByRole("button", { name: s.declineRequest }).click();
  await expect(decline.getByText(s.enterReason)).toBeVisible();
  await decline.getByLabel(s.reason).fill("Asked by phone to cancel the request");
  await decline.getByRole("button", { name: s.declineRequest }).click();
  await expect(page.getByText(s.requestDeclined)).toBeVisible();
  await expect(rowOf(sara.name)).toContainText(s.declined);
  await expect(rowOf(sara.name)).toContainText("Asked by phone to cancel the request");
  expect(await storedRequest(request, sara.id)).toMatchObject({
    status: "declined",
    decline_reason: "Asked by phone to cancel the request",
    export_job_id: null,
  });
  expect(await decisionsAudited(request, shop.tenantId)).toBe(2);

  // The export runs on its own schedule; once the link is sent the row says so.
  await expect
    .poll(async () => (await storedRequest(request, maryam.id)).status, { timeout: 150_000, intervals: [2_000, 5_000] })
    .toBe("delivered");
  expect(await subjectsTo(request, maryam.email)).toEqual([expect.stringContaining("جاهزة")]);
  await page.reload();
  await expect(rowOf(maryam.name)).toContainText(s.linkSent);

  // A manager has neither the settings entry nor the page.
  await signOut(page, s);
  await signIn(page, s, manager);
  await page.goto("/settings");
  await expect(page.getByRole("link", { name: s.dataAccessRequests })).toHaveCount(0);
  await page.goto("/settings/data-requests");
  await expect(page.getByRole("heading", { name: s.forbidden })).toBeVisible();
});
