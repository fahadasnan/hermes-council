import { createSale, enableTips } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { figure, kuwaitNow, reportJson, reportShop } from "./reportFixtures";

// 7.2-T6 My sales (R4) on My day, for a staff login on a shop of its own. One
// sale at Main: a 10.000 service by Huda (the staff login), one by Mariam, and
// a 1.500 tip for Huda. Huda's card shows her line and her tip only.

test("a staff login sees their own sales and tips on My day, equal to report_own_sales", async ({ page, request, s }) => {
  const { day } = kuwaitNow();
  const shop = await reportShop(request, "my-sales");
  await enableTips(request, shop.branchId);
  await createSale(request, shop.owner, {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    lines: [
      { type: "service", service_id: shop.serviceId, staff_id: shop.loginStaffId },
      { type: "service", service_id: shop.serviceId, staff_id: shop.mainStaffId },
    ],
    tips: [{ staff_id: shop.loginStaffId, amount_minor: 1_500 }],
    payments: [{ method: "knet_terminal", amount_minor: 21_500 }],
    expected: { total_minor: 20_000, tip_minor: 1_500, grand_total_minor: 21_500 },
  });
  const rpc = await reportJson<{ totals: { line_count: number; lines_minor: number; tips_minor: number } }>(request, shop.staffLogin, "report_own_sales", {
    p_tenant_id: shop.tenantId,
    p_from: day,
    p_to: day,
  });
  expect(rpc.totals).toMatchObject({ line_count: 1, lines_minor: 10_000, tips_minor: 1_500 });

  await page.goto("/login");
  await signIn(page, s, shop.staffLogin);
  await expect(page).toHaveURL(/\?branch=/);
  await page.getByRole("navigation", { name: s.mainNav }).getByRole("link", { name: s.myDay }).click();
  const card = page.getByRole("region", { name: s.mySales });
  await expect(card.getByRole("radio", { name: s.today })).toBeChecked();
  await expect(figure(card, s.itemsSold)).toHaveText("1");
  await expect(figure(card, s.salesGroup)).toContainText("10.000");
  await expect(figure(card, s.tipsFigure)).toContainText("1.500");

  await card.getByRole("radio", { name: s.thisMonth }).click();
  await expect(card.getByRole("radio", { name: s.thisMonth })).toBeChecked();
  await expect(figure(card, s.itemsSold)).toHaveText("1");
  await expect(figure(card, s.salesGroup)).toContainText("10.000");
  await expect(card.getByRole("button", { name: /export|csv|تصدير/i })).toHaveCount(0);
});
