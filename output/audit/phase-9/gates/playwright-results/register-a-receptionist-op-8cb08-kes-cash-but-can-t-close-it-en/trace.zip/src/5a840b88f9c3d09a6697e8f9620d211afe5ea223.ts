import type { Page } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import {
  addMember,
  attemptCloseRegister,
  attemptSale,
  createSale,
  freshShop,
  openCalendar,
  registerSessionsOf,
  saleOf,
  shopVisit,
  walkInSale,
  type ShopVisit,
} from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { kuwaitToday } from "./shiftFlows";
import type { Strings } from "./strings";

// The register day, each journey in a tenant of its own (`freshShop`) so no
// other spec's register is touched. Open and close go through the UI; sales
// taken "at the desk meanwhile" go through the checkout function as the same
// login, and the service key only reads results back.

const PRICE = 12_000;

const registerBar = (page: Page, s: Strings) => page.getByRole("banner").getByRole("group", { name: s.cashRegister });

/** Opens the visit's checkout drawer from the calendar. */
async function checkOutVisit(page: Page, s: Strings, visit: ShopVisit) {
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await byStaff.locator("[data-event-id]:not([id^='time-grid-event-copy-'])").filter({ hasText: visit.label }).first().click();
  const appointment = page.getByRole("dialog", { name: new RegExp(visit.label) });
  await appointment.getByRole("button", { name: s.checkOut, exact: true }).click();
  return page.getByRole("dialog", { name: s.checkOut });
}

test("a manager opens the register, recounts after cash moved, and the difference is shown and stored", async ({ page, request, s, appLocale }) => {
  const shop = await freshShop(request, `reg-${appLocale}`);
  const manager = await addMember(request, shop, "branch_manager");
  await page.goto("/login");
  await signIn(page, s, manager);
  await expect(page).toHaveURL(/\?branch=/);

  const bar = registerBar(page, s);
  await expect(bar.getByText(s.registerClosed)).toBeVisible();
  await bar.getByRole("button", { name: s.openRegister }).click();
  const opening = page.getByRole("dialog", { name: s.openTheRegister });
  await opening.getByRole("textbox", { name: s.openingCash }).fill("50");
  await opening.getByRole("button", { name: s.openRegister }).dblclick();
  await expect(opening).toBeHidden();
  await expect(bar.getByText(s.registerOpen)).toBeVisible();
  await expect(bar).toContainText(s.openedByYou);
  await expect(bar).toContainText("50.000");

  // Cash and card taken at the desk meanwhile; only the cash is the drawer's.
  await createSale(request, manager, walkInSale(shop, 100_000, [{ method: "cash", amount_minor: 100_000 }]));
  await createSale(request, manager, walkInSale(shop, 30_000, [{ method: "card_terminal", amount_minor: 30_000 }]));
  await page.reload();
  await expect(bar).toContainText("150.000");

  await bar.getByRole("button", { name: s.closeRegister }).click();
  const closing = page.getByRole("dialog", { name: s.closeTheRegister });
  await expect(closing).toContainText("50.000");
  await expect(closing).toContainText("150.000");

  // Another cash sale lands while she counts: the close is refused and the numbers refresh.
  await createSale(request, manager, walkInSale(shop, 27_500, [{ method: "cash", amount_minor: 27_500 }]));
  await closing.getByRole("textbox", { name: s.cashCounted }).fill("180");
  await expect(closing.getByText(s.overBy("30.000"))).toBeVisible();
  await closing.getByRole("button", { name: s.closeRegister }).click();
  await expect(closing.getByText(s.cashMoved, { exact: false })).toBeVisible();
  await expect(closing).toContainText("177.500");
  await expect(closing.getByText(s.overBy("2.500"))).toBeVisible();

  await closing.getByRole("textbox", { name: s.note }).fill("Change found under the till");
  await closing.getByRole("button", { name: s.closeRegister }).dblclick();
  const closed = page.getByRole("dialog", { name: s.registerClosed });
  await expect(closed).toContainText("180.000");
  await expect(closed.getByText(s.overBy("2.500"))).toBeVisible();
  await closed.getByRole("button", { name: s.done }).click();
  await expect(closed).toBeHidden();
  await expect(bar.getByText(s.registerClosed)).toBeVisible();
  await expect(bar.getByRole("button", { name: s.openRegister })).toBeFocused();

  // One session: 50.000 + 100.000 + 27.500 expected, 180.000 counted, +2.500 kept with the note.
  const sessions = await registerSessionsOf(request, shop.branchId);
  expect(sessions).toHaveLength(1);
  expect(sessions[0]).toMatchObject({
    opening_cash_minor: 50_000,
    expected_cash_minor: 177_500,
    counted_cash_minor: 180_000,
    difference_minor: 2_500,
    close_note: "Change found under the till",
  });
  expect(sessions[0]!.closed_at).not.toBeNull();
});

test("cash is refused with the register closed, and taken outside a session once the owner turns the rule off", async ({ page, request, s, appLocale }) => {
  const shop = await freshShop(request, `regoff-${appLocale}`);
  const day = addDays(kuwaitToday(), 1);
  const visit = await shopVisit(request, shop, shop.owner, { day, priceMinor: PRICE });

  // The function is the guard, not the disabled button.
  const refused = await attemptSale(request, shop.owner, walkInSale(shop, 5_000, [{ method: "cash", amount_minor: 5_000 }]));
  expect(refused.status, JSON.stringify(refused.body)).toBe(409);
  expect("error" in refused.body && refused.body.error.details?.reason).toBe("register_closed");

  await openCalendar(page, s, shop.owner, shop.branchId, day);
  let checkout = await checkOutVisit(page, s, visit);
  await expect(checkout.getByText(s.registerClosedNoCash, { exact: false })).toBeVisible();
  await expect(checkout.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: s.cash, exact: true })).toBeDisabled();
  await checkout.getByRole("button", { name: s.close, exact: true }).click();

  await page.goto(`/settings/branches/${shop.branchId}/methods`);
  await page.getByLabel(s.requireRegister).uncheck();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.methodsSaved)).toBeVisible();

  await page.goto(`/calendar?branch=${shop.branchId}&date=${day}`);
  checkout = await checkOutVisit(page, s, visit);
  await expect(checkout.getByText(s.registerClosedNoCash, { exact: false })).toHaveCount(0);
  await checkout.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: s.cash, exact: true }).click();
  await expect(checkout.getByRole("group", { name: s.cash, exact: true }).getByRole("textbox", { name: s.amount })).toHaveValue("12.000");
  await checkout.getByRole("button", { name: s.completeSale }).click();
  await expect(checkout).toBeHidden();
  await expect(registerBar(page, s).getByText(s.registerClosed)).toBeVisible();

  // Taken in no register session (the daily summary flags it); no session was opened.
  const sale = await saleOf(request, { appointmentId: visit.id });
  expect(sale.status).toBe("completed");
  expect(sale.payments).toEqual([{ payment_type: "payment", payment_method: "cash", amount_minor: PRICE, register_session_id: null }]);
  expect(await registerSessionsOf(request, shop.branchId)).toHaveLength(0);
});

test("a receptionist opens the register from checkout and takes cash, but can't close it", async ({ page, request, s, appLocale }) => {
  const shop = await freshShop(request, `regrc-${appLocale}`);
  const reception = await addMember(request, shop, "receptionist");
  const day = addDays(kuwaitToday(), 1);
  const visit = await shopVisit(request, shop, reception, { day, priceMinor: PRICE });

  await openCalendar(page, s, reception, shop.branchId, day);
  const bar = registerBar(page, s);
  await expect(bar.getByRole("button", { name: s.openRegister })).toBeVisible();

  const checkout = await checkOutVisit(page, s, visit);
  await expect(checkout.getByText(s.registerClosedNoCash, { exact: false })).toBeVisible();
  await checkout.getByRole("button", { name: s.openRegister }).click();
  const opening = page.getByRole("dialog", { name: s.openTheRegister });
  await opening.getByRole("textbox", { name: s.openingCash }).fill("20");
  await opening.getByRole("button", { name: s.openRegister }).click();
  await expect(opening).toBeHidden();
  await expect(checkout.locator("[tabindex='-1']", { hasText: s.registerNowOpen })).toBeFocused();

  await checkout.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: s.cash, exact: true }).click();
  await checkout.getByRole("button", { name: s.completeSale }).click();
  await expect(checkout).toBeHidden();

  // Open, but closing is an owner's or a manager's: no control, and the function refuses her.
  await expect(bar.getByText(s.registerOpen)).toBeVisible();
  await expect(bar).toContainText("32.000");
  await expect(bar.getByRole("button", { name: s.closeRegister })).toHaveCount(0);
  const [session] = await registerSessionsOf(request, shop.branchId);
  const refused = await attemptCloseRegister(request, reception, {
    tenantId: shop.tenantId,
    sessionId: session!.id,
    countedCashMinor: 32_000,
    expectedCashMinor: 32_000,
  });
  expect(refused.status, JSON.stringify(refused.body)).toBe(403);
  expect("error" in refused.body && refused.body.error.code).toBe("FORBIDDEN");

  const sale = await saleOf(request, { appointmentId: visit.id });
  expect(sale.payments).toEqual([{ payment_type: "payment", payment_method: "cash", amount_minor: PRICE, register_session_id: session!.id }]);
  expect((await registerSessionsOf(request, shop.branchId))[0]!.closed_at).toBeNull();
});
