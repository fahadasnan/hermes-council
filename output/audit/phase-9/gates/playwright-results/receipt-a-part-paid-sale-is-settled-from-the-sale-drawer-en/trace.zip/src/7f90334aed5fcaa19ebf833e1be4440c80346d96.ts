import type { APIRequestContext, Page } from "@playwright/test";
import type { SaleCreateInput } from "@repo/validation";
import { addDays } from "./blockedTimeFlows";
import { admin, create, createClient, createService, createStaff, kuwait, REST, SETUP_TENANT, setStatus } from "./bookingFixtures";
import { attemptRefund, attemptVoid, createSale, enableTips, ensureRegisterOpen, openCalendar, saleOf } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { AppLocale, Strings } from "./strings";

// The sale drawer and the 80 mm receipt at Setup Studio: en at Hawally (the
// receptionist sells, the manager refunds and voids), ar at Jahra (the owner
// does everything; it is the only Jahra login). Sales are made through the
// checkout function; the drawer settles and the receipt prints them.

const place = (appLocale: AppLocale) =>
  appLocale === "en"
    ? { branchId: SETUP_BRANCH.hawally, seller: "setup-reception@spacorner.test", refunder: "setup-manager@spacorner.test" }
    : { branchId: SETUP_BRANCH.jahra, seller: "setup-owner@spacorner.test", refunder: "setup-owner@spacorner.test" };

const PHONE = "+96522667788";
const CLIENT_PHONE = "+96555443322";

/** Receipt details on the branch; the receipt prints them in its language. */
async function brandBranch(request: APIRequestContext, branchId: string) {
  const response = await request.patch(`${REST}/branches?id=eq.${branchId}`, {
    headers: admin,
    data: {
      address: "Block 2, Tunis Street",
      phone: PHONE,
      receipt_header_en: "Thank you for visiting",
      receipt_header_ar: "شكراً لزيارتكم",
      receipt_footer_en: "See you soon",
      receipt_footer_ar: "نراكم قريباً",
    },
  });
  expect(response.ok(), await response.text()).toBe(true);
}

async function namesOf(request: APIRequestContext, branchId: string) {
  const [tenant] = (await (await request.get(`${REST}/tenants?id=eq.${SETUP_TENANT}&select=name_en,name_ar`, { headers: admin })).json()) as {
    name_en: string;
    name_ar: string;
  }[];
  const [branch] = (await (await request.get(`${REST}/branches?id=eq.${branchId}&select=name_en,name_ar`, { headers: admin })).json()) as {
    name_en: string;
    name_ar: string;
  }[];
  const [tax] = (await (
    await request.get(`${REST}/tax_rates?tenant_id=eq.${SETUP_TENANT}&is_default=eq.true&select=name_en,name_ar`, { headers: admin })
  ).json()) as { name_en: string | null; name_ar: string | null }[];
  return { tenant: tenant!, branch: branch!, tax: tax! };
}

async function appointmentItems(request: APIRequestContext, appointmentId: string): Promise<{ id: string; staff_id: string }[]> {
  const response = await request.get(`${REST}/appointment_items?appointment_id=eq.${appointmentId}&select=id,staff_id&order=sort_order`, {
    headers: admin,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return (await response.json()) as { id: string; staff_id: string }[];
}

/** A visit tomorrow for a new client with one 25.000 service, marked arrived. */
async function arrivedVisit(request: APIRequestContext, appLocale: AppLocale, id: string) {
  const { branchId, seller } = place(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const serviceId = await createService(request, { en: `Haircut ${id}`, ar: `قص ${id}` }, { duration: 60, price: 25_000 });
  const staffName = { en: `Mona ${id}`, ar: `منى ${id}` };
  const staffId = await createStaff(request, { name: staffName, branchId, serviceIds: [serviceId], shifts: [{ day, starts: "09:00", ends: "22:00" }] });
  const client = { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: `العلي ${id}`, phone: CLIENT_PHONE };
  const clientId = await createClient(request, client);
  const visit = await create(request, seller, {
    branchId,
    clientId,
    items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(day, "15:00") }],
  });
  await setStatus(request, seller, visit.id, "arrived");
  const [item] = await appointmentItems(request, visit.id);
  return { day, visit, clientId, staffId, staffName, client, itemId: item!.id };
}

async function openReceipt(page: Page, s: Strings, actor: string, saleId: string, lang: AppLocale) {
  await page.goto("/login");
  await signIn(page, s, actor);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/sales/${saleId}/receipt?lang=${lang}`);
  return page.locator("article[lang]");
}

test("a part-paid sale is settled from the sale drawer", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const { branchId, seller } = place(appLocale);
  await ensureRegisterOpen(request, seller, branchId);
  const { day, visit, clientId, itemId } = await arrivedVisit(request, appLocale, id);
  const sale = await createSale(request, seller, {
    tenant_id: SETUP_TENANT,
    branch_id: branchId,
    appointment_id: visit.id,
    client_id: clientId,
    lines: [{ type: "appointment_item", appointment_item_id: itemId }],
    tips: [],
    payments: [{ method: "knet_terminal", amount_minor: 10_000 }],
    expected: { total_minor: 25_000, tip_minor: 0, grand_total_minor: 25_000 },
  });
  expect(sale.status).toBe("part_paid");

  await openCalendar(page, s, seller, branchId, day);
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await byStaff.locator("[data-event-id]:not([id^='time-grid-event-copy-'])").filter({ hasText: id }).first().click();
  const appointment = page.getByRole("dialog", { name: new RegExp(id) });
  await appointment.getByRole("button", { name: s.viewSale }).click();

  const drawer = page.getByRole("dialog", { name: s.sale, exact: true });
  await expect(drawer).toContainText(sale.invoice_number);
  await expect(drawer.getByText(s.partPaid, { exact: true })).toBeVisible();
  await expect(drawer.getByRole("link", { name: s.printReceipt })).toHaveAttribute("href", `/sales/${sale.id}/receipt`);
  await expect(drawer.getByText(s.balanceDue)).toBeVisible();

  await drawer.getByRole("button", { name: s.settleBalance }).click();
  await drawer.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: s.cash, exact: true }).click();
  await expect(drawer.getByRole("group", { name: s.cash, exact: true }).getByRole("textbox", { name: s.amount })).toHaveValue("15.000");
  await drawer.getByRole("button", { name: s.recordPayment }).dblclick();
  await expect(drawer.getByText(s.paidInFull(sale.invoice_number))).toBeVisible();
  await expect(drawer.getByText(s.paid, { exact: true })).toBeVisible();
  await expect(drawer.getByRole("button", { name: s.settleBalance })).toHaveCount(0);

  // Settled once: a cash payment in the open register clears the balance.
  const stored = await saleOf(request, { id: sale.id });
  expect(stored.status).toBe("completed");
  expect(stored.totals.due_minor).toBe(0);
  expect(stored.payments.map((p) => [p.payment_method, p.amount_minor])).toEqual([
    ["knet_terminal", 10_000],
    ["cash", 15_000],
  ]);
  expect(stored.payments[1]!.register_session_id).not.toBeNull();
});

test("the receipt prints every mandated element in its own language, 80 mm wide in print", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const { branchId, seller, refunder } = place(appLocale);
  await brandBranch(request, branchId);
  await enableTips(request, branchId);
  await ensureRegisterOpen(request, seller, branchId);
  const { visit, clientId, staffId, staffName, client, itemId } = await arrivedVisit(request, appLocale, id);

  // 25.000 less 2.500, plus 2 × 3.000, less 1.000: 27.500, a 2.000 tip, 29.500 due; 15.000 paid.
  const oil = { en: `Hair oil ${id}`, ar: `زيت شعر ${id}` };
  const input: SaleCreateInput = {
    tenant_id: SETUP_TENANT,
    branch_id: branchId,
    appointment_id: visit.id,
    client_id: clientId,
    lines: [
      { type: "appointment_item", appointment_item_id: itemId, discount: { fixed_minor: 2_500 }, discount_reason: "Loyalty" },
      { type: "manual_item", name_en: oil.en, name_ar: oil.ar, unit_price_minor: 3_000, quantity: 2 },
    ],
    sale_discount: { fixed_minor: 1_000 },
    discount_reason: "Promo",
    tips: [{ staff_id: staffId, amount_minor: 2_000 }],
    payments: [
      { method: "cash", amount_minor: 10_000 },
      { method: "knet_terminal", amount_minor: 5_000 },
    ],
    expected: { total_minor: 27_500, tip_minor: 2_000, grand_total_minor: 29_500 },
  };
  const sale = await createSale(request, seller, input);
  const knet = await request.get(`${REST}/payments?sale_id=eq.${sale.id}&payment_method=eq.knet_terminal&select=id`, { headers: admin });
  const [knetPayment] = (await knet.json()) as { id: string }[];
  const refund = await attemptRefund(request, refunder, { paymentId: knetPayment!.id, reason: "Changed mind" });
  expect(refund.status, JSON.stringify(refund.body)).toBe(201);

  const names = await namesOf(request, branchId);
  const local = (en: string, ar: string) => (appLocale === "ar" ? ar : en);
  const receipt = await openReceipt(page, s, seller, sale.id, appLocale);
  await expect(receipt).toHaveAttribute("lang", appLocale);
  await expect(receipt).toHaveAttribute("dir", appLocale === "ar" ? "rtl" : "ltr");
  await expect(receipt).toHaveAccessibleName(local(`Receipt ${sale.invoice_number}`, `إيصال ${sale.invoice_number}`));

  // Header: tenant, branch, address, phone, header text.
  await expect(receipt).toContainText(local(names.tenant.name_en, names.tenant.name_ar));
  await expect(receipt).toContainText(local(names.branch.name_en, names.branch.name_ar));
  await expect(receipt).toContainText("Block 2, Tunis Street");
  await expect(receipt.locator("bdi[dir=ltr]", { hasText: PHONE })).toBeVisible();
  await expect(receipt).toContainText(local("Thank you for visiting", "شكراً لزيارتكم"));
  await expect(receipt).toContainText(local("See you soon", "نراكم قريباً"));

  // Invoice number (isolated LTR), date, client name and a Latin phone isolated inside an RTL receipt (F-i18n-1).
  await expect(receipt.getByText(s.invoiceNo)).toBeVisible();
  await expect(receipt.locator("bdi[dir=ltr]", { hasText: sale.invoice_number })).toBeVisible();
  await expect(receipt).toContainText(local(`${client.firstName} ${client.lastName}`, `${client.firstNameAlt} ${client.lastNameAlt}`));
  await expect(receipt.locator("bdi[dir=ltr]", { hasText: CLIENT_PHONE })).toBeVisible();

  // Lines with quantity, unit price, discount and total.
  await expect(receipt).toContainText(local(`Haircut ${id}`, `قص ${id}`));
  await expect(receipt).toContainText(local(oil.en, oil.ar));
  await expect(receipt).toContainText(/2 × [^\n]*3\.000/);
  await expect(receipt).toContainText(/1 × [^\n]*25\.000/);
  await expect(receipt).toContainText(/-[^\n]{0,4}2\.500/);
  // Line totals carry their share of the sale discount, so they add up to the total.
  await expect(receipt).toContainText(/21\.711/);
  await expect(receipt).toContainText(/5\.789/);

  // Subtotal, discounts, tax by rate, total, tips by staff, amount due.
  await expect(receipt.getByText(s.subtotal, { exact: true })).toBeVisible();
  await expect(receipt.getByText(s.itemDiscounts, { exact: true })).toBeVisible();
  await expect(receipt.getByText(s.saleDiscountFor("Promo"))).toBeVisible();
  await expect(receipt.getByText(local(`Tax: ${names.tax.name_en ?? names.tax.name_ar}`, `الضريبة: ${names.tax.name_ar ?? names.tax.name_en}`))).toBeVisible();
  await expect(receipt.getByText(s.total, { exact: true })).toBeVisible();
  await expect(receipt.getByText(s.tipFor(local(staffName.en, staffName.ar)))).toBeVisible();
  await expect(receipt.getByText(s.amountDue, { exact: true })).toBeVisible();
  await expect(receipt).toContainText(/29\.500/);

  // Payments by method, the refund, what was paid and the balance (refunds never reopen it).
  await expect(receipt.getByText(s.cash, { exact: true })).toBeVisible();
  await expect(receipt.getByText(s.knet, { exact: true })).toBeVisible();
  await expect(receipt.getByText(s.refundOf(s.knet))).toBeVisible();
  await expect(receipt.getByText(s.amountPaid, { exact: true })).toBeVisible();
  await expect(receipt.getByText(s.refunded, { exact: true })).toBeVisible();
  await expect(receipt.getByText(s.balanceDue, { exact: true })).toBeVisible();
  await expect(receipt).toContainText(/14\.500/);
  await expect(receipt.getByText(s.voidedMark, { exact: true })).toHaveCount(0);

  // Print: the toolbar goes, the paper is the 72 mm printable width of an 80 mm roll.
  const print = page.getByRole("button", { name: s.print, exact: true });
  await expect(print).toBeVisible();
  await page.emulateMedia({ media: "print" });
  await expect(print).toBeHidden();
  await expect(page.getByRole("group", { name: s.receiptLanguage })).toBeHidden();
  const box = await receipt.boundingBox();
  expect(Math.abs(box!.width - (72 / 25.4) * 96)).toBeLessThan(2);
  await page.emulateMedia({ media: "screen" });

  // The toggle reprints in the other language; the app stays in its own.
  const other = appLocale === "en" ? "ar" : "en";
  await page.getByRole("group", { name: s.receiptLanguage }).getByRole("link", { name: other === "ar" ? "العربية" : "English" }).click();
  await expect(receipt).toHaveAttribute("lang", other);
  await expect(receipt).toHaveAttribute("dir", other === "ar" ? "rtl" : "ltr");
  await expect(receipt).toContainText(other === "ar" ? "رقم الفاتورة" : "Invoice #");
  await expect(page.locator("html")).toHaveAttribute("lang", appLocale);
});

test("a voided sale's receipt is marked VOIDED and shows no balance", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const { branchId, seller, refunder } = place(appLocale);
  const sale = await createSale(request, seller, {
    tenant_id: SETUP_TENANT,
    branch_id: branchId,
    client_id: null,
    lines: [{ type: "manual_item", name_en: `Gift card ${id}`, unit_price_minor: 1_000 }],
    tips: [],
    payments: [{ method: "knet_terminal", amount_minor: 1_000 }],
    expected: { total_minor: 1_000, tip_minor: 0, grand_total_minor: 1_000 },
  });
  const voided = await attemptVoid(request, refunder, { saleId: sale.id, reason: "Rang up by mistake" });
  expect(voided.status, JSON.stringify(voided.body)).toBe(200);

  const receipt = await openReceipt(page, s, seller, sale.id, appLocale);
  await expect(receipt.getByText(s.voidedMark, { exact: true })).toBeVisible();
  await expect(receipt).toContainText("Rang up by mistake");
  await expect(receipt).toContainText(s.walkIn);
  await expect(receipt.getByText(s.refundOf(s.knet))).toBeVisible();
  await expect(receipt.getByText(s.balanceDue, { exact: true })).toHaveCount(0);
});
