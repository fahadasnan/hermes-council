import { readFile } from "node:fs/promises";
import type { APIRequestContext, Page } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { admin, API, ANON_KEY, insert, REST } from "./bookingFixtures";
import { addMember, freshShop, shopCatalogue, type Shop } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { kuwaitToday } from "./shiftFlows";
import type { Strings } from "./strings";

// Settings → branch → Online booking, on a business of its own per run
// (provision_tenant through the local service key): the owner switches the
// page on, copies the link, downloads the QR code, prints the card and takes
// a service and a staff member off the page; a manager edits the page but not
// the tenant-wide service flag. The public page is read through the
// online-booking function, as the booking app reads it.

const BOOKING_APP = "http://127.0.0.1:5174";

type StoredOnline = { is_enabled: boolean; slug: string | null; min_notice_minutes: number };

async function storedOnline(request: APIRequestContext, branchId: string): Promise<StoredOnline> {
  const response = await request.get(
    `${REST}/online_booking_settings?branch_id=eq.${branchId}&select=is_enabled,slug,min_notice_minutes`,
    { headers: admin },
  );
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as StoredOnline[])[0]!;
}

async function onlineFlag(request: APIRequestContext, table: "services" | "staff_members", id: string): Promise<boolean> {
  const response = await request.get(`${REST}/${table}?id=eq.${id}&select=online_bookable`, { headers: admin });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { online_bookable: boolean }[])[0]!.online_bookable;
}

/** The booking page as a visitor's browser loads it: 404 when it's off, else its services. */
async function publicPage(request: APIRequestContext, shop: Shop, linkName: string) {
  const query = new URLSearchParams({ tenant_slug: tenantSlug(shop), branch_slug: linkName });
  const response = await request.get(`${functionUrl(API, "online-booking", "page")}?${query}`, {
    headers: { apikey: ANON_KEY, origin: BOOKING_APP, "x-forwarded-for": `198.51.100.${Math.floor(Math.random() * 250) + 1}` },
  });
  if (response.status() === 404) return null;
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { data: { services: { id: string }[] } }).data;
}

const tenantSlug = (shop: Shop) => `checkout-${shop.id}`;

async function openOnlineTab(page: Page, s: Strings, actor: string, branchId: string) {
  await page.goto("/login");
  await signIn(page, s, actor);
  await page.goto(`/settings/branches/${branchId}/online`);
  await expect(page.getByRole("link", { name: s.onlineBookingTab })).toHaveAttribute("aria-current", "page");
}

test("owner switches the booking page on, shares its link and QR code, and chooses what it offers", async ({
  page,
  context,
  request,
  s,
  other,
  appLocale,
}) => {
  test.setTimeout(90_000);
  const shop = await freshShop(request, `online-${appLocale}`);
  const catalogue = await shopCatalogue(request, shop, { day: kuwaitToday(), priceMinor: 10_000 });
  const serviceName = appLocale === "en" ? `Facial ${catalogue.label}` : `تنظيف بشرة ${catalogue.label}`;
  const staffName = appLocale === "en" ? `Huda ${catalogue.label}` : `هدى ${catalogue.label}`;
  const link = `${BOOKING_APP}/${tenantSlug(shop)}/main-hall`;
  await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin: "http://127.0.0.1:5173" });

  await openOnlineTab(page, s, shop.owner, shop.branchId);

  // The page can't go on without a link name.
  await page.getByLabel(s.takeBookingsOnline).check();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.slugRequired)).toBeVisible();
  expect((await storedOnline(request, shop.branchId)).is_enabled).toBe(false);

  // Typed in capitals with spaces, saved as the link name.
  await page.getByLabel(s.linkName).fill("  Main-Hall ");
  await page.getByLabel(s.minimumNotice).selectOption("60");
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.onlineSaved)).toBeVisible();
  expect(await storedOnline(request, shop.branchId)).toEqual({ is_enabled: true, slug: "main-hall", min_notice_minutes: 60 });
  expect((await publicPage(request, shop, "main-hall"))?.services.map((x) => x.id)).toEqual([catalogue.serviceId]);

  // The link, copied as shown.
  await expect(page.getByRole("link", { name: link, exact: true })).toHaveAttribute("href", link);
  await page.getByRole("button", { name: s.copyLink }).click();
  await expect(page.getByText(s.linkCopied)).toBeVisible();
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(link);

  // The QR code, on screen and as files.
  await expect(page.getByRole("img", { name: s.bookingLinkQr })).toBeVisible();
  const [svg] = await Promise.all([page.waitForEvent("download"), page.getByRole("button", { name: s.downloadSvg }).click()]);
  expect(svg.suggestedFilename()).toBe("booking-main-hall-qr.svg");
  expect(await readFile(await svg.path(), "utf8")).toMatch(/^<svg xmlns="http:\/\/www\.w3\.org\/2000\/svg" viewBox="0 0 \d+ \d+"/);
  const [png] = await Promise.all([page.waitForEvent("download"), page.getByRole("button", { name: s.downloadPng }).click()]);
  expect(png.suggestedFilename()).toBe("booking-main-hall-qr.png");
  expect((await readFile(await png.path())).subarray(0, 8)).toEqual(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));

  // The printable card, in either language.
  await page.getByRole("link", { name: s.printableCard }).click();
  await expect(page).toHaveURL(new RegExp(`/settings/branches/${shop.branchId}/online-card`));
  const card = page.getByRole("article");
  await expect(card.getByText(s.bookYourVisit)).toBeVisible();
  await expect(card.getByRole("img", { name: s.bookingPageQr })).toBeVisible();
  await expect(card.getByText(link, { exact: true })).toBeVisible();
  await page.getByRole("link", { name: s.languageButton }).click();
  await expect(card.getByText(other.bookYourVisit)).toBeVisible();
  await expect(card).toHaveAttribute("dir", other.dir);
  // The language switch replaces the history entry, so one step back is the tab.
  await page.goBack();

  // Off the page: the service, then the staff member.
  const service = page.getByRole("checkbox", { name: serviceName });
  await expect(service).toBeChecked();
  await service.uncheck();
  await expect(page.getByText(s.onlineOff(serviceName))).toBeVisible();
  await expect(service).not.toBeChecked();
  expect(await onlineFlag(request, "services", catalogue.serviceId)).toBe(false);
  expect((await publicPage(request, shop, "main-hall"))?.services).toEqual([]);

  const staff = page.getByRole("checkbox", { name: staffName });
  await staff.uncheck();
  await expect(page.getByText(s.onlineOff(staffName))).toBeVisible();
  expect(await onlineFlag(request, "staff_members", catalogue.staffId)).toBe(false);
  await staff.check();
  await expect(page.getByText(s.onlineOn(staffName))).toBeVisible();
  expect(await onlineFlag(request, "staff_members", catalogue.staffId)).toBe(true);

  // Switched off again: the link stays, the page is gone.
  await page.getByLabel(s.takeBookingsOnline).uncheck();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.onlineSaved)).toBeVisible();
  await expect(page.getByText(s.onlineOffNotice)).toBeVisible();
  expect(await publicPage(request, shop, "main-hall")).toBeNull();
});

test("a manager edits the booking page but not the services, and a link name in use is refused", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const shop = await freshShop(request, `online-mgr-${appLocale}`);
  const catalogue = await shopCatalogue(request, shop, { day: kuwaitToday(), priceMinor: 5_000 });
  const manager = await addMember(request, shop, "branch_manager");
  const [seef] = await insert(request, "branches", { tenant_id: shop.tenantId, name_en: `Seef ${shop.id}`, name_ar: `السيف ${shop.id}` });
  const taken = await request.patch(`${REST}/online_booking_settings?branch_id=eq.${seef!.id}`, {
    headers: admin,
    data: { slug: "seef" },
  });
  expect(taken.ok(), await taken.text()).toBe(true);

  await openOnlineTab(page, s, manager, shop.branchId);

  await page.getByLabel(s.linkName).fill("seef");
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.slugTaken)).toBeVisible();
  expect((await storedOnline(request, shop.branchId)).slug).toBeNull();

  await page.getByLabel(s.linkName).fill("main");
  await page.getByLabel(s.takeBookingsOnline).check();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.onlineSaved)).toBeVisible();
  expect(await storedOnline(request, shop.branchId)).toMatchObject({ is_enabled: true, slug: "main" });

  // A service's online flag is the owner's: shown, not changeable.
  const serviceName = appLocale === "en" ? `Facial ${catalogue.label}` : `تنظيف بشرة ${catalogue.label}`;
  await expect(page.getByText(s.servicesOwnerOnly)).toBeVisible();
  await expect(page.getByRole("checkbox", { name: serviceName })).toBeDisabled();
});
