import type { APIRequestContext, Page } from "@playwright/test";
import { expect, signIn, test } from "./fixtures";
import { figure, knetSale, kuwaitNow, reportJson, reportShop, type ReportShop } from "./reportFixtures";
import type { Strings } from "./strings";

// 7.2-T3 money reports on a two-branch shop of its own, today in Kuwait:
//   Main:   20.000 by KNET and 7.500 by card; Second: 5.000 by KNET (zero-rated custom items, no staff member)
// Every branch: 3 sales, 32.500; Main: 2 sales, 27.500.

type Totals = { count: number; grand_total_minor: number };

async function shopWithSales(request: APIRequestContext, label: string): Promise<{ shop: ReportShop; day: string }> {
  const shop = await reportShop(request, label);
  await knetSale(request, shop, shop.branchId, 20_000);
  await knetSale(request, shop, shop.branchId, 7_500, "card_terminal");
  await knetSale(request, shop, shop.secondBranchId, 5_000);
  return { shop, day: kuwaitNow().day };
}

async function open(page: Page, s: Strings, email: string, path: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(path);
}

const table = (page: Page, caption: string) => page.getByRole("table", { name: caption, exact: true });
const bodyRows = (page: Page, caption: string) => table(page, caption).locator("tbody tr");
const totalRow = (page: Page, caption: string) => table(page, caption).locator("tfoot tr");

test.describe("money reports", () => {
  test("the sales summary equals the RPC and splits by branch, day, item and staff member", async ({ page, request, s }) => {
    const { shop, day } = await shopWithSales(request, "money-sales");
    const rpc = await reportJson<{ totals: Totals }>(request, shop.owner, "report_sales_summary", { p_tenant_id: shop.tenantId, p_from: day, p_to: day });
    expect(rpc.totals).toMatchObject({ count: 3, grand_total_minor: 32_500 });

    await open(page, s, shop.owner, "/reports/sales?branch=all&preset=today");
    const totals = page.getByRole("region", { name: s.totals, exact: true });
    await expect(figure(totals, s.salesTitle)).toHaveText("3");
    await expect(figure(totals, s.salesTotal)).toContainText("32.500");

    await expect(bodyRows(page, s.byBranch)).toHaveCount(2);
    await expect(bodyRows(page, s.byBranch).filter({ hasText: "27.500" })).toHaveCount(1);
    await expect(bodyRows(page, s.byBranch).filter({ hasText: "5.000" })).toHaveCount(1);
    await expect(totalRow(page, s.byBranch)).toContainText(s.total);
    await expect(totalRow(page, s.byBranch)).toContainText("32.500");

    await expect(page.getByRole("tab", { name: s.byDay })).toHaveAttribute("aria-selected", "true");
    await expect(bodyRows(page, s.salesByDay)).toHaveCount(2);
    await expect(totalRow(page, s.salesByDay)).toContainText("32.500");

    await page.getByRole("tab", { name: s.byItem }).click();
    await expect(page).toHaveURL(/view=item/);
    await expect(bodyRows(page, s.salesByItem)).toHaveCount(1);
    await expect(bodyRows(page, s.salesByItem).first()).toContainText(`Voucher ${shop.id}`);
    await expect(totalRow(page, s.salesByItem)).toContainText("32.500");

    await page.getByRole("tab", { name: s.byStaffMember }).click();
    await expect(page).toHaveURL(/view=staff/);
    await expect(bodyRows(page, s.salesByStaffMember)).toHaveCount(1);
    await expect(bodyRows(page, s.salesByStaffMember).first()).toContainText(s.unassigned);
    await expect(totalRow(page, s.salesByStaffMember)).toContainText("32.500");

    await page.reload();
    await expect(page.getByRole("tab", { name: s.byStaffMember })).toHaveAttribute("aria-selected", "true");
  });

  test("payments by method and by day equal the RPC", async ({ page, request, s }) => {
    const { shop, day } = await shopWithSales(request, "money-payments");
    const rpc = await reportJson<{ totals: { net_minor: number; payment_count: number } }>(request, shop.owner, "report_payments_summary", {
      p_tenant_id: shop.tenantId,
      p_from: day,
      p_to: day,
    });
    expect(rpc.totals).toMatchObject({ net_minor: 32_500, payment_count: 3 });

    await open(page, s, shop.owner, "/reports/payments?branch=all&preset=today");
    await expect(figure(page.getByRole("region", { name: s.totals, exact: true }), s.netTakings)).toContainText("32.500");
    await expect(bodyRows(page, s.byPaymentMethod)).toHaveCount(2);
    await expect(bodyRows(page, s.byPaymentMethod).filter({ hasText: s.knet })).toContainText("25.000");
    await expect(bodyRows(page, s.byPaymentMethod).filter({ hasText: s.cardTerminal })).toContainText("7.500");
    await expect(totalRow(page, s.byPaymentMethod)).toContainText("32.500");
    await expect(bodyRows(page, s.byDay)).toHaveCount(2);
    await expect(totalRow(page, s.byDay)).toContainText("32.500");
  });

  test("taxes by rate and by day equal the RPC", async ({ page, request, s }) => {
    const { shop, day } = await shopWithSales(request, "money-taxes");
    const rpc = await reportJson<{ totals: { taxable_base_minor: number; tax_charged_minor: number }; by_rate: unknown[] }>(
      request,
      shop.owner,
      "report_taxes_summary",
      { p_tenant_id: shop.tenantId, p_from: day, p_to: day },
    );
    expect(rpc.totals).toMatchObject({ taxable_base_minor: 32_500, tax_charged_minor: 0 });

    await open(page, s, shop.owner, "/reports/taxes?branch=all&preset=today");
    await expect(figure(page.getByRole("region", { name: s.totals, exact: true }), s.taxCharged)).toContainText("0.000");
    await expect(bodyRows(page, s.byRate)).toHaveCount(rpc.by_rate.length);
    await expect(totalRow(page, s.byRate)).toContainText("32.500");
    await expect(bodyRows(page, s.byDay)).toHaveCount(2);
    await expect(totalRow(page, s.byDay)).toContainText("32.500");
  });

  test("one branch's sales equal its daily summary and the hub's card, for the owner and the manager", async ({ page, request, s }) => {
    const { shop } = await shopWithSales(request, "money-daily");
    await open(page, s, shop.owner, `/reports/sales?branch=${shop.branchId}&preset=today`);
    const totals = page.getByRole("region", { name: s.totals, exact: true });
    await expect(figure(totals, s.salesTitle)).toHaveText("2");
    const total = await figure(totals, s.salesTotal).innerText();
    expect(total).toContain("27.500");
    await expect(table(page, s.byBranch)).toHaveCount(0);

    await page.goto(`/sales/summary?branch=${shop.branchId}`);
    await expect(figure(page.getByRole("region", { name: s.salesOnThisDay }), s.salesTotal)).toHaveText(total);

    for (const [email, path] of [
      [shop.owner, `/reports?branch=${shop.branchId}`],
      [shop.manager, "/reports"],
    ] as const) {
      if (email !== shop.owner) {
        await page.context().clearCookies();
        await page.evaluate(() => window.localStorage.clear());
        await open(page, s, email, path);
      } else {
        await page.goto(path);
      }
      const card = page.getByRole("list", { name: s.reports }).getByRole("listitem").filter({ hasText: s.dailySummary });
      await expect(figure(card, s.salesToday)).toHaveText("2");
      await expect(figure(card, s.salesTotalToday)).toHaveText(total);
    }
  });
});
