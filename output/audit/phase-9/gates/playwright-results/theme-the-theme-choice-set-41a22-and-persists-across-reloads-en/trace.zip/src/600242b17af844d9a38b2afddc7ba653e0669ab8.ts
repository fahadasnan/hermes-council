import { expect, openAccountMenu, signIn, test } from "./fixtures";

test("the theme choice sets data-theme and persists across reloads", async ({ page, s }, testInfo) => {
  await page.goto("/login");
  await signIn(page, s, "owner@spacorner.test");
  const html = page.locator("html");
  await expect(html).not.toHaveAttribute("data-theme");

  await openAccountMenu(page);
  await page.getByRole("radio", { name: s.themeDark }).click();
  await expect(html).toHaveAttribute("data-theme", "dark");
  await page.screenshot({ path: testInfo.outputPath(`shell-dark-${s.lang}.png`), fullPage: true });

  // Applied before first paint by the inline script, then kept by the provider.
  await page.reload();
  await expect(html).toHaveAttribute("data-theme", "dark");
  await openAccountMenu(page);
  await expect(page.getByRole("radio", { name: s.themeDark })).toBeChecked();

  await page.getByRole("radio", { name: s.themeLight }).click();
  await expect(html).toHaveAttribute("data-theme", "light");

  await page.getByRole("radio", { name: s.themeSystem }).click();
  await expect(html).not.toHaveAttribute("data-theme");
  await page.reload();
  await expect(html).not.toHaveAttribute("data-theme");
});
