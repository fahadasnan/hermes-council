import type { APIRequestContext, Page } from "@playwright/test";
import { insert } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { bookVisit, cancelVisit, clock, figure, knetSale, kuwaitNow, reportJson, reportShop, type ReportShop } from "./reportFixtures";
import type { Strings } from "./strings";

// 7.2-T4 operational reports on a two-branch shop of its own, later today in Kuwait:
//   Main:   A (Huda, the staff login, client Noura), B (Huda, Noura, cancelled), C (Mariam, walk-in); a 20.000 walk-in sale
//   Second: D (Dana, Noura)
// Every branch: 4 appointments, 1 cancelled; Main: 3. Three shifts. The sale has no staff member: "Unassigned".

type Day = { shop: ReportShop; day: string };

async function today(request: APIRequestContext, label: string): Promise<Day> {
  const { day, minute } = kuwaitNow();
  const slot = Math.ceil((minute + 20) / 15) * 15;
  const shop = await reportShop(request, label);
  await bookVisit(request, shop, { branchId: shop.branchId, staffId: shop.loginStaffId, day, time: clock(slot), client: true });
  const b = await bookVisit(request, shop, { branchId: shop.branchId, staffId: shop.loginStaffId, day, time: clock(slot + 30), client: true });
  await bookVisit(request, shop, { branchId: shop.branchId, staffId: shop.mainStaffId, day, time: clock(slot + 30), client: false });
  await bookVisit(request, shop, { branchId: shop.secondBranchId, staffId: shop.secondStaffId, day, time: clock(slot), client: true });
  await cancelVisit(request, shop, b.id);
  await knetSale(request, shop, shop.branchId, 20_000);
  return { shop, day };
}

async function open(page: Page, s: Strings, email: string, path: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(path);
}

const table = (page: Page, caption: string) => page.getByRole("table", { name: caption, exact: true });
const bodyRows = (page: Page, caption: string) => table(page, caption).locator("tbody tr");
const totalRow = (page: Page, caption: string) => table(page, caption).locator("tfoot tr");
const args = ({ shop, day }: Day) => ({ p_tenant_id: shop.tenantId, p_from: day, p_to: day });

test.describe("operational reports", () => {
  test.skip(kuwaitNow().minute > 22 * 60 + 30, "needs the visits to start later today in Kuwait");

  test("appointments by day, reason and service equal the RPC; the manager sees Main only", async ({ page, request, s }) => {
    const fixture = await today(request, "ops-appointments");
    const { shop } = fixture;
    const rpc = await reportJson<{ totals: { total: number; cancelled: number }; by_service: { item_count: number }[] }>(
      request,
      shop.owner,
      "report_appointments_summary",
      args(fixture),
    );
    expect(rpc.totals).toMatchObject({ total: 4, cancelled: 1 });

    await open(page, s, shop.owner, "/reports/appointments?branch=all&preset=today");
    const totals = page.getByRole("region", { name: s.totals, exact: true });
    await expect(figure(totals, s.appointments)).toHaveText("4");
    await expect(figure(totals, s.cancelled)).toHaveText("1");
    await expect(bodyRows(page, s.appointmentsByDay)).toHaveCount(2);
    await expect(totalRow(page, s.appointmentsByDay)).toContainText("4");
    await expect(bodyRows(page, s.cancellationReasons)).toHaveCount(1);
    await expect(totalRow(page, s.cancellationReasons)).toContainText("1");
    await expect(bodyRows(page, s.byService)).toHaveCount(1);
    await expect(bodyRows(page, s.byService).first()).toContainText(`${shop.id}`);
    await expect(bodyRows(page, s.byService).first()).toContainText(String(rpc.by_service[0]!.item_count));

    await page.context().clearCookies();
    await page.evaluate(() => window.localStorage.clear());
    await open(page, s, shop.manager, "/reports/appointments?preset=today");
    await expect(figure(page.getByRole("region", { name: s.totals, exact: true }), s.appointments)).toHaveText("3");
    await expect(table(page, s.byBranch)).toHaveCount(0);
  });

  test("staff performance lists each staff member and the unassigned sales, adding up to the total", async ({ page, request, s }) => {
    const fixture = await today(request, "ops-staff");
    const { shop } = fixture;
    const rpc = await reportJson<{ rows: { staff_id: string; booked_minutes: number }[]; totals: { sales_minor: number; booked_minutes: number } }>(
      request,
      shop.owner,
      "report_staff_performance",
      args(fixture),
    );
    expect(rpc.totals).toMatchObject({ sales_minor: 20_000, booked_minutes: 90 });
    expect(rpc.rows).toHaveLength(3);

    await open(page, s, shop.owner, "/reports/staff?branch=all&preset=today");
    await expect(bodyRows(page, s.byStaffMember)).toHaveCount(4);
    const names = s.lang === "ar" ? ["هدى", "مريم", "دانة"] : ["Huda", "Mariam", "Dana"];
    for (const name of names) await expect(bodyRows(page, s.byStaffMember).filter({ hasText: `${name} ${shop.id}` })).toHaveCount(1);
    await expect(bodyRows(page, s.byStaffMember).last()).toContainText(s.unassigned);
    await expect(bodyRows(page, s.byStaffMember).last()).toContainText("20.000");
    await expect(totalRow(page, s.byStaffMember)).toContainText("20.000");
    await expect(totalRow(page, s.byStaffMember)).toContainText("90");
  });

  test("shifts list each staff member and day and add up to the RPC", async ({ page, request, s }) => {
    const fixture = await today(request, "ops-shifts");
    const { shop } = fixture;
    const rpc = await reportJson<{ totals: { shift_count: number; scheduled_minutes: number } }>(request, shop.owner, "report_shifts", args(fixture));
    expect(rpc.totals.shift_count).toBe(3);

    await open(page, s, shop.owner, "/reports/shifts?branch=all&preset=today");
    await expect(bodyRows(page, s.byStaffMemberAndDay)).toHaveCount(3);
    await expect(totalRow(page, s.byStaffMemberAndDay)).toContainText("3");
    await expect(figure(page.getByRole("region", { name: s.totals, exact: true }), s.scheduledMinutes)).toHaveText(
      new RegExp(`^${rpc.totals.scheduled_minutes.toLocaleString("en-US").replace(",", "[,٬]?")}$`),
    );
  });

  test("the client list shows seen clients or everyone, loads more, and opens a profile", async ({ page, request, s }) => {
    const { shop } = await today(request, "ops-clients");
    await insert(
      request,
      "clients",
      Array.from({ length: 101 }, (_, index) => ({ tenant_id: shop.tenantId, first_name: `Zz${String(index).padStart(3, "0")}`, last_name: shop.id })),
    );

    await open(page, s, shop.owner, "/reports/clients?branch=all&preset=today");
    await expect(bodyRows(page, s.clients)).toHaveCount(1);
    await expect(bodyRows(page, s.clients).first()).toContainText(shop.id);
    await expect(figure(page.getByRole("region", { name: s.totals, exact: true }), s.walkInSales)).toHaveText("1");

    await page.getByRole("radio", { name: s.everyClient }).click();
    await expect(page).toHaveURL(/mode=all/);
    await expect(bodyRows(page, s.clients)).toHaveCount(100);
    await expect(page.getByText(s.showingOf(100, 102))).toBeVisible();
    await page.getByRole("button", { name: s.loadMore }).click();
    await expect(bodyRows(page, s.clients)).toHaveCount(102);
    await expect(page.getByRole("button", { name: s.loadMore })).toHaveCount(0);

    await page.getByRole("radio", { name: s.seenInThisPeriod }).click();
    await expect(bodyRows(page, s.clients)).toHaveCount(1);
    await bodyRows(page, s.clients).first().getByRole("link").click();
    await expect(page).toHaveURL(new RegExp(`/clients/${shop.clientId}`));
  });
});
