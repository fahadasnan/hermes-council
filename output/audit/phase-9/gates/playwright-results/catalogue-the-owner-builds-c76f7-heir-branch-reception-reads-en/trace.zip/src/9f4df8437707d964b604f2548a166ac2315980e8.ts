import type { Page } from "@playwright/test";
import { expect } from "./fixtures";
import type { Strings } from "./strings";

// Catalogue journeys shared by catalogue.spec.ts and the Phase 3 evidence run.

const escape = (text: string) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Opens the hub with a branch filter ("all" for every branch). */
export async function openCatalogue(page: Page, s: Strings, branch: string) {
  // A just-submitted sign-in must land before a full page load.
  await expect(page).not.toHaveURL(/\/login/);
  await page.goto(`/catalogue?branch=${branch}`);
  await expect(page.getByRole("heading", { level: 1, name: s.catalogue })).toBeVisible();
}

export const categoryLinks = (page: Page, s: Strings) =>
  page.getByRole("navigation", { name: s.categories }).getByRole("listitem").getByRole("link");

/** Category names in menu order, without the "All categories" entry. */
export async function categoryOrder(page: Page, s: Strings): Promise<string[]> {
  return (await categoryLinks(page, s).allTextContents()).slice(1).map((text) => text.trim());
}

export async function addCategory(page: Page, s: Strings, names: { nameEn: string; nameAr: string }) {
  await page.getByRole("button", { name: s.newCategory }).click();
  const drawer = page.getByRole("dialog");
  await drawer.getByLabel(s.nameEn).fill(names.nameEn);
  await drawer.getByLabel(s.nameAr).fill(names.nameAr);
  await drawer.getByRole("button", { name: s.addCategory }).click();
  await expect(page.getByText(s.categoryAdded)).toBeVisible();
}

/** Picks a category in the hub; the services table is then named after it. */
export async function openCategory(page: Page, s: Strings, category: string) {
  await categoryLinks(page, s)
    .filter({ hasText: new RegExp(`^${escape(category)}`) })
    .click();
  await expect(servicesTable(page, s, category)).toBeVisible();
}

export const servicesTable = (page: Page, s: Strings, category: string) =>
  page.getByRole("table", { name: s.servicesIn(category) });

export const serviceRow = (page: Page, s: Strings, category: string, marker: string) =>
  servicesTable(page, s, category).getByRole("row", { name: new RegExp(escape(marker)) });

export const editorPanel = (page: Page, name: string) => page.getByRole("tabpanel", { name });

export type NewService = {
  nameEn: string;
  nameAr: string;
  duration: string;
  bufferBefore: string;
  bufferAfter: string;
  price: string;
};

/** Fills the Definition tab of the service editor. */
export async function fillDefinition(page: Page, s: Strings, service: NewService) {
  const definition = editorPanel(page, s.definitionTab);
  await definition.getByLabel(s.nameEn).fill(service.nameEn);
  await definition.getByLabel(s.nameAr).fill(service.nameAr);
  await definition.getByLabel(s.durationMinutes).fill(service.duration);
  await definition.getByLabel(s.bufferBefore).fill(service.bufferBefore);
  await definition.getByLabel(s.bufferAfter).fill(service.bufferAfter);
  await definition.getByLabel(s.price).fill(service.price);
}

/** The service id from the editor URL. */
export function serviceIdFromUrl(page: Page): string {
  const id = /\/catalogue\/services\/([0-9a-f-]{36})/.exec(page.url())?.[1];
  if (!id) throw new Error(`not on a service editor: ${page.url()}`);
  return id;
}
