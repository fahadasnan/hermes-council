import type { APIRequestContext, Page } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import {
  addMember,
  attemptRefund,
  attemptVoid,
  closeRegister,
  createSale,
  ensureRegisterOpen,
  freshShop,
  openCalendar,
  paymentIdsOf,
  saleOf,
  salesOf,
  shopVisit,
  type Shop,
  type ShopVisit,
} from "./checkoutFixtures";
import { expect, test } from "./fixtures";
import { kuwaitToday } from "./shiftFlows";
import type { AppLocale, Strings } from "./strings";

// Refunds and voids, each journey in a tenant of its own (`freshShop`): it
// opens and closes registers, which would disturb the Setup Studio branches
// the other checkout specs sell at. Money moves through the checkout function
// as real logins; the service key only reads results back.

const PRICE = 12_000;

async function setUp(request: APIRequestContext, appLocale: AppLocale, role: "branch_manager" | "receptionist") {
  const shop = await freshShop(request, `rv-${appLocale}`);
  const actor = await addMember(request, shop, role);
  const day = addDays(kuwaitToday(), 1);
  const visit = await shopVisit(request, shop, actor, { day, priceMinor: PRICE });
  return { shop, actor, day, visit };
}

function sellVisit(request: APIRequestContext, actor: string, shop: Shop, visit: ShopVisit, payments: { method: "cash" | "knet_terminal"; amount_minor: number }[]) {
  return createSale(request, actor, {
    tenant_id: shop.tenantId,
    branch_id: shop.branchId,
    appointment_id: visit.id,
    client_id: visit.clientId,
    lines: [{ type: "appointment_item", appointment_item_id: visit.itemId }],
    tips: [],
    payments,
    expected: { total_minor: PRICE, tip_minor: 0, grand_total_minor: PRICE },
  });
}

/** Signs in, opens the visit on the calendar and its sale from the appointment drawer. */
async function openSale(page: Page, s: Strings, actor: string, shop: Shop, day: string, visit: ShopVisit) {
  await openCalendar(page, s, actor, shop.branchId, day);
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await byStaff.locator("[data-event-id]:not([id^='time-grid-event-copy-'])").filter({ hasText: visit.label }).first().click();
  const appointment = page.getByRole("dialog", { name: new RegExp(visit.label) });
  await appointment.getByRole("button", { name: s.viewSale }).click();
  return { appointment, drawer: page.getByRole("dialog", { name: s.sale, exact: true }) };
}

test("a manager refunds a cash payment with no register open, and the refund is flagged", async ({ page, request, s, appLocale }) => {
  const { shop, actor, day, visit } = await setUp(request, appLocale, "branch_manager");
  const session = await ensureRegisterOpen(request, actor, shop.branchId, { tenantId: shop.tenantId });
  const sale = await sellVisit(request, actor, shop, visit, [{ method: "cash", amount_minor: PRICE }]);
  await closeRegister(request, actor, session, { tenantId: shop.tenantId });

  const { drawer } = await openSale(page, s, actor, shop, day, visit);
  await expect(drawer).toContainText(sale.invoice_number);
  await drawer.getByRole("button", { name: s.refundPaymentButton(s.cash) }).click();

  const dialog = page.getByRole("dialog", { name: s.refundThisPayment });
  await expect(dialog).toContainText("12.000");
  await expect(dialog.getByText(s.cashRefundWarning)).toBeVisible();
  // The reason is required before anything is sent.
  await dialog.getByRole("button", { name: s.refundConfirm }).click();
  await expect(dialog.getByText(s.giveReason)).toBeVisible();
  await dialog.getByRole("textbox", { name: s.reason }).fill("Client complaint");
  await dialog.getByRole("button", { name: s.refundConfirm }).dblclick();
  await expect(dialog).toBeHidden();

  await expect(drawer.getByText(s.refundFlagged, { exact: false })).toBeVisible();
  const refundRow = drawer.getByRole("listitem").filter({ hasText: s.refundOf(s.cash) });
  await expect(refundRow.getByText(s.outsideRegisterSession)).toBeVisible();
  await expect(refundRow).toContainText("Client complaint");
  await expect(drawer.getByRole("button", { name: s.refundPaymentButton(s.cash) })).toHaveCount(0);

  // One refund for the whole payment, by cash, in no register session; the sale stays paid.
  const stored = await saleOf(request, { id: sale.id });
  expect(stored.status).toBe("completed");
  expect(stored.payments.map((p) => [p.payment_type, p.payment_method, p.amount_minor])).toEqual([
    ["payment", "cash", PRICE],
    ["refund", "cash", PRICE],
  ]);
  expect(stored.payments[0]!.register_session_id).toBe(session);
  expect(stored.payments[1]!.register_session_id).toBeNull();
});

test("a receptionist sees no refund or void controls, and the function refuses her", async ({ page, request, s, appLocale }) => {
  const { shop, actor, day, visit } = await setUp(request, appLocale, "receptionist");
  const sale = await sellVisit(request, actor, shop, visit, [{ method: "knet_terminal", amount_minor: PRICE }]);

  const { drawer } = await openSale(page, s, actor, shop, day, visit);
  await expect(drawer.getByText(s.paid, { exact: true })).toBeVisible();
  await expect(drawer.getByRole("link", { name: s.printReceipt })).toBeVisible();
  await expect(drawer.getByRole("button", { name: s.refundPaymentButton(s.knet) })).toHaveCount(0);
  await expect(drawer.getByRole("button", { name: s.voidSale })).toHaveCount(0);

  // Hidden is not the guard: the checkout function answers 403 to her raw calls.
  const [paymentId] = await paymentIdsOf(request, sale.id);
  const refund = await attemptRefund(request, actor, { tenantId: shop.tenantId, paymentId: paymentId!, reason: "Trying" });
  expect(refund.status, JSON.stringify(refund.body)).toBe(403);
  expect("error" in refund.body && refund.body.error.code).toBe("FORBIDDEN");
  const voided = await attemptVoid(request, actor, { tenantId: shop.tenantId, saleId: sale.id, reason: "Trying" });
  expect(voided.status, JSON.stringify(voided.body)).toBe(403);
  expect("error" in voided.body && voided.body.error.code).toBe("FORBIDDEN");

  const stored = await saleOf(request, { id: sale.id });
  expect(stored.status).toBe("completed");
  expect(stored.payments).toHaveLength(1);
});

test("a manager voids a same-day sale: it stays as voided and the visit checks out again", async ({ page, request, s, appLocale }) => {
  const { shop, actor, day, visit } = await setUp(request, appLocale, "branch_manager");
  await ensureRegisterOpen(request, actor, shop.branchId, { tenantId: shop.tenantId });
  const sale = await sellVisit(request, actor, shop, visit, [
    { method: "cash", amount_minor: 5_000 },
    { method: "knet_terminal", amount_minor: 7_000 },
  ]);

  const { appointment, drawer } = await openSale(page, s, actor, shop, day, visit);
  await drawer.getByRole("button", { name: s.voidSale, exact: true }).click();
  const dialog = page.getByRole("dialog", { name: s.voidSaleTitle(sale.invoice_number) });
  await expect(dialog.getByText(s.onlyToday)).toBeVisible();
  await expect(dialog.getByText(s.appointmentStaysCompleted)).toBeVisible();
  await expect(dialog).toContainText("5.000");
  await expect(dialog).toContainText("7.000");
  await dialog.getByRole("button", { name: s.voidSale, exact: true }).click();
  await expect(dialog.getByText(s.giveReason)).toBeVisible();
  await dialog.getByRole("textbox", { name: s.reason }).fill("Rang up twice");
  await dialog.getByRole("button", { name: s.voidSale, exact: true }).dblclick();
  await expect(dialog).toBeHidden();

  await expect(drawer.getByText(s.saleVoided(sale.invoice_number))).toBeVisible();
  await expect(drawer.getByText(s.voided, { exact: true })).toBeVisible();
  await expect(drawer).toContainText("Rang up twice");
  await expect(drawer.getByText(s.refundOf(s.cash))).toBeVisible();
  await expect(drawer.getByText(s.refundOf(s.knet))).toBeVisible();
  await expect(drawer.getByRole("button", { name: s.voidSale, exact: true })).toHaveCount(0);

  // The record stays, voided, with both payments refunded once (one transaction, so in no set order).
  const stored = await saleOf(request, { id: sale.id });
  expect(stored.status).toBe("voided");
  expect(stored.payments.map((p) => [p.payment_type, p.payment_method, p.amount_minor]).sort()).toEqual([
    ["payment", "cash", 5_000],
    ["payment", "knet_terminal", 7_000],
    ["refund", "cash", 5_000],
    ["refund", "knet_terminal", 7_000],
  ]);

  // The visit has no live sale any more: it checks out again.
  await drawer.getByRole("button", { name: s.close }).click();
  await appointment.getByRole("button", { name: s.checkOut, exact: true }).click();
  const checkout = page.getByRole("dialog", { name: s.checkOut });
  await checkout.getByRole("group", { name: s.addAPayment }).getByRole("button", { name: s.knet, exact: true }).click();
  await expect(checkout.getByRole("group", { name: s.knet, exact: true }).getByRole("textbox", { name: s.amount })).toHaveValue("12.000");
  await checkout.getByRole("button", { name: s.completeSale }).click();
  await expect(checkout).toBeHidden();

  const sales = await salesOf(request, { appointmentId: visit.id });
  expect(sales.map((row) => row.status)).toEqual(["voided", "completed"]);
});
