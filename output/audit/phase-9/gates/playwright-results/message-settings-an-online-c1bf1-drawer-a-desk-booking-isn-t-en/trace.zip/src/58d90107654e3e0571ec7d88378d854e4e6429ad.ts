import type { APIRequestContext } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { accessToken, admin, API, ANON_KEY, insert, kuwait, REST } from "./bookingFixtures";
import { addMember, freshShop, openCalendar, shopCatalogue, type Shop } from "./checkoutFixtures";
import { expect, signIn, test } from "./fixtures";
import { kuwaitToday } from "./shiftFlows";

// Settings → branch → Messages, the "Booked online" badge and the
// "Possible duplicate" review flag, each on a business of its own per run.
// Online rows are made with the local service key: the online path itself is
// covered by the booking app's suite.

type StoredMessages = {
  reminders_enabled: boolean;
  reminder_offsets_minutes: number[];
  confirm_desk_bookings: boolean;
};

async function storedMessages(request: APIRequestContext, branchId: string): Promise<StoredMessages> {
  const response = await request.get(
    `${REST}/notification_settings?branch_id=eq.${branchId}&select=reminders_enabled,reminder_offsets_minutes,confirm_desk_bookings`,
    { headers: admin },
  );
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as StoredMessages[])[0]!;
}

async function deskBooking(request: APIRequestContext, actor: string, shop: Shop, item: object, clientId: string) {
  const response = await request.post(functionUrl(API, "bookings", "create"), {
    headers: {
      apikey: ANON_KEY,
      authorization: `Bearer ${await accessToken(request, actor)}`,
      "idempotency-key": crypto.randomUUID(),
    },
    data: { tenant_id: shop.tenantId, branch_id: shop.branchId, client_id: clientId, items: [item] },
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { data: { id: string } }).data.id;
}

const tomorrow = () => {
  const day = new Date(`${kuwaitToday()}T00:00:00Z`);
  day.setUTCDate(day.getUTCDate() + 1);
  return day.toISOString().slice(0, 10);
};

test("owner chooses when reminders go out and whether desk bookings get messages", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const shop = await freshShop(request, `messages-${appLocale}`);
  await page.goto("/login");
  await signIn(page, s, shop.owner);
  await page.goto(`/settings/branches/${shop.branchId}/messages`);
  await expect(
    page.getByRole("navigation", { name: s.branchSettingsNav }).getByRole("link", { name: s.messagesTab, exact: true }),
  ).toHaveAttribute("aria-current", "page");

  // The defaults: reminders a day and two hours ahead; a third time can't be added.
  const offset = (minutes: keyof typeof s.reminderOffset) =>
    page.getByRole("checkbox", { name: s.reminderOffset[minutes], exact: true });
  await expect(page.getByLabel(s.sendReminders)).toBeChecked();
  await expect(offset(1440)).toBeChecked();
  await expect(offset(120)).toBeChecked();
  await expect(offset(2880)).toBeDisabled();
  await expect(page.getByRole("checkbox", { name: s.sms })).toBeDisabled();
  await expect(page.getByRole("checkbox", { name: s.whatsapp })).toBeDisabled();
  await expect(page.getByText(s.notAvailableYet)).toHaveCount(2);

  // Two days and one day ahead, and no messages for desk bookings.
  await offset(120).uncheck();
  await offset(2880).check();
  await page.getByLabel(s.deskMessages).uncheck();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.messagesSaved)).toBeVisible();
  expect(await storedMessages(request, shop.branchId)).toEqual({
    reminders_enabled: true,
    reminder_offsets_minutes: [2880, 1440],
    confirm_desk_bookings: false,
  });

  // Reminders on with no time is refused at the form.
  await offset(2880).uncheck();
  await offset(1440).uncheck();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.reminderRequired)).toBeVisible();
  expect((await storedMessages(request, shop.branchId)).reminder_offsets_minutes).toEqual([2880, 1440]);

  // Reminders off.
  await page.getByLabel(s.sendReminders).uncheck();
  await expect(offset(1440)).toBeDisabled();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.messagesSaved)).toBeVisible();
  // The first save's toast may still be showing, so wait for the row itself.
  await expect
    .poll(() => storedMessages(request, shop.branchId))
    .toMatchObject({ reminders_enabled: false, reminder_offsets_minutes: [] });
  await page.reload();
  await expect(page.getByLabel(s.sendReminders)).not.toBeChecked();
  await expect(page.getByLabel(s.deskMessages)).not.toBeChecked();
});

test("an online booking is badged on the calendar and in its drawer; a desk booking isn't", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const day = tomorrow();
  const shop = await freshShop(request, `badge-${appLocale}`);
  const catalogue = await shopCatalogue(request, shop, { day, priceMinor: 10_000 });
  const [walkIn] = await insert(request, "clients", {
    tenant_id: shop.tenantId,
    first_name: "Reem",
    last_name: catalogue.label,
  });
  const item = (time: string) => ({
    service_id: catalogue.serviceId,
    staff_id: catalogue.staffId,
    starts_at: kuwait(day, time),
  });
  const online = await deskBooking(request, shop.owner, shop, item("15:00"), catalogue.clientId);
  await deskBooking(request, shop.owner, shop, item("17:00"), walkIn!.id);
  const marked = await request.patch(`${REST}/appointments?id=eq.${online}`, {
    headers: admin,
    data: { booked_via: "online", online_source: "qr" },
  });
  expect(marked.ok(), await marked.text()).toBe(true);

  await openCalendar(page, s, shop.owner, shop.branchId, day);
  const cards = page
    .getByRole("region", { name: s.appointmentsByStaff })
    .locator("[data-event-id]:not([id^='time-grid-event-copy-'])");
  const onlineCard = cards.filter({ hasText: appLocale === "en" ? "Noor" : "نور" });
  const deskCard = cards.filter({ hasText: "Reem" });
  await expect(onlineCard).toContainText(s.bookedOnline);
  await expect(deskCard).toBeVisible();
  await expect(deskCard).not.toContainText(s.bookedOnline);

  await onlineCard.click();
  await expect(page.getByRole("dialog").getByText(s.bookedOnlineByQr)).toBeVisible();
});

test("the desk finds a possible duplicate, sees who it matches and clears the flag", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const shop = await freshShop(request, `review-${appLocale}`);
  const receptionist = await addMember(request, shop, "receptionist");
  const phone = `+9655${String(Math.floor(Math.random() * 10_000_000)).padStart(7, "0")}`;
  const tenant = { tenant_id: shop.tenantId };
  await insert(request, "clients", {
    ...tenant,
    first_name: "Maryam",
    last_name: "Desk",
    phone,
    email: `desk-${shop.id}@example.com`,
  });
  const [flagged] = await insert(request, "clients", {
    ...tenant,
    first_name: "Maryam",
    last_name: "Online",
    phone,
    email: `online-${shop.id}@example.com`,
    source: "online",
    review_pending: true,
  });
  await insert(request, "clients", { ...tenant, first_name: "Dana", last_name: "Other" });

  await page.goto("/login");
  await signIn(page, s, receptionist);
  await page.goto("/clients");
  await page.getByLabel(s.statusFilter).selectOption({ label: s.needsReview });
  await expect(page).toHaveURL(/review=true/);
  const rows = page.getByRole("table").getByRole("row");
  await expect(rows.filter({ hasText: "Maryam Online" })).toContainText(s.possibleDuplicate);
  await expect(rows.filter({ hasText: "Maryam Desk" })).toHaveCount(0);
  await expect(rows.filter({ hasText: "Dana" })).toHaveCount(0);

  await page.getByRole("link", { name: "Maryam Online" }).click();
  await expect(page.getByText(s.onlineBookingTab, { exact: true })).toBeVisible();
  const banner = page.getByRole("region", { name: s.possibleDuplicate });
  const matches = banner.getByRole("list", { name: s.clientsWithSameDetails });
  await expect(matches.getByRole("listitem")).toHaveCount(1);
  await expect(matches.getByRole("link", { name: "Maryam Desk" })).toBeVisible();
  await expect(matches.getByText(s.samePhone)).toBeVisible();

  await banner.getByRole("button", { name: s.clearFlag }).click();
  await expect(page.getByText(s.duplicateFlagCleared)).toBeVisible();
  await expect(banner).toHaveCount(0);
  const stored = await request.get(`${REST}/clients?id=eq.${flagged!.id}&select=review_pending`, { headers: admin });
  expect(((await stored.json()) as { review_pending: boolean }[])[0]!.review_pending).toBe(false);

  await page.goto("/clients?review=true");
  await expect(page.getByRole("table").getByRole("row").filter({ hasText: "Maryam" })).toHaveCount(0);
});
